// chartype.cpp -- the char type
#include <iostream>
int main( )
{
	using namespace std;
	char ch; // deklarace znakove promenne

	cout << "Zadejte znak: " << endl;
	cin >> ch;
	cout << "Hola! ";
	cout << "Za znak " << ch << " vam dekuji." << endl;
	return 0;
}
