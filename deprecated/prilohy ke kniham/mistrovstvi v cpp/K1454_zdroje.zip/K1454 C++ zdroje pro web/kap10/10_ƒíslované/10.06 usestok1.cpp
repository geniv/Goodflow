 // usestok1.cpp -- pou�it� t��dy Stock
#include <iostream>
#include "stock1.h"

int main()
{
	using std::cout;
	using std::ios_base;
	cout.precision(2); 														// #.## form�t
	cout.setf(ios_base::fixed, ios_base::floatfield);		// #.## form�t
	cout.setf(ios_base::showpoint); 									// #.## form�t

	cout << "Vytvoreni novych objektu pomoci konstruktoru\n";
	Stock stock1("NanoSmart", 12, 20.0); // syntax 1
	stock1.show();
	Stock stock2 = Stock ("Boffo Objects", 2, 2.0); 		// syntaxe 2
	stock2.show();

	cout << "Dosazeni stock1 do stock2:\n";
	stock2 = stock1;
	cout << "Vypis stock1 a stock2:\n";
	stock1.show();
	stock2.show();

	cout << "Obnova objektu pomoci konstruktoru \n";
	stock1 = Stock("Nifty Foods", 10, 50.0); 					// do�asn� objekt
	cout << "Obnoveny stock1:\n";
	stock1.show();
	cout << "Hotovo\n";
	return 0;
}
