// myfirst.cpp -- zobrazuje zpr�vu
#include <iostream> 					// direktiva preprocesoru
int main() 									// hlavi�ka funkce
{ 													// za��tek t�la funkce
	using namespace std; 				// zp��stupn� definice
	cout << "Pojdme se chvili venovat C++."; 	// v�stup
	cout << endl; 							// za��tek nov� ��dky
	cout << "Nebudes litovat!" << endl;		// dal�� v�stup

	return 0; 								// ukon�uje main()
}													// konec t�la funkce
