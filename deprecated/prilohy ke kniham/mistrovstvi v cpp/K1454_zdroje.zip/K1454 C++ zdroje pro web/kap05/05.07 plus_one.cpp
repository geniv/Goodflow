// plus_one.cpp -- opr�tor inkrementov�n�
#include <iostream>
int main()
{
	using namespace std;
	int a = 20;
	int b = 20;

cout << "a   = " << a << ":   b = " << b << "\n";
cout << "a++ = " << a++ << ": ++b = " << ++b << "\n";
cout << "a   = " << a << ":   b = " << b << "\n";	

return 0;
}
