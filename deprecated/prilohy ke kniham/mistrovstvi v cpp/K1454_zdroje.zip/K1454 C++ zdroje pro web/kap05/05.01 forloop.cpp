// forloop.cpp -- p�edstaven� cyklu for
#include <iostream>
int main()
{
	using namespace std;
	int i; 			// vytvo�� po�itadlo
// inicializace; test; aktualizace
	for (i = 0; i < 5; i++)
		cout << "C++ umi cykly.\n";
	cout << "C++ vi, kdy skoncit.\n";
	
	return 0;
}
