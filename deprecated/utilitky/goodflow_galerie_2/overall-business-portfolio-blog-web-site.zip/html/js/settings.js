/* getting fade slider settings */
$fade_slider_speed = 5000;

/* getting nivo slider settings */
$nivo_slider_speed = 5000;
$nivo_slider_effect = 'random';

/* getting headlines settings */
$headlines_delay = 5000;