
-------------------- table:dynamicuser_gui_element

CREATE TABLE `dynamicuser_gui_element` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `nazev` varchar(200) collate utf8_czech_ci default NULL,
  `typ` int(10) unsigned default NULL,
  `value` varchar(500) collate utf8_czech_ci default NULL,
  `registrace` tinyint(1) default NULL,
  `profil` tinyint(1) default NULL,
  `readonly` tinyint(1) default NULL,
  `disabled` tinyint(1) default NULL,
  `povinne` tinyint(1) default NULL,
  `vstupni_typ` int(10) unsigned default NULL,
  `reg_exp` varchar(500) collate utf8_czech_ci default NULL,
  `format` varchar(200) collate utf8_czech_ci default NULL,
  `min_val` int(10) unsigned default NULL,
  `max_val` int(10) unsigned default NULL,
  `poradi` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('1', 'jméno', '0', '', '0', '1', '0', '0', '1', '0', '', '', '0', '0', '1');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('2', 'příjmení', '0', '', '0', '1', '0', '0', '1', '0', '', '', '0', '0', '2');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('3', 'muž', '6', 'pohlavi', '1', '1', '0', '0', '1', '0', '', '', '0', '0', '3');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('4', 'žena', '6', 'pohlavi', '1', '1', '0', '0', '1', '0', '', '', '0', '0', '4');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('5', 'hermafrodit', '6', 'pohlavi', '1', '1', '0', '0', '1', '0', '', '', '0', '0', '5');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('6', 'suene', '6', 'pohlavi', '1', '1', '0', '0', '1', '0', '', '', '0', '0', '6');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('7', 'něco o sobě', '1', '', '0', '1', '0', '0', '0', '0', '', '', '0', '0', '7');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('8', 'něaký povinný checkbox', '5', 'povny check', '1', '1', '0', '0', '1', '0', '', '', '0', '0', '8');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('9', 'a naše captcha', '7', '3', '1', '0', '0', '0', '1', '0', '', '', '0', '0', '9');
INSERT INTO dynamicuser_gui_element (id, nazev, typ, value, registrace, profil, readonly, disabled, povinne, vstupni_typ, reg_exp, format, min_val, max_val, poradi) VALUES ('10', 'datm narození', '2', '', '0', '1', '0', '0', '0', '0', '', 'j.n.Y', '0', '0', '10');

-------------------- table:dynamicuser_last_login

CREATE TABLE `dynamicuser_last_login` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uzivatel` int(10) unsigned default NULL,
  `prihlaseni` datetime default NULL,
  `last_active` datetime default NULL,
  `ip` varchar(50) collate utf8_czech_ci default NULL,
  `agent` varchar(300) collate utf8_czech_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('1', '9', '2009-09-28 19:58:20', '2009-09-28 20:22:20', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('2', '9', '2009-09-28 20:04:03', '2009-09-28 23:05:38', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('3', '10', '2009-09-28 21:02:00', '2009-09-28 21:07:00', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('4', '9', '2009-09-28 23:11:58', '2009-09-29 14:02:29', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('5', '9', '2009-09-29 13:58:42', '2009-10-02 19:45:57', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('6', '9', '2009-09-29 14:09:26', '2009-10-02 23:52:16', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('7', '9', '2009-10-02 19:41:55', '2009-10-02 23:52:23', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('8', '9', '2009-10-02 23:49:55', '2009-10-03 14:46:24', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('9', '10', '2009-10-02 23:50:19', '2009-10-04 19:35:50', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('10', '10', '2009-10-04 19:31:21', '2009-10-04 19:40:57', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('11', '10', '2009-10-04 19:43:14', '2009-10-04 19:44:25', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('12', '10', '2009-10-04 19:45:05', '2009-10-04 19:50:05', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('13', '10', '2009-10-04 19:45:36', '2009-10-04 19:50:36', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('14', '10', '2009-10-04 19:45:45', '2009-10-04 19:45:46', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('15', '10', '2009-10-04 19:46:02', '2009-10-04 19:55:04', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('16', '10', '2009-10-04 19:55:58', '2009-10-04 20:45:14', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('17', '10', '2009-10-04 20:42:12', '2009-10-04 20:47:12', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('18', '10', '2009-10-04 20:42:15', '2009-10-04 20:42:16', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('19', '10', '2009-10-04 20:45:38', '2009-10-04 20:50:38', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('20', '10', '2009-10-04 20:45:40', '2009-10-04 20:45:42', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('21', '10', '2009-10-04 20:45:43', '2009-10-04 20:45:44', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('22', '10', '2009-10-04 20:45:59', '2009-10-04 22:29:25', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('23', '10', '2009-10-05 12:26:47', '2009-10-05 12:46:55', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.3) Gecko/20090910 Ubuntu/9.04 (jaunty) Shiretoko/3.5.3');
INSERT INTO dynamicuser_last_login (id, uzivatel, prihlaseni, last_active, ip, agent) VALUES ('24', '9', '2009-10-05 12:28:08', '2009-10-05 12:47:11', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.213.1 Safari/532.1');

-------------------- table:dynamicuser_uzivatele

CREATE TABLE `dynamicuser_uzivatele` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `login` varchar(100) collate utf8_czech_ci default NULL,
  `heslo` varchar(100) collate utf8_czech_ci default NULL,
  `email` varchar(100) collate utf8_czech_ci default NULL,
  `pridano` datetime default NULL,
  `upraveno` datetime default NULL,
  `aktivni` tinyint(1) default NULL,
  `pocet` int(10) unsigned NOT NULL,
  `polozky` text collate utf8_czech_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicuser_uzivatele (id, login, heslo, email, pridano, upraveno, aktivni, pocet, polozky) VALUES ('9', 'genva', 'ad79e2cd5fd5ae53547d991007344847', 'kokot@email.cz', '2009-09-17 15:51:39', '2009-09-30 22:50:16', '1', '3', 'dfujnhbjhbcvxcyqj|-x-|dsfd f|-x-|hermafrodit|-x-|hermafrodit|-x-|hermafrodit|-x-|hermafrodit|-x-|dfdfsdf hveee|-x-|povny check|-x-|3|-x-|17.9.2009');
INSERT INTO dynamicuser_uzivatele (id, login, heslo, email, pridano, upraveno, aktivni, pocet, polozky) VALUES ('10', 'genvb', 'ad79e2cd5fd5ae53547d991007344847', 'email@email.cz', '2009-10-01 22:38:36', '0000-00-00 00:00:00', '1', '15', 'sadasdsad|-x-|asdasd|-x-|žena|-x-|žena|-x-|žena|-x-|žena|-x-|asd|-x-|povny check|-x-|3|-x-|1.10.2009');
