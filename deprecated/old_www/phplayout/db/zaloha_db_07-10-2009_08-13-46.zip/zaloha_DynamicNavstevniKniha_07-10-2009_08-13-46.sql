
-------------------- table:dynamicnavstevnikniha_element_kniha

CREATE TABLE `dynamicnavstevnikniha_element_kniha` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sablona` int(10) unsigned default NULL,
  `typ` int(10) unsigned default NULL,
  `nazev` varchar(200) collate utf8_czech_ci default NULL,
  `value` varchar(200) collate utf8_czech_ci default NULL,
  `povinne` tinyint(1) default NULL,
  `skryt_obsah` tinyint(1) default NULL,
  `vstupni_typ` int(10) unsigned default NULL,
  `reg_exp` varchar(500) collate utf8_czech_ci default NULL,
  `vystupni_format` varchar(200) collate utf8_czech_ci default NULL,
  `min_val` int(10) unsigned default NULL,
  `max_val` int(10) unsigned default NULL,
  `poradi` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicnavstevnikniha_element_kniha (id, sablona, typ, nazev, value, povinne, skryt_obsah, vstupni_typ, reg_exp, vystupni_format, min_val, max_val, poradi) VALUES ('1', '1', '1', 'sdsadasd', '', '1', '0', '0', '', '', '0', '0', '1');
INSERT INTO dynamicnavstevnikniha_element_kniha (id, sablona, typ, nazev, value, povinne, skryt_obsah, vstupni_typ, reg_exp, vystupni_format, min_val, max_val, poradi) VALUES ('2', '1', '4', 'sdsdasdsad', '', '1', '0', '0', '', 'd.m.Y', '0', '0', '2');
INSERT INTO dynamicnavstevnikniha_element_kniha (id, sablona, typ, nazev, value, povinne, skryt_obsah, vstupni_typ, reg_exp, vystupni_format, min_val, max_val, poradi) VALUES ('3', '1', '3', 'dfsdfsdf', '2', '1', '0', '0', '', '', '0', '0', '3');

-------------------- table:dynamicnavstevnikniha_obsah_sablony_kniha

CREATE TABLE `dynamicnavstevnikniha_obsah_sablony_kniha` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sablona` int(10) unsigned default NULL,
  `obsah` text collate utf8_czech_ci,
  `pridano` datetime default NULL,
  `zobrazit` tinyint(1) default NULL,
  `admin` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicnavstevnikniha_obsah_sablony_kniha (id, sablona, obsah, pridano, zobrazit, admin) VALUES ('1', '1', '0||--x--||aedwfrqfegtr|-x-|16.09.2009', '2009-09-16 21:17:51', '1', '1');
INSERT INTO dynamicnavstevnikniha_obsah_sablony_kniha (id, sablona, obsah, pridano, zobrazit, admin) VALUES ('2', '1', '0||--x--||dsfgdghdhhggfh|-x-|16.09.2009', '2009-09-16 21:29:22', '1', '1');

-------------------- table:dynamicnavstevnikniha_sablona_kniha

CREATE TABLE `dynamicnavstevnikniha_sablona_kniha` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `adresa` text collate utf8_czech_ci,
  `razeni` varchar(50) collate utf8_czech_ci default NULL,
  `nove_rss` int(10) unsigned default NULL,
  `nazev` varchar(200) collate utf8_czech_ci default NULL,
  `popisek` text collate utf8_czech_ci,
  `href_id` varchar(200) collate utf8_czech_ci default NULL,
  `href_class` varchar(200) collate utf8_czech_ci default NULL,
  `href_akce` varchar(500) collate utf8_czech_ci default NULL,
  `zobrazit` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicnavstevnikniha_sablona_kniha (id, adresa, razeni, nove_rss, nazev, popisek, href_id, href_class, href_akce, zobrazit) VALUES ('1', 'adresa', 'DESC', '5', 'asdfsdafdsdasd a ', 'asdasdas f ad asd s d a sa dsa d asd as d sd asd', '', '', '', '1');
