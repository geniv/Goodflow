
-------------------- table:cyklicky_obsah

CREATE TABLE cyklicky_obsah (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      datum DATETIME,
                                      text TEXT);

INSERT INTO cyklicky_obsah (id, adresa, datum, text) VALUES ('1', 'neco', '2009-02-15 00:00:00', 'ahojky');
INSERT INTO cyklicky_obsah (id, adresa, datum, text) VALUES ('2', 'neco', '2009-03-18 00:00:00', 'kkuk');
INSERT INTO cyklicky_obsah (id, adresa, datum, text) VALUES ('3', 'dsff_2', '2009-04-03 21:49:09', 'sdasd');
INSERT INTO cyklicky_obsah (id, adresa, datum, text) VALUES ('4', 'dsff_1', '2009-05-23 19:26:44', 'sdfdsaf');
