
-------------------- table:skupina

CREATE TABLE skupina (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      nahledy INTEGER UNSIGNED,
                                      nazev VARCHAR(200),
                                      rewrite VARCHAR(200),
                                      url VARCHAR(200),
                                      popis TEXT,
                                      datum DATETIME,
                                      defaultni BOOL,
                                      poradi INTEGER UNSIGNED);

INSERT INTO skupina (id, adresa, nahledy, nazev, rewrite, url, popis, datum, defaultni, poradi) VALUES ('1', 'adresa', '1', 'sekce jedna', 'sekce-jedna', '', '', '2009-07-28 23:28:38', '0', '0');

-------------------- table:picture_gallery

CREATE TABLE picture_gallery (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      skupina INTEGER UNSIGNED,
                                      popisek VARCHAR(300),
                                      url VARCHAR(200),
                                      datum DATETIME,
                                      w_mini INTEGER UNSIGNED,
                                      h_mini INTEGER UNSIGNED,
                                      w_midd INTEGER UNSIGNED,
                                      h_midd INTEGER UNSIGNED,
                                      w_full INTEGER UNSIGNED,
                                      h_full INTEGER UNSIGNED,
                                      zobrazeni INTEGER UNSIGNED,
                                      poradi INTEGER UNSIGNED);

INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('1', '1', '1', '28-07-2009-23-32-08-77.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '0');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('2', '1', '2', '28-07-2009-23-32-09-64.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '1');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('3', '1', '3', '28-07-2009-23-32-10-96.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '2');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('4', '1', '4', '28-07-2009-23-32-11-12.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '3');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('5', '1', '5', '28-07-2009-23-32-11-81.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '4');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('6', '1', '6', '28-07-2009-23-32-12-69.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '5');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('7', '1', '7', '28-07-2009-23-32-13-37.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '6');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('8', '1', '8', '28-07-2009-23-32-14-72.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '2', '7');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('9', '1', '9', '28-07-2009-23-32-14-71.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '8');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('10', '1', '10', '28-07-2009-23-32-15-78.jpg', '2009-07-28 23:29:14', '0', '135', '0', '300', '0', '0', '0', '9');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('11', '1', '--- bez komentáře ---', '05-08-2009-12-24-51-24.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '0');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('12', '1', '--- bez komentáře ---', '05-08-2009-12-24-53-40.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '1');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('13', '1', '--- bez komentáře ---', '05-08-2009-12-24-54-85.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '2');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('14', '1', '--- bez komentáře ---', '05-08-2009-12-24-55-33.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '3');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('15', '1', '--- bez komentáře ---', '05-08-2009-12-24-57-88.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '4');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('16', '1', '--- bez komentáře ---', '05-08-2009-12-24-58-69.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '5');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('17', '1', '--- bez komentáře ---', '05-08-2009-12-24-59-79.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '6');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('18', '1', '--- bez komentáře ---', '05-08-2009-12-25-00-49.jpg', '2009-08-05 12:20:30', '0', '135', '0', '300', '1024', '768', '0', '7');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('21', '1', '--- bez komentáře ---', '05-08-2009-12-28-39-61.jpg', '2009-08-05 12:27:22', '0', '135', '0', '300', '0', '1024', '0', '0');
INSERT INTO picture_gallery (id, skupina, popisek, url, datum, w_mini, h_mini, w_midd, h_midd, w_full, h_full, zobrazeni, poradi) VALUES ('22', '1', '--- bez komentáře ---', '05-08-2009-12-28-40-16.jpg', '2009-08-05 12:27:22', '0', '135', '0', '300', '0', '1024', '0', '1');
