
-------------------- table:gallery

CREATE TABLE gallery (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      popisek VARCHAR(300),
                                      url VARCHAR(200),
                                      datum DATETIME,
                                      poradi INTEGER UNSIGNED,
                                      w_mini INTEGER UNSIGNED,
                                      h_mini INTEGER UNSIGNED,
                                      w_full INTEGER UNSIGNED,
                                      h_full INTEGER UNSIGNED);

INSERT INTO gallery (id, adresa, popisek, url, datum, poradi, w_mini, h_mini, w_full, h_full) VALUES ('1', 'adresa', 'popisovity', '23-09-2009-18-31-36.jpg', '2009-07-05 13:11:02', '1', '0', '135', '0', '0');
INSERT INTO gallery (id, adresa, popisek, url, datum, poradi, w_mini, h_mini, w_full, h_full) VALUES ('2', 'adresa', 'sfsfsf', '23-09-2009-18-29-13.jpg', '2009-09-23 18:29:01', '2', '0', '135', '0', '0');
INSERT INTO gallery (id, adresa, popisek, url, datum, poradi, w_mini, h_mini, w_full, h_full) VALUES ('3', 'adresa', 'gdfg', '23-09-2009-18-31-51.jpg', '2009-09-23 18:31:41', '3', '0', '135', '0', '0');
INSERT INTO gallery (id, adresa, popisek, url, datum, poradi, w_mini, h_mini, w_full, h_full) VALUES ('4', 'adresa', 'dsadsad', '29-09-2009-01-49-46.jpg', '2009-09-29 01:48:41', '4', '0', '135', '0', '0');
