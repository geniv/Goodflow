
-------------------- table:formular

CREATE TABLE formular (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      nazev VARCHAR(200),
                                      predmet VARCHAR(200),
                                      email VARCHAR(100),
                                      textemail TEXT,
                                      dodatek TEXT,
                                      oznameni BOOL,
                                      predmetoznameni VARCHAR(200),
                                      textemailoznameni TEXT,
                                      zdrojovyemail VARCHAR(100),
                                      odesilateladmin VARCHAR(100),
                                      odesilateluzivatel VARCHAR(100));

INSERT INTO formular (id, adresa, nazev, predmet, email, textemail, dodatek, oznameni, predmetoznameni, textemailoznameni, zdrojovyemail, odesilateladmin, odesilateluzivatel) VALUES ('1', 'adresa', 'název formulaře', 'předmět emailu', 'kokot1@hu.cz, kokot2@hu.cz, kokot3@hu.cz', 'adasd ad asdas dsad asd as dsadsad.
@@1@@ - 1&lt;br /&gt;
@@2@@ - 2&lt;br /&gt;
@@3@@ - 3&lt;br /&gt;
@@4@@ - 4&lt;br /&gt;
@@5@@ - 5&lt;br /&gt;
@@6@@ - 6&lt;br /&gt;
@@7@@ - 7&lt;br /&gt;
@@8@@ - 8&lt;br /&gt;
@@9@@ - 9&lt;br /&gt;
@@10@@ - 10&lt;br /&gt;
@@11@@ - 11&lt;br /&gt;
@@12@@ - 12&lt;br /&gt;
@@13@@ - 13&lt;br /&gt;
@@14@@ - 14&lt;br /&gt;
@@15@@ - 15&lt;br /&gt;
@@16@@ - 16&lt;br /&gt;
@@17@@ - 17&lt;br /&gt;
@@18@@ - 18&lt;br /&gt;
@@19@@ - 19&lt;br /&gt;
@@20@@ - 20&lt;br /&gt;

dsfdg fjdgh  dhss dfhg.  ', 'dsfdg fjdgh  dhss dfhg.', '0', '', '', '', '&quot;od debilu sro.cz&quot; &lt;no-reply@ranky.cz&gt;', '');

-------------------- table:prvek

CREATE TABLE prvek (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      formular INTEGER UNSIGNED,
                                      nazev VARCHAR(200),
                                      typ INTEGER UNSIGNED,
                                      value VARCHAR(200),
                                      readonly BOOL,
                                      disabled BOOL,
                                      povinne BOOL,
                                      reg_exp VARCHAR(500),
                                      vstupni_typ INTEGER UNSIGNED,
                                      min_val INTEGER UNSIGNED,
                                      max_val INTEGER UNSIGNED,
                                      poradi INTEGER UNSIGNED);

INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('1', '1', 'dsfkjkj:', '0', 'hhsdasd asd :D', '0', '0', '0', '', '0', '0', '0', '1');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('2', '1', 'email:', '0', 'zde napiš svůj email', '0', '0', '1', '/^[_a-zA-Z0-9\.\-]+@[_a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,4}$/', '2', '0', '0', '2');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('3', '1', '', '2', 'odeslat', '0', '0', '1', '', '0', '0', '0', '4');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('4', '1', '', '4', '1', '0', '0', '1', '', '0', '0', '0', '3');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('5', '1', 'pokus1', '1', '', '0', '0', '0', '', '0', '0', '0', '5');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('6', '1', 'pokus2', '1', '', '0', '0', '0', '', '0', '0', '0', '6');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('7', '1', 'pokus3', '1', '', '0', '0', '0', '', '0', '0', '0', '7');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('8', '1', 'pokus4', '1', '', '0', '0', '0', '', '0', '0', '0', '8');
