
-------------------- table:menu

CREATE TABLE menu (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      rewrite VARCHAR(200),
                                      nazev VARCHAR(200),
                                      koren INTEGER UNSIGNED,
                                      submenu TEXT,
                                      zanoreni INTEGER UNSIGNED);

INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('1', 'ahoj-sekce', 'ahoj sekce', '0', '2-5', '0');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('2', 'pod-ahoj-sekce', 'pod ahoj sekce', '1', '8', '1');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('3', 'hu-dalsi-hlavni', 'hu další hlavní', '0', '4', '0');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('4', 'a-ta-ma-taky-pod-hlavni', 'a ta má taky pod hlavní', '3', '6-7', '1');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('5', 'jeste-raz', 'jestě raz', '1', '', '1');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('6', 'a-tu-taky', 'a tu taky', '4', '', '2');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('7', 'dokonce', 'dokonce', '4', '', '2');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('8', 'a-sup-novou', 'a šup novou', '2', '9', '2');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('9', 'tak-schvalne', 'tak schválně', '8', '10', '3');
INSERT INTO menu (id, rewrite, nazev, koren, submenu, zanoreni) VALUES ('10', 'lol-to-je-faakt-narez', 'lol to je fáákt nářez', '9', '', '4');
