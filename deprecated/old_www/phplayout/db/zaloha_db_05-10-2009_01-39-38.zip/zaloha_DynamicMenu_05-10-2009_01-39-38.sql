
-------------------- table:skupina_menu

CREATE TABLE skupina_menu (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      nazev VARCHAR(200),
                                      poradi INTEGER UNSIGNED,
                                      razeni BOOL,
                                      adresa TEXT,
                                      adr_obsahu VARCHAR(200));

INSERT INTO skupina_menu (id, nazev, poradi, razeni, adresa, adr_obsahu) VALUES ('1', '', '1', '1', 'adresa', 'dynobsah&amp;co=addobsah');

-------------------- table:dynamic_menu

CREATE TABLE dynamic_menu (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      main_href VARCHAR(200),
                                      odkaz VARCHAR(300),
                                      title VARCHAR(300),
                                      href_id VARCHAR(200),
                                      href_class VARCHAR(200),
                                      href_akce VARCHAR(500),
                                      skupina INTEGER UNSIGNED,
                                      poradi INTEGER UNSIGNED,
                                      defaultni BOOL);

INSERT INTO dynamic_menu (id, main_href, odkaz, title, href_id, href_class, href_akce, skupina, poradi, defaultni) VALUES ('1', 'podsekce', 'asd', 'sdasd', '', 'sadasd', '', '1', '1', '1');
INSERT INTO dynamic_menu (id, main_href, odkaz, title, href_id, href_class, href_akce, skupina, poradi, defaultni) VALUES ('2', 'a', 'men_a', '', '', '', '', '1', '2', '0');
INSERT INTO dynamic_menu (id, main_href, odkaz, title, href_id, href_class, href_akce, skupina, poradi, defaultni) VALUES ('3', 'b', 'men b', '', '', '', '', '1', '3', '0');
