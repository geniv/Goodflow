
-------------------- table:hlavicka

CREATE TABLE hlavicka (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      nadpis VARCHAR(200),
                                      sloupce TEXT,
                                      defaultni TEXT,
                                      poznamka VARCHAR(300),
                                      table_id VARCHAR(200),
                                      table_class VARCHAR(200),
                                      table_akce VARCHAR(500));

INSERT INTO hlavicka (id, adresa, nadpis, sloupce, defaultni, poznamka, table_id, table_class, table_akce) VALUES ('1', 'adresa', 'nadpisek', 's1 :D|--|s2|--|s2', 'def ob1|--|def ob2|--|def ob3', 'poznámka na konec', 'id_Tab', 'class_Tab', '');
INSERT INTO hlavicka (id, adresa, nadpis, sloupce, defaultni, poznamka, table_id, table_class, table_akce) VALUES ('2', 'dfdfd', 'dsfdfasfasfdsa', 'assas|--|asasddf', 'aa|--|ss', 'fdsf', '', '', '');
INSERT INTO hlavicka (id, adresa, nadpis, sloupce, defaultni, poznamka, table_id, table_class, table_akce) VALUES ('3', 'adresa3', 'sdsds', 'nazev', 'defi', '', '', '', '');

-------------------- table:bunka

CREATE TABLE bunka (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      hlavicka INTEGER UNSIGNED,
                                      radek TEXT,
                                      poradi INTEGER UNSIGNED,
                                      bunka_id VARCHAR(200),
                                      bunka_class VARCHAR(200),
                                      bunka_akce VARCHAR(500));

INSERT INTO bunka (id, hlavicka, radek, poradi, bunka_id, bunka_class, bunka_akce) VALUES ('1', '1', 'def ob1|--|def ob2|--|def ob3', '1', 'ideecko', 'classs', '');
INSERT INTO bunka (id, hlavicka, radek, poradi, bunka_id, bunka_class, bunka_akce) VALUES ('2', '1', 'def ob1|--|def ob2|--|def ob3', '2', '', '', '');
INSERT INTO bunka (id, hlavicka, radek, poradi, bunka_id, bunka_class, bunka_akce) VALUES ('3', '1', 'def ob1|--|def ob2|--|def ob3', '3', '', '', '');
INSERT INTO bunka (id, hlavicka, radek, poradi, bunka_id, bunka_class, bunka_akce) VALUES ('4', '3', 'defisf', '1', '', '', '');
INSERT INTO bunka (id, hlavicka, radek, poradi, bunka_id, bunka_class, bunka_akce) VALUES ('5', '3', 'defiafaf', '2', '', '', '');
