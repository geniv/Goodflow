
-------------------- table:htaccess

CREATE TABLE htaccess (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      aktivni BOOL,
                                      rewrite TEXT,
                                      poznamka VARCHAR(300),
                                      poradi INTEGER UNSIGNED);

INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('1', '1', 'Options -Indexes', 'zobrazovani souboru', '1');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('2', '1', 'ErrorDocument 400 http://geniv-laptop/phplayout/error_page/400.html', 'error page 400', '2');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('3', '1', 'ErrorDocument 401 http://geniv-laptop/phplayout/error_page/401.html', 'error page 401', '3');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('4', '1', 'ErrorDocument 403 http://geniv-laptop/phplayout/error_page/403.html', 'error page 403', '4');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('5', '1', 'ErrorDocument 404 http://geniv-laptop/phplayout/error_page/404.html', 'error page 404', '5');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('6', '1', 'ErrorDocument 500 http://geniv-laptop/phplayout/error_page/500.html', 'error page 500', '6');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('7', '1', 'ErrorDocument 503 http://geniv-laptop/phplayout/error_page/503.html', 'error page 503', '7');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('8', '0', 'AddHandler php5-cgi .php', 'zapinani php5 na klenotu 1/2', '8');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('9', '0', 'Action php5-cgi /php5cgi/php', 'zapinani php5 na klenotu 2/2', '9');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('10', '0', 'RewriteEngine on', 'zapinani rewrite', '10');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('11', '0', 'RewriteRule ^rss/([a-zA-Z-\_]+)/?$ ?action=rss&sablona=$1 [L]', '', '11');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('12', '0', 'RewriteRule ^([a-zA-Z0-9-\_]+)/([0-9]+)?$ ?action=$1&str=$2 [L]', '', '12');
INSERT INTO htaccess (id, aktivni, rewrite, poznamka, poradi) VALUES ('13', '0', 'RewriteRule ^([a-zA-Z0-9-\_]+)/?$ ?action=$1 [L]', '', '13');
