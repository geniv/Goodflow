
-------------------- table:dynamic_menu_without_group

CREATE TABLE dynamic_menu_without_group (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      main_href VARCHAR(200),
                                      href VARCHAR(200),
                                      odkaz VARCHAR(300),
                                      title VARCHAR(300),
                                      href_id VARCHAR(200),
                                      href_class VARCHAR(200),
                                      href_akce VARCHAR(500),
                                      poradi INTEGER UNSIGNED,
                                      defaultni BOOL,
                                      adresa TEXT);

INSERT INTO dynamic_menu_without_group (id, main_href, href, odkaz, title, href_id, href_class, href_akce, poradi, defaultni, adresa) VALUES ('1', 'maindd', 'dhrees=kokot', 'gdfgdfgfdg', '-aaesfdf', '', '', '', '1', '0', 'adresa');
INSERT INTO dynamic_menu_without_group (id, main_href, href, odkaz, title, href_id, href_class, href_akce, poradi, defaultni, adresa) VALUES ('2', 'gjhgjjghj', 'oioioio=jj', 'vncfgd', '-dsgdfg', '', '', '', '2', '1', 'adresa');
