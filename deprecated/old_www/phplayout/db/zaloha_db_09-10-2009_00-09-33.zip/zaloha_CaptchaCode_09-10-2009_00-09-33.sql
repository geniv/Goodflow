
-------------------- table:captcha

CREATE TABLE captcha (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      typ INTEGER UNSIGNED,
                                      otazka VARCHAR(500),
                                      pocet INTEGER UNSIGNED,
                                      x INTEGER UNSIGNED,
                                      y INTEGER UNSIGNED,
                                      width INTEGER UNSIGNED,
                                      height INTEGER UNSIGNED,
                                      font INTEGER UNSIGNED,
                                      font_size VARCHAR(20),
                                      roztec INTEGER UNSIGNED,
                                      font_color VARCHAR(20),
                                      background_color VARCHAR(10),
                                      rotace_pismen VARCHAR(20),
                                      mrizka VARCHAR(20),
                                      rand_dot BOOL,
                                      rand_line BOOL,
                                      rand_rectangle BOOL,
                                      rand_arc BOOL,
                                      rand_ellipse BOOL,
                                      rand_barva VARCHAR(20),
                                      rand_koeficient VARCHAR(20),
                                      url VARCHAR(200),
                                      vyrez_x INTEGER UNSIGNED,
                                      vyrez_y INTEGER UNSIGNED);

INSERT INTO captcha (id, typ, otazka, pocet, x, y, width, height, font, font_size, roztec, font_color, background_color, rotace_pismen, mrizka, rand_dot, rand_line, rand_rectangle, rand_arc, rand_ellipse, rand_barva, rand_koeficient, url, vyrez_x, vyrez_y) VALUES ('1', '9', 'opiš následující super text:', '6', '20', '50', '200', '100', '1', '14|--|', '20', 'fff|--|', '000', '0|--|', '|--||--|', '0', '0', '0', '0', '0', 'aaa|--|', '|--|', '', '0', '0');
INSERT INTO captcha (id, typ, otazka, pocet, x, y, width, height, font, font_size, roztec, font_color, background_color, rotace_pismen, mrizka, rand_dot, rand_line, rand_rectangle, rand_arc, rand_ellipse, rand_barva, rand_koeficient, url, vyrez_x, vyrez_y) VALUES ('2', '12', 'ot2', '6', '20', '50', '500', '100', '2', '14|--|', '20', 'fff|--|', '000', '0|--|', '|--||--|', '0', '0', '0', '0', '0', 'aaa|--|', '|--|', '', '0', '0');
INSERT INTO captcha (id, typ, otazka, pocet, x, y, width, height, font, font_size, roztec, font_color, background_color, rotace_pismen, mrizka, rand_dot, rand_line, rand_rectangle, rand_arc, rand_ellipse, rand_barva, rand_koeficient, url, vyrez_x, vyrez_y) VALUES ('3', '14', 'ot3', '31', '10', '20', '450', '30', '2', '14|--|', '20', '000|--|', 'fff', '0|--|', '|--||--|', '0', '0', '0', '0', '0', 'ccc|--|', '|--|', '', '0', '0');

-------------------- table:captcha_font

CREATE TABLE captcha_font (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      nazev VARCHAR(100),
                                      url VARCHAR(300));

INSERT INTO captcha_font (id, nazev, url) VALUES ('1', 'font 1', '16-07-2009-22-43-37_05-07-2009-23-55-33_Last-Ninja.ttf');
INSERT INTO captcha_font (id, nazev, url) VALUES ('2', 'font 2', '16-07-2009-22-43-52_05-07-2009-23-55-58_Daniel.ttf');
