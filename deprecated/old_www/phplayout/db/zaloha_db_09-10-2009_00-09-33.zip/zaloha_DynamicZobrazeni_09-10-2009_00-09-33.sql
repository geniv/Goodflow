
-------------------- table:dynamiczobrazeni_element

CREATE TABLE `dynamiczobrazeni_element` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sablona` int(10) unsigned default NULL,
  `typ` int(10) unsigned default NULL,
  `nazev` varchar(200) collate utf8_czech_ci default NULL,
  `value` varchar(200) collate utf8_czech_ci default NULL,
  `povinne` tinyint(1) default NULL,
  `vstupni_typ` int(10) unsigned default NULL,
  `reg_exp` varchar(500) collate utf8_czech_ci default NULL,
  `vystupni_format` varchar(200) collate utf8_czech_ci default NULL,
  `min_poc` int(10) unsigned default NULL,
  `max_poc` int(10) unsigned default NULL,
  `poradi` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamiczobrazeni_element (id, sablona, typ, nazev, value, povinne, vstupni_typ, reg_exp, vystupni_format, min_poc, max_poc, poradi) VALUES ('1', '1', '1', 'neco... S', '', '0', '0', '', '', '0', '0', '1');
INSERT INTO dynamiczobrazeni_element (id, sablona, typ, nazev, value, povinne, vstupni_typ, reg_exp, vystupni_format, min_poc, max_poc, poradi) VALUES ('2', '1', '7', 'nějaky chceck box', 'bocX?', '0', '0', '', '', '0', '0', '2');
INSERT INTO dynamiczobrazeni_element (id, sablona, typ, nazev, value, povinne, vstupni_typ, reg_exp, vystupni_format, min_poc, max_poc, poradi) VALUES ('5', '1', '3', 'obr', '130|-|0|-|0|-|0', '0', '0', '', '', '0', '0', '4');
INSERT INTO dynamiczobrazeni_element (id, sablona, typ, nazev, value, povinne, vstupni_typ, reg_exp, vystupni_format, min_poc, max_poc, poradi) VALUES ('4', '1', '4', 'datum akce', '', '1', '0', '', 'd.m.Y', '0', '0', '3');
INSERT INTO dynamiczobrazeni_element (id, sablona, typ, nazev, value, povinne, vstupni_typ, reg_exp, vystupni_format, min_poc, max_poc, poradi) VALUES ('6', '1', '8', 'datum auto smazani', 'id_autodel', '1', '0', '+1 day', 'd.m.Y H:i:s', '0', '0', '5');

-------------------- table:dynamiczobrazeni_obsah_sablony

CREATE TABLE `dynamiczobrazeni_obsah_sablony` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sablona` int(10) unsigned default NULL,
  `obsah` text collate utf8_czech_ci,
  `pridano` datetime default NULL,
  `nazev` varchar(200) collate utf8_czech_ci default NULL,
  `rewrite` varchar(200) collate utf8_czech_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamiczobrazeni_obsah_sablony (id, sablona, obsah, pridano, nazev, rewrite) VALUES ('7', '1', 'fgfdgdfgdfg|-x-||-x-|27.09.2009|-x-|||--x--||130||--x--||0||--x--||0||--x--||0|-x-|28.09.2009 00:00:00', '2009-09-24 16:26:33', '', '');
INSERT INTO dynamiczobrazeni_obsah_sablony (id, sablona, obsah, pridano, nazev, rewrite) VALUES ('5', '1', 'dfsdsad|-x-||-x-|20.09.2009|-x-|||--x--||130||--x--||0||--x--||0||--x--||0|-x-|21.09.2009 00:00:00', '2009-09-23 20:51:22', '', '');
INSERT INTO dynamiczobrazeni_obsah_sablony (id, sablona, obsah, pridano, nazev, rewrite) VALUES ('6', '1', 'sdsd|-x-||-x-|23.10.2009|-x-|||--x--||130||--x--||0||--x--||0||--x--||0|-x-|24.10.2009 00:00:00', '2009-09-23 20:51:41', '', '');

-------------------- table:dynamiczobrazeni_sablona

CREATE TABLE `dynamiczobrazeni_sablona` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `adresa` text collate utf8_czech_ci,
  `razeni` varchar(50) collate utf8_czech_ci default NULL,
  `nove` int(10) unsigned default NULL,
  `nove_rss` int(10) unsigned default NULL,
  `nazev` varchar(200) collate utf8_czech_ci default NULL,
  `rewrite` varchar(200) collate utf8_czech_ci default NULL,
  `popisek` text collate utf8_czech_ci,
  `href_id` varchar(200) collate utf8_czech_ci default NULL,
  `href_class` varchar(200) collate utf8_czech_ci default NULL,
  `href_akce` varchar(500) collate utf8_czech_ci default NULL,
  `zobrazit` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamiczobrazeni_sablona (id, adresa, razeni, nove, nove_rss, nazev, rewrite, popisek, href_id, href_class, href_akce, zobrazit) VALUES ('1', 'adresa', 'DESC', '1', '1', 'pokus', 'pokus', 'ksdkjfsdasd', '', '', '', '1');
