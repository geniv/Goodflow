
-------------------- table:random_gallery

CREATE TABLE random_gallery (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      popisek VARCHAR(300),
                                      url VARCHAR(200),
                                      datum DATETIME,
                                      w_mini INTEGER UNSIGNED,
                                      h_mini INTEGER UNSIGNED,
                                      w_full INTEGER UNSIGNED,
                                      h_full INTEGER UNSIGNED);

INSERT INTO random_gallery (id, adresa, popisek, url, datum, w_mini, h_mini, w_full, h_full) VALUES ('1', 'adresa', 'wow', '3896275429629532374__3_6_2009-18_09_35.jpg', '2009-06-03 17:13:01', '0', '0', '0', '0');
INSERT INTO random_gallery (id, adresa, popisek, url, datum, w_mini, h_mini, w_full, h_full) VALUES ('2', 'adresa', 'sfsgfsd', '28267591921418319__3_6_2009-23_31_28.jpg', '2009-06-03 23:31:10', '0', '123', '0', '400');
INSERT INTO random_gallery (id, adresa, popisek, url, datum, w_mini, h_mini, w_full, h_full) VALUES ('3', 'sdfsdfsdf', '', '13-06-2009-16-18-14.jpg', '2009-06-13 16:17:46', '160', '0', '0', '0');
INSERT INTO random_gallery (id, adresa, popisek, url, datum, w_mini, h_mini, w_full, h_full) VALUES ('4', 'adresa', '', '13-06-2009-16-44-08.jpg', '2009-06-13 16:29:47', '160', '0', '0', '0');
INSERT INTO random_gallery (id, adresa, popisek, url, datum, w_mini, h_mini, w_full, h_full) VALUES ('5', 'adresa', '', '13-06-2009-16-44-54.jpg', '2009-06-13 16:44:39', '160', '0', '0', '0');
INSERT INTO random_gallery (id, adresa, popisek, url, datum, w_mini, h_mini, w_full, h_full) VALUES ('6', 'adresa', '', '13-06-2009-16-46-31.jpg', '2009-06-13 16:45:21', '160', '0', '0', '0');
