
-------------------- table:obsah_eshop

CREATE TABLE obsah_eshop (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      nazev TEXT,
                                      vyrobce VARCHAR(200),
                                      popis TEXT,
                                      publikace DATE,
                                      kod VARCHAR(50),
                                      hmotnost FLOAT,
                                      dph FLOAT,
                                      cena FLOAT,
                                      obrazek VARCHAR(200),
                                      skladem INTEGER UNSIGNED);

INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('1', '1', 'fgs', '', 'fgsfgsdf', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('2', '1-5', 'sadf', '', 'AFADFASD', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('3', '1-5', 'sdfgfsg', '', 'sdfgfsg', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('4', '1-2', 'sgsfg', '', 'sgsfgfsg', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('5', '1-2', 'sdfgsfg', '', 'sdfgsdfg', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('6', '1-2', 'adsf', '', 'dsfdsf', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('7', '1-2-3', 'sadasd', '', 'asdasd', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('8', '1-2-3', 'sdad', '', 'asdasdasd', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('9', '1-2-3', 'aasfads', '', 'ffdhfgh', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('10', '1-2-3', 'fgjfghj', '', 'dfhjfghj', '2009-04-28 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('11', '6-7', 'yfdsf', '', 'dsfdsfsdfds', '2009-04-29 00:00:00', '', '0', '19', '0', '', '0');
INSERT INTO obsah_eshop (id, adresa, nazev, vyrobce, popis, publikace, kod, hmotnost, dph, cena, obrazek, skladem) VALUES ('12', '1-2-8', 'dfsfdsf', '', 'sdfdsfdsf', '2009-05-27 00:00:00', '', '0', '19', '0', '', '0');

-------------------- table:kosik

CREATE TABLE kosik (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      zakaznik INTEGER UNSIGNED,
                                      zbozi INTEGER UNSIGNED,
                                      pocet INTEGER UNSIGNED);


-------------------- table:zakaznik

CREATE TABLE zakaznik (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      session VARCHAR(100),
                                      expirace DATETIME,
                                      doprava INTEGER UNSIGNED);

