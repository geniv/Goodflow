
-------------------- table:jazyk

CREATE TABLE jazyk (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      jazyk VARCHAR(100),
                                      zkratka VARCHAR(10));

INSERT INTO jazyk (id, jazyk, zkratka) VALUES ('1', 'česky', 'cz');
INSERT INTO jazyk (id, jazyk, zkratka) VALUES ('2', 'usa', 'us');
