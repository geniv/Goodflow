
-------------------- table:dynamiccomment_komentare

CREATE TABLE `dynamiccomment_komentare` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `skupina` int(10) unsigned default NULL,
  `uzivatel` int(10) unsigned default NULL,
  `email` varchar(100) collate utf8_czech_ci default NULL,
  `www` varchar(500) collate utf8_czech_ci default NULL,
  `pridano` datetime default NULL,
  `zprava` text collate utf8_czech_ci,
  `hodnoceni` int(11) default NULL,
  `zanoreni` int(10) unsigned default NULL,
  `ip` varchar(50) collate utf8_czech_ci default NULL,
  `agent` varchar(300) collate utf8_czech_ci default NULL,
  `zobrazit` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;


-------------------- table:dynamiccomment_komentare_skupina

CREATE TABLE `dynamiccomment_komentare_skupina` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `adresa` text collate utf8_czech_ci,
  `razeni` varchar(50) collate utf8_czech_ci default NULL,
  `idcaptcha` int(10) unsigned default NULL,
  `popisek` text collate utf8_czech_ci,
  `href_id` varchar(200) collate utf8_czech_ci default NULL,
  `href_class` varchar(200) collate utf8_czech_ci default NULL,
  `href_akce` varchar(500) collate utf8_czech_ci default NULL,
  `zobrazit` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

