
-------------------- table:sekce

CREATE TABLE sekce (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      nadpis VARCHAR(200),
                                      nadpis_url VARCHAR(200),
                                      w_mini INTEGER UNSIGNED,
                                      h_mini INTEGER UNSIGNED,
                                      sloupce TEXT,
                                      defaultni TEXT,
                                      poznamka VARCHAR(300),
                                      sekce_id VARCHAR(200),
                                      sekce_class VARCHAR(200),
                                      sekce_akce VARCHAR(500),
                                      poradi INTEGER UNSIGNED);

INSERT INTO sekce (id, adresa, nadpis, nadpis_url, w_mini, h_mini, sloupce, defaultni, poznamka, sekce_id, sekce_class, sekce_akce, poradi) VALUES ('1', 'adresa', '', '', '0', '135', 'ju1|--|hu2|--|fff', 'ee|--|aaa|--|sdff', '', '', '', '', '1');

-------------------- table:polozka

CREATE TABLE polozka (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      sekce INTEGER UNSIGNED,
                                      radek TEXT,
                                      poradi INTEGER UNSIGNED,
                                      polozka_id VARCHAR(200),
                                      polozka_class VARCHAR(200),
                                      polozka_akce VARCHAR(200));

INSERT INTO polozka (id, sekce, radek, poradi, polozka_id, polozka_class, polozka_akce) VALUES ('1', '1', 'ee|--|aaa|--|sss!', '1', '', '', '');
