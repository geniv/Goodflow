<?php

/**
 *
 * Centralni funkce projektu
 *
 * public funkce:\n
 * construct: Funkce - hlavni konstruktor tridy\n
 * StartCas() - zacatek stopovani casu\n
 * KonecCas() - konec stopovani casu\n
 * ObsahStranek() - vkladani statickych nebo pevne danych stranek\n
 * OdkazZpet() - hypertextovy odkaz zpet\n
 * ZadnyZaznam() - hlaska zadny zaznam\n
 * ErrorMsg() - globalni vypis chybovych hlasek\n
 * AutoClick() - meta odkaz na auto presmerovani\n
 * TypOS() - zjisteni  typu OS\n
 * TypBrowseru() - zjisteni typu Browseru\n
 * ExistenceUrl() - kontrola existence url\n
 * NactiUrl() - stahne obsah url stranky do promenne\n
 * Velikost() - dle dane velikosti vrati prepocitanou jednotku\n
 * KontrolaEmailu() - kontrola emailu za pomoci regularnich vyrazu\n
 *
 * NactiFunkci() - nacte danou funkci z daneho modulu udaneho indexem, i s danym parametrem\n
 * AdminMenu() - odkaz na admin obsahu\n
 * AdminObsah() - obsah adminu\n
 *
 * GenerovaniAdminMenu() - generovani menu adminu\n
 * GenerovaniAdminObsah() - generovani obsahu adminu\n
 *
 */

class Funkce
{
  private $var;
  private $start, $konec;
  private $idmodul = "funkce";
  private $idzaloha = "zaloha";
  private $iddelzal = "delzal";
  private $idupp = "up";

  private $autozaloha = true; //true/false - aktualizace kazdy den

  private $zalohadir = "db";  //adresat zalohovani

/**
 *
 * Konstruktor funkce
 *
 * @param var pruchodova struktura
 * @param index prideleny index pri generovani
 *
 */
  public function __construct(&$var, $index) //konstruktor
  {
    $this->var = $var;

    //$this->Instalace();

    $this->Prihlasovani();

    $this->AutoZalohovani();
  }

/**
 *
 * Zavola danou funkc z daneho indexu tridy, dokaze zpracovat libovolne mnozstvi parametru
 *
 * @param index index funkce pro $this->var->main
 * @param funkce volana public funkce
 * @return obsah funkce
 */
  public function NactiFunkci($index, $funkce)
  {
    $paramatr = func_get_args();
    $pocet = func_num_args();
    $argv = array();
    if ($pocet > 2)
    {
      for ($i = 2, $j = 0; $i < $pocet; $i++, $j++)
      {
        $argv[$j] = $paramatr[$i];  //prevedeni parametru
      }
    }

    $result = "";
    if (method_exists($this->var->moduly[$index]["class"], $funkce))
    {
      $result = call_user_func_array(array($this->var->main[$index], $funkce), $argv);  //trida::funkce, parametry
    }
      else
    {
      $this->ErrorMsg("POZOR! U třídy:  ''{$this->var->moduly[$index]["class"]}'' neporařilo se načíst funkci: ''{$funkce}''!");
    }

    return $result;
  }

/**
 *
 * Administracni menu
 *
 * @return odkazy menu
 */
  public function AdminMenu()
  {
    $result =
    "
    <a href=\"?{$this->var->get_kam}={$this->var->adresaadminu}\" title=\"uvod adminu\">uvod adminu</a><br />
    <a href=\"?{$this->var->get_kam}={$this->var->adresaadminu}&amp;{$this->var->get_idmodul}={$this->idmodul}\" title=\"kontrola aktualizaci\">kontrola aktualizaci</a><br />
    <a href=\"?{$this->var->get_kam}={$this->var->adresaadminu}&amp;{$this->var->get_idmodul}={$this->idmodul}{$this->idzaloha}\" title=\"zaloha DB\" onclick=\"return confirm('Opravdu zalohovat databazi??');\">zaloha DB</a><br />
    ";

    return $result;
  }

/**
 *
 * Obsah adminu
 *
 * @return obsah adminu
 */
  public function AdminObsah()
  {
    if ($_GET[$this->var->get_kam] == $this->var->adresaadminu &&
        $this->var->aktivniadmin)
    {
      switch ($_GET[$this->var->get_idmodul])
      {
        case "":  //uvod adminu
          $result =
          "
            obsah uvod adminu<br />
            <br />
            výpis záloh databaze:<br />
            {$this->VypisZalohyDB()}
          ";
        break;

        case $this->idmodul:  //id modul
          $result = $this->KontrolaAktualizace();
        break;

        case "{$this->idmodul}{$this->idzaloha}": //zaloha
          $result = $this->ZalohovaniSQLiteDB();
        break;

        case "{$this->idmodul}{$this->iddelzal}": //smazani souboru zalohy
          $result = $this->SmazatSouborZalohy();
        break;

        case "{$this->idmodul}{$this->idupp}":
          $result = $this->UploadovatNovouVerzi();
        break;
      }
    }

    return $result;
  }

/**
 *
 * Kontroluje aktualizace na repozitu
 *
 * @return formular s aktualizacema
 */
  private function KontrolaAktualizace()
  {
    if ($this->var->aktualizovat)
    {
      $result = "";
      for ($i = 0; $i < count($this->var->moduly); $i++)
      {
        $nazev = $this->var->moduly[$i]["class"];
        $cesta = $this->var->moduly[$i]["include"];

        $soubor = basename($cesta); //soubor
        $adresar = dirname($cesta); //adresar
        $adresar = explode("/", $adresar);
        $adresar = (count($adresar) > 1 ? $adresar[1] : "kořen");

        if (file_exists($cesta))
        {
          $velikost = $this->Velikost(filesize($cesta));
          $datum = date("d.m. Y H:i:s", filemtime($cesta)); //datum na webu
        }
          else
        {
          $datum = "Chybná cesta v promenne.php";
        }

        $zprava = $this->NactiUrl("{$this->var->depozitar}?check={$cesta}");  //datum na depozitu s velikosti
        $zprava_velikost = explode("-_-", $zprava); //zozdeleni na datum a velikost

        $zprava_datum = $zprava_velikost[0];  //vraceni datumu zpravy
        $zprava_velikost = $zprava_velikost[1]; //vraceni velikosti

        $aktualni = "aktuální verze";
        $old = "novější verze na depozitu <a href=\"{$this->var->depozitar}?down={$cesta}\" title=\"sosnout\">sosnout</a> <a href=\"?{$this->var->get_kam}={$this->var->adresaadminu}&amp;{$this->var->get_idmodul}={$this->idmodul}{$this->idupp}&amp;file={$cesta}\" title=\"upnout\">upnout</a>";
        $new = "novější verze na tomto webu";

        if (!Empty($zprava_velikost))
        {
          $info = ($datum == $zprava_datum ? $aktualni :
                  ($datum < $zprava_datum ? $old :
                                            $new));
        }
          else
        {
          $info = "Dotyčná verze neni na depozitu prozatím vložena";
        }

        $result .=
        "<p>
          {$nazev} ([{$adresar}] - {$soubor}) - {$datum} ({$velikost}) || depozit: {$zprava_datum} ({$zprava_velikost}) - {$info}
        </p>";
      }
    }
      else
    {
      $result = "Aktualizace jsou vypnuty";
    }

    return $result;
  }

/**
 *
 * Upload nove verze modulu
 *
 * @return info o uploadovani
 */
  private function UploadovatNovouVerzi()
  {
    $soubor = $_GET["file"];
    chmod($soubor, 0777);
    chmod(dirname($soubor), 0777);

    $result =
    "
    <form method=\"post\" enctype=\"multipart/form-data\" onsubmit=\"return confirm('Opravdu aktualizovat tento modul: \'{$soubor}\' ??');\">
      <fieldset>
        modul (jen php): <input type=\"file\" name=\"modul\" /> <br />
        <input type=\"submit\" name=\"tlacitko\" value=\"Upgradovat\" />
      </fieldset>
    </form>
    ";

    $koncovka = explode(".", $_FILES["modul"]["name"]);

    if (!Empty($_FILES["modul"]["tmp_name"]) &&
        !Empty($_POST["tlacitko"]) &&
        !Empty($soubor) &&
        $_FILES["modul"]["name"] == basename($soubor) &&
        $koncovka[count($koncovka) - 1] == "php" &&
        file_exists($soubor) &&
        $soubor != "promenne.php" &&
        $soubor != "index.php" &&
        $soubor != ".htaccess")
    {
      if (move_uploaded_file($_FILES["modul"]["tmp_name"], $soubor))
      {
        $result = "modul: ''{$soubor}'' uspěšne aktualizován";

        $this->var->main[0]->AutoClick(2, "?{$this->var->get_kam}={$this->var->adresaadminu}&{$this->var->get_idmodul}={$this->idmodul}");  //auto kliknuti
      }
        else
      {
        $result = "Nastala chyba: ''{$_FILES["modul"]["error"]}''";
      }
    }
      else
    {
      if (!Empty($_FILES["modul"]["tmp_name"]))
      {
        if ($koncovka[count($koncovka) - 1] == "php")
        {
          $result = "Jiná koncovka";
        }

        if (file_exists($soubor))
        {
          $result = "Soubor neexistuje";
        }

        if ($soubor != "promenne.php" &&
            $soubor != ".htaccess")
        {
          $result = "Nepřípustné soubory";
        }

        if ($_FILES["modul"]["name"] == basename($soubor))
        {
          $result = "Nenahráváte kompatibilní soubor";
        }
      }
    }

    return $result;
  }

/**
 *
 * Vygenerovani menu adminu
 *
 * @return admin menu
 */
  public function GenerovaniAdminMenu()
  {
    $result = "";
    for ($i = 0; $i < count($this->var->moduly); $i++)
    {
      $result .= ($this->var->moduly[$i]["admin"] ? (method_exists($this->var->moduly[$i]["class"], "AdminMenu") ? $this->var->main[$i]->AdminMenu() : "Modul menu z třídy: ''{$this->var->moduly[$i]["class"]}'' se nepodařilo načíst, aktualizujte jej prosím<br />") : "");
    }

    $result .= "<a href=\"?{$this->var->get_kam}=logoff\">(log off)</a>";

    return $result;
  }

/**
 *
 * Vygenerovani obsahu adminu
 *
 * @return admin obsah
 */
  public function GenerovaniAdminObsah()
  {
    $result = "";
    for ($i = 0; $i < count($this->var->moduly); $i++)
    {
      $result .= ($this->var->moduly[$i]["admin"] ? (method_exists($this->var->moduly[$i]["class"], "AdminObsah") ? $this->var->main[$i]->AdminObsah() : "Modul obsahu z třídy: ''{$this->var->moduly[$i]["class"]}'' se nepodařilo načíst, aktualizujte jej prosím<br />") : "");
    }

    return $result;
  }

/**
 *
 * Zazalohovani sqlite databazi
 *
 * @return odkaz na zip soubor
 */
  private function ZalohovaniSQLiteDB($autodown = true)
  {
    $result = "";

    if (!file_exists($this->zalohadir))
    {
      mkdir($this->zalohadir, 0777);
    }
    $cil = "{$this->zalohadir}/zaloha_db_".date("d-m-Y_H-i-s").".zip";

    $zip = new ZipArchive();
    if ($zip->open($cil, ZipArchive::CREATE) === true)
    {
      for ($i = 0; $i < count($this->var->moduly); $i++)
      {
        if ($this->var->moduly[$i]["admin"])  //pokud ma modul dazaba
        {
          $databaze = dirname($this->var->moduly[$i]["include"])."/".$this->var->moduly[$i]["databaze"];
          if (file_exists($databaze))
          {
            $zip->addFile($databaze);  //ulozi i se stejnou cestou!!
          }
        }
      }
      $zip->close();
    }

    if ($autodown)
    {
      header("Content-Description: File Transfer");
      header("Content-Type: application/force-download");
      header("Content-Disposition: attachment; filename=\"{$cil}\"");
      $result = readfile($cil); //vybydne ke stazeni
    }

    return $result;
  }

/**
 *
 * Stara se o automatcke zalohovani
 *
 */
  private function AutoZalohovani()
  {
    if ($this->autozaloha)
    {
      $cesta = $this->zalohadir;
      if (file_exists($cesta))
      {
        $handle = opendir($cesta);
        $i = 0;
        while($soub = readdir($handle))
        {
          if ($soub != "." && $soub != ".." && filetype("{$cesta}/{$soub}") == "file")
          {
            if (date("Y-m-d") == date("Y-m-d", filemtime("{$cesta}/{$soub}")))
            {
              $i++;
            }
          }
        }
        closedir($handle);

        if ($i == 0)
        {
          $this->ZalohovaniSQLiteDB(false); //pri prazdne slozce
        }
      }
        else
      {
        mkdir($this->zalohadir, 0777);  //vytvoreni a prvotni zalohovani
        $this->ZalohovaniSQLiteDB(false);
      }
    }
  }

/**
 *
 * Vypise obsah adresare zalohy
 *
 * @return seznam souboru
 */
  private function VypisZalohyDB()
  {
    $result = "";
    $cesta = $this->zalohadir;
    if (file_exists($cesta))
    {
      $handle = opendir($cesta);
      $i = 0;
      while($soub = readdir($handle))
      {
        if ($soub != "." && $soub != ".." && filetype("{$cesta}/{$soub}") == "file")
        {
          $soubor[$i] = $soub;
          $i++;
        }
      }
      closedir($handle);

      if ($i == 0)
      {
        $result = "složka záloh je prázdná";
      }
        else
      {
        rsort($soubor);

        for ($i = 0; $i < count($soubor); $i++)
        {
          $result .=
          "
          <a href=\"{$cesta}/{$soubor[$i]}\" >{$soubor[$i]}</a> -
          <a href=\"?{$this->var->get_kam}={$this->var->adresaadminu}&amp;{$this->var->get_idmodul}={$this->idmodul}{$this->iddelzal}&amp;file={$soubor[$i]}\" onclick=\"return confirm('Opravdu smazat soubor: \'{$soubor[$i]}\' ??');\">smazat</a><br />
          ";
        }
      }
    }
      else
    {
      $result = "nenexistuje složka, musí se něco zálohovat a nebo vytvořt adresář: '{$cesta}'";
    }

    return $result;
  }

/**
 *
 * Smaze dany soubor ve slozce zalohy
 *
 * @return zprava o smazani
 */
  private function SmazatSouborZalohy()
  {
    $cesta = $_GET["file"];

    if (file_exists("{$this->zalohadir}/{$cesta}"))
    {
      $result = (unlink("{$this->zalohadir}/{$cesta}") ? "soubor: '{$cesta}' byl smazán" : "něco se pokazilo");

      $this->var->main[0]->AutoClick(1, "?{$this->var->get_kam}={$this->var->adresaadminu}");  //auto kliknuti
    }
      else
    {
      $result = "cesta neexistuje";

      $this->var->main[0]->AutoClick(1, "?{$this->var->get_kam}={$this->var->adresaadminu}");  //auto kliknuti
    }

    return $result;
  }

/**
 *
 * Funkce se pokusí stáhnout danou url stránku
 *
 * @param url www adresa
 * @return stranka v promenne
 */
  public function NactiUrl($url)
  {
    $url = str_replace("http://", "", $url);
    if (preg_match("#/#","{$url}"))
    {
      $page = $url;
      $url = @explode("/",$url);
      $url = $url[0];
      $page = str_replace($url,"",$page);
      if (!$page || $page == "")
      {
        $page = "/";
      }
      $ip = gethostbyname($url);
    }
      else
    {
      $ip = gethostbyname($url);
      $page = "/";
    }

    if ($open = @fsockopen($ip, 80, $errno, $errstr, 60))
    {
      $send .= "GET {$page} HTTP/1.0\r\n";
      $send .= "Host: {$url}\r\n";
      $send .= "Accept-Language: en-us, en;q=0.50\r\n";
      $send .= "User-Agent: {$_SERVER["HTTP_USER_AGENT"]}\r\n";
      $send .= "Connection: Close\r\n\r\n";

      fputs($open, $send);
      $return = "";
      while (!feof($open))
      {
        $return .= fgets($open, 4096);
      }
      fclose($open);

      $ret = @explode("\r\n\r\n", $return, 2);
      //$header = $ret[0]; //header
      $result = $ret[1]; //body
    }
      else
    {
      $this->var->main->ErrorMsg("připojení k portu 80, cislo: {$errno}, duvod: {$errstr}");
      $result = NULL;
    }

    return $result;
  }

/**
 *
 * Kontrola emailu pres regularni vyraz
 *
 * @param email text na zkontrolovani
 * @return je-li vyraz v poradku vrati jeho hodnotu
 */
  public function KontrolaEmailu($email)
  {
    $regular = "/^[_a-zA-Z0-9\.\-]+@[_a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,4}\$/";
    preg_match($regular, $email, $result);

    return $result;
  }

/**
 *
 * Kontroluje zda dana url adresa existuje
 *
 * @param url www adresa
 * @return true/false - existuje / neexistuje
 */
  public function ExistenceUrl($url)
  {
    if (!in_array($_SERVER["REMOTE_ADDR"], $this->var->ipblok))
    {
      $a = get_headers($url);
      $b = explode(" ", $a[0]);

      if ($b[1] == 200) //kdyz existuje je 200
      {
        $result = true;
      }
        else
      {
        $result = false;
      }
    }
      else
    {
      $result = true;
    }

    return $result;
  }

/**
 *
 * Provadi prihlaseni do adminu
 *
 */
  private function Prihlasovani()
  {
    if ($this->var->klenot)  //prepnuti pro ziskani dat z klenot
    {
      list($_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"]) = explode(":", base64_decode(substr($_SERVER["REDIRECT_REMOTE_USER"], 6)));
    }

    if ($_GET[$this->var->get_kam] == "logoff")
    {
      $_SERVER["PHP_AUTH_USER"] = "";
      $_SERVER["PHP_AUTH_PW"] = "";
      header("WWW-Authenticate: Basic realm=\"vychozi layout\"");
      header("HTTP/1.0 401 Unauthorized");
      $this->AutoClick(0, "./");
    }

    if ($_GET[$this->var->get_kam] == $this->var->adresaadminu)
    {
      if (!$this->Autorizace($_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"]))
      {
        header("WWW-Authenticate: Basic realm=\"vychozi layout\"");
        header("HTTP/1.0 401 Unauthorized");

        $this->var->aktivniadmin = false;
        $this->AutoClick(0, "./");
      }
        else
      {
        if ($this->Autorizace($_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"]))
        {
          $this->var->aktivniadmin = true;
        }
          else
        {
          $this->var->aktivniadmin = false;
        }
      }
    }
  }

/**
 *
 * Overeni hesla do administrace
 *
 * @param login: login admina
 * @param heslo: heslo admina
 * @return povoleno/zamitnuto - true/false
 */
  private function Autorizace($login, $heslo)
  {
    $result = ($this->var->adminpristup[$login] == md5(md5($heslo)) ? true : false);

    return $result;
  }

/**
 *
 * Vraceni odpocitavaneho casu pro vypocet delky provaden skryptu
 *
 * @return cas stopek v ms
 */
  private function MeritCas() //funkce pro vrácení času
  {
    $cas = explode(" ", microtime());
    $soucet = $cas[1] + $cas[0];

    return $soucet;
  }

/**
 *
 * Zacatek odpocitavani
 *
 */
  public function StartCas() //zapis začátku
  {
    $this->start = $this->MeritCas();
  }

/**
 *
 * Konec odpocitavani
 *
 * @return cas v sec.
 */
  public function KonecCas()
  {
    $this->konec = $this->MeritCas();
    $cas = Abs(Round(($this->konec - $this->start) * 10000) / 10000); //Abs, výpočet

    return $cas;
  }

/**
 *
 * Sesklada obsah pevne definovanych stranek
 *
 * @return seskladany obsad stranek
 */
  public function ObsahStranek()
  {
    $kam = $_GET[$this->var->get_kam];

    if (!Empty($kam))
    {
      if (file_exists("{$this->var->souborymenu}/{$kam}.php"))
      {
        $this->var->kam = $kam;
        $result = include_once "{$this->var->souborymenu}/{$this->var->kam}.php";
      }
        else
      {
        $result = $this->KontrolaDefaultu();
      }
    }
      else
    {
      $result = $this->KontrolaDefaultu();
    }

    if ($_GET[$this->var->get_kam] == $this->var->adresaadminu &&
        $this->var->aktivniadmin)
    {
      $result = "admin obsahu neni - každá stránka má indivduální<br />"; //pri zapnute adminstraci
    }

    return $result;
  }

/**
 *
 * Kontrluje zda existuje a vraci defaultni stranku
 *
 * @return defultni stranku nebo chybu
 */
  private function KontrolaDefaultu()
  {
    if (file_exists("{$this->var->souborymenu}/{$this->var->default}.php"))
    {
      $this->var->kam = $this->var->default;
      $result = include_once "{$this->var->souborymenu}/{$this->var->kam}.php";
    }
      else
    {
      $this->ErrorMsg("Stánka: '{$this->var->default}.php' neexistuje");
    }

    return $result;
  }

/**
 *
 * Prechod o pocet stranek zpet
 *
 * @param zpet pocet kroku koli ma udelat zpet
 * @return odkaz v html
 */
  public function OdkazZpet($text = "O úroveň nazpět", $zpet = 1) //vracec historie
  {
    $result = "<a href=\"javascript:history.back(-{$zpet});\">{$text}</a>";

    return $result;
  }

/**
 *
 * Funkce vraci text zadny zaznam pri tabulkovych vypisech
 *
 * @return text zadny zaznam
 */
  public function ZadnyZaznam()  //prazdne pole
  {
    $result = "<strong>žádná hodnota</strong>";

    return $result;
  }

/**
 *
 * Vypis chyby v html
 *
 * @param chyba text chyby
 * @return chyby interpretovana v html kodu
 */
  public function ErrorMsg($chyba)  //proecdura chybove hlasky
  {
    $this->var->chyba =
    "
<div id=\"centralni_chyba\">
  <p>
    Vyskytla se chyba:
  </p>
  <p>
    <strong>{$chyba}</strong>
  </p>
  {$this->OdkazZpet()}
</div>
    ";
  }

/**
 *
 * Meta refresh
 *
 * @param cas doba aktualizace
 * @param cesta cilova cesta presmerovani
 * @return prislusne nastaveny meta tag
 */
  public function AutoClick($cas, $cesta)  //auto kliknuti, procedura
  {
    $this->var->meta = "<meta http-equiv=\"refresh\" content=\"{$cas};URL={$cesta}\" />";
  }

/**
 *
 * Zjisteni a vypsani typu OS
 *
 * @param agent agent z $_SERVER["HTTP_USER_AGENT"]
 * @return typ OS
 */
  public function TypOS($agent)
  { //var_dump($_SERVER["HTTP_USER_AGENT"]);
    $OSList = array("Windows 3.11" => "/Win16/i",
                    "Windows 95" => "/(Windows.95)|(Win95)/i",
                    "Windows 98" => "/(Windows.98)|(Win98)/i",
                    "Windows 2000" => "/(Windows NT 5\.0)|(Windows 2000)/i",
                    "Windows XP" => "/(Windows NT 5\.1)|(Windows XP)/i",
                    "Windows XP x64" => "/((Windows NT 5\.2).*(Win64))|((Win64).*(Windows NT 5\.2))/i",
                    "Windows Server 2003" => "/Windows NT 5\.2/i",
                    "Windows Vista" => "/Windows NT 6\.0/i",
                    "Windows 7" => "/Windows NT 7\.0/i",
                    "Windows NT 4.0" => "/(Windows NT 4\.0)|(WinNT4\.0)|(WinNT)|(Windows NT)/i",
                    "Windows ME" => "/(Windows ME)|(Win 9x 4\.90)/i",
                    "Microsoft PocketPC" => "/((Windows CE).*(PPC))|((PPC).*(Windows CE))/i",
                    "Microsoft Smartphone" => "/((Windows CE).*(smartphone))|((smartphone).*(Windows CE))/i",
                    "Windows CE" => "/Windows CE/i",
                    "Mandrake Linux" => "/((Linux).*(Mandrake))|((Mandrake).*(Linux))/i",
                    "Mandriva Linux" => "/((Linux).*(Mandriva))|((Mandriva).*(Linux))/i",
                    "SuSE Linux" => "/((Linux).*(SuSE))|((SuSE).*(Linux))/i",
                    "Novell Linux" => "/((Linux).*(Novell))|((Novell).*(Linux))/i",
                    "Kubuntu Linux" => "/((Linux).*(Kubuntu))|((Kubuntu).*(Linux))/i",
                    "Xubuntu Linux" => "/((Linux).*(Xubuntu))|((Xubuntu).*(Linux))/i",
                    "Edubuntu Linux" => "/((Linux).*(Edubuntu))|((Edubuntu).*(Linux))/i",
                    "Ubuntu Linux" => "/((Linux).*(Ubuntu))|((Ubuntu).*(Linux))/i",
                    "Debian GNU/Linux" => "/((Linux).*(Debian))|((Debian).*(Linux))/i",
                    "RedHat Linux" => "/((Linux).*(Red ?Hat))|((Red ?Hat).*(Linux))/i",
                    "Gentoo Linux" => "/((Linux).*(Gentoo))|((Gentoo).*(Linux))/i",
                    "Fedora Linux" => "/((Linux).*(Fedora))|((Fedora).*(Linux))/i",
                    "MEPIS Linux" => "/((Linux).*(MEPIS))|((MEPIS).*(Linux))/i",
                    "Knoppix Linux" => "/((Linux).*(Knoppix))|((Knoppix).*(Linux))/i",
                    "Slackware Linux" => "/((Linux).*(Slackware))|((Slackware).*(Linux))/i",
                    "Xandros Linux" => "/((Linux).*(Xandros))|((Xandros).*(Linux))/i",
                    "Kanotix Linux" => "/((Linux).*(Kanotix))|((Kanotix).*(Linux))/i",
                    "Linux" => "/(Linux)|(X11)/i",
                    "FreeBSD" => "/Free/i",
                    "OpenBSD" => "/OpenBSD/i",
                    "NetBSD" => "/NetBSD/i",
                    "SGI IRIX" => "/IRIX/i",
                    "Sun OS" => "/SunOS/i",
                    "QNX" => "/QNX/i",
                    "BeOS" => "/BeOS/i",
                    "Mac OS X Leopard" => "/(Mac OS).*(Leopard)/i",
                    "Mac OS X" => "/(Mac OS X)/i",
                    "Mac OS" => "/(Mac_PowerPC)|(Macintosh)/i",
                    "OS/2" => "#OS/2#i",
                    "Qtopia" => "/QtEmbedded/i",
                    "Sharp Zaurus \\1" => "/Zaurus ([a-zA-Z0-9\.]+)/i",
                    "Zaurus" => "/Zaurus/i",
                    "Symbian OS" => "/Symbian/i",
                    "Sony Clie" => "#PalmOS/sony/model#i",
                    "Series \\1" => "/Series ([0-9]+)/i",
                    "Nokia \\1" => "/Nokia ([0-9]+)/i",
                    "Siemens \\1" => "/SIE-([a-zA-Z0-9]+)/i",
                    "Dopod \\1" => "/dopod([a-zA-Z0-9]+)/i",
                    "O2 XDA \\1" => "/o2 xda ([a-zA-Z0-9 ]+);/i",
                    "Samsung \\1" => "/SEC-([a-zA-Z0-9]+)/i",
                    "SonyEricsson \\1" => "/SonyEricsson ?([a-zA-Z0-9]+)/i",
                    "Nintendo Wii" => "/Wii/i",
                    "Bot" => "/(crawler)|(Mediapartners-Google)|(Jyxobot)|(morfeo.centrum.cz)|(Gigabot)|(ASAP-LynxViewer)|(ASAP-Web-Sniffer)|(EARTHCOM.info)|(Mozdex)|(SeznamBot)|(Speedy Spider)|(Yahoo! Slurp)|(ZACATEK_CZ_BOT)|(www.yacy.net)|(Googlebot)|(Openbot)|(MSNBot)|(del.icio.us-thumbnails)|(Exabot)|(findlinks)|(Bot,Robot,Spider)/i",
                    "Neznámý" => "/(.*)/");

    foreach($OSList as $os => $regexp)
    {
      preg_match($regexp, $agent, $matches);
      if (!Empty($matches))
      {
        for ($i = 0; $i <= count($matches); $i++)
        {
          $os = str_replace("\\{$i}", $matches[$i], $os);
        }
        break;
      }
    }

    return trim($os);
  }

/**
 *
 * Zjisteni a vypsani typu Browseru
 *
 * @param agent agent z $_SERVER["HTTP_USER_AGENT"]
 * @return typ Browseru
 */
  public function TypBrowseru($agent)
  {
    $BrowserList = array ("Internet Explorer \\1" => "#MSIE ([a-zA-Z0-9\.]+)#i",
                          "Mozilla Firefox \\2" => "#(Firefox|Phoenix|Firebird)/([a-zA-Z0-9\.]+)#i",
                          "Opera \\1" => "#Opera[ /]([a-zA-Z0-9\.]+)#i",
                          "Netscape \\1" => "#Netscape[0-9]?/([a-zA-Z0-9\.]+)#i",
                          "Safari \\1" => "#Safari/([a-zA-Z0-9\.]+)#i",
                          "Flock \\1" => "#Flock/([a-zA-Z0-9\.]+)#i",
                          "Epiphany \\1" => "#Epiphany/([a-zA-Z0-9\.]+)#i",
                          "Konqueror \\1" => "#Konqueror/([a-zA-Z0-9\.]+)#i",
                          "Maxthon \\1" => "#Maxthon ?([a-zA-Z0-9\.]+)?#i",
                          "K-Meleon \\1" => "#K-Meleon/([a-zA-Z0-9\.]+)#i",
                          "Lynx \\1" => "#Lynx/([a-zA-Z0-9\.]+)#i",
                          "Links \\1" => "#Links .{2}([a-zA-Z0-9\.]+)#i",
                          "ELinks \\3" => "#ELinks([/ ]|(.{2}))([a-zA-Z0-9\.]+)#i",
                          "Debian IceWeasel \\1" => "#(iceweasel)/([a-zA-Z0-9\.]+)#i",
                          "Mozilla SeaMonkey \\1" => "#(SeaMonkey)/([a-zA-Z0-9\.]+)#i",
                          "OmniWeb" => "#OmniWeb#i",
                          "Mozilla \\1" => "#^Mozilla/5\.0.*rv:([a-zA-Z0-9\.]+).*#i",
                          "Netscape Navigator \\1" => "#^Mozilla/([a-zA-Z0-9\.]+)#i",
                          "PHP" => "/PHP/i",
                          "SymbianOS \\1" => "#symbianos/([a-zA-Z0-9\.]+)#i",
                          "Avant Browser" => "/avantbrowser\.com/i",
                          "Camino \\1" => "#(Camino|Chimera)[ /]([a-zA-Z0-9\.]+)#i",
                          "Anonymouse" => "/anonymouse/i",
                          "Danger HipTop" => "/danger hiptop/i",
                          "W3M \\1" => "#w3m/([a-zA-Z0-9\.]+)#i",
                          "Shiira \\1" => "#Shiira[ /]([a-zA-Z0-9\.]+)#i",
                          "Dillo \\1" => "#Dillo[ /]([a-zA-Z0-9\.]+)#i",
                          "Openwave UP.Browser \\1" => "#UP.Browser/([a-zA-Z0-9\.]+)#i",
                          "DoCoMo \\1" => "#DoCoMo/(([a-zA-Z0-9\.]+)[/ ]([a-zA-Z0-9\.]+))#i",
                          "Unbranded Firefox \\1" => "#(bonecho)/([a-zA-Z0-9\.]+)#i",
                          "Kazehakase \\1" => "#Kazehakase/([a-zA-Z0-9\.]+)#i",
                          "Minimo \\1" => "#Minimo/([a-zA-Z0-9\.]+)#i",
                          "MultiZilla \\1" => "#MultiZilla/([a-zA-Z0-9\.]+)#i",
                          "Sony PSP \\2" => "/PSP \(PlayStation Portable\)\; ([a-zA-Z0-9\.]+)/i",
                          "Galeon \\1" => "#Galeon/([a-zA-Z0-9\.]+)#i",
                          "iCab \\1" => "#iCab/([a-zA-Z0-9\.]+)#i",
                          "NetPositive \\1" => "#NetPositive/([a-zA-Z0-9\.]+)#i",
                          "NetNewsWire \\1" => "#NetNewsWire/([a-zA-Z0-9\.]+)#i",
                          "Opera Mini \\1" => "#opera mini/([a-zA-Z0-9]+)#i",
                          "WebPro \\2" => "#WebPro(/([a-zA-Z0-9\.]+))?#i",
                          "Netfront \\1" => "#Netfront/([a-zA-Z0-9\.]+)#i",
                          "Xiino \\1" => "#Xiino/([a-zA-Z0-9\.]+)#i",
                          "Blackberry \\1" => "#Blackberry([0-9]+)?#i",
                          "Orange SPV \\1" => "#SPV ([0-9a-zA-Z\.]+)#i",
                          "LG \\1" => "#LGE-([a-zA-Z0-9]+)#i",
                          "Motorola \\1" => "#MOT-([a-zA-Z0-9]+)#i",
                          "Nokia \\1" => "#Nokia ?([0-9]+)#i",
                          "Nokia N-Gage" => "#NokiaN-Gage#i",
                          "Blazer \\1" => "#Blazer[ /]?([a-zA-Z0-9\.]*)#i",
                          "Siemens \\1" => "#SIE-([a-zA-Z0-9]+)#i",
                          "Samsung \\4" => "#((SEC-)|(SAMSUNG-))((S.H-[a-zA-Z0-9]+)|([a-zA-Z0-9]+))#i",
                          "SonyEricsson \\1" => "#SonyEricsson ?([a-zA-Z0-9]+)#i",
                          "J2ME/MIDP Browser" => "#(j2me|midp)#i",
                          "Neznámý" => "/(.*)/");

    foreach($BrowserList as $browser => $regexp)
    {
      if (preg_match($regexp, $agent, $matches))
      {
        if (!Empty($matches))
        {
          for ($i = 0; $i <= count($matches); $i++)
          {
            $browser = str_replace("\\{$i}", $matches[$i], $browser);
          }
        }
        break;
      }
    }

    return trim($browser);
  }

/**
 *
 * Stara se instalaci databaze
 *
 */
  private function Instalace()  //instalace databaze
  {
    //
  }

/**
 *
 * Prepocet velikosti
 *
 * @param size zmerena velikost
 * @return prepocitana velikost
 */
  public function Velikost($size)  //vypocet velikosti souboru
  {
    $symbol = array("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB");

    $exp = 0;
    $converted_value = 0;
    if ($size > 0)
    {
      $exp = floor(log($size) / log(1024));
      $converted_value = ($size / pow(1024, floor($exp)));
    }

    $result = sprintf("%.2f {$symbol[$exp]}", $converted_value);

    return $result;
  }
}
?>
