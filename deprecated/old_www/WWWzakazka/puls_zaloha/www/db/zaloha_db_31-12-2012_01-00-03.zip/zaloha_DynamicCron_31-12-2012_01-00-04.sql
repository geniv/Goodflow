
-------------------- table:cron

CREATE TABLE cron (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                modul VARCHAR(100),
                                funkce VARCHAR(100),
                                parametry TEXT,
                                popis TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('1', 'Funkce', 'CronAdminClearLog', '', 'Promazávání admin logu', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('2', 'Funkce', 'CronZalohovaniDatabaze', '', 'Zálohování databází', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('3', 'Funkce', 'CronKontolaZalohyDatabaze', '', 'Promazávání databází', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('4', 'Funkce', 'CronZalohovaniUnikatnich', '', 'Zálohování unikátních', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('5', 'Funkce', 'CronKontrolaUnikatnich', '', 'Promazávání unikátních', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('6', 'Funkce', 'CronKontrolaErrorLogu', '', 'Promazávání error logů', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('7', 'Funkce', 'CronGenerovaniCacheGrafu', '', 'Generování cache pro grafy', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('8', 'Funkce', 'CronKontrolaSessionLogu', '', 'Promazávání session logů', '2010-11-11 10:32:24', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('9', 'Funkce', 'CronKontrolaActionLogu', '', 'Promazávání action logů', '2010-11-11 10:32:24', '', '1');

-------------------- table:cron_log

CREATE TABLE cron_log (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                exectime VARCHAR(100),
                                datum DATETIME,
                                agent VARCHAR(300),
                                ip VARCHAR(50));

INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('688', '26.856', '2012-12-25 01:00:30', 'Wget/1.10.2', '91.207.189.101');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('689', '30.6608', '2012-12-26 01:00:34', 'Wget/1.10.2', '91.207.189.101');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('690', '51.479', '2012-12-27 01:01:14', 'Wget/1.10.2', '91.207.189.101');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('691', '22.3874', '2012-12-28 01:00:25', 'Wget/1.10.2', '91.207.189.101');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('692', '23.3182', '2012-12-29 01:00:26', 'Wget/1.10.2', '91.207.189.101');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('693', '26.3544', '2012-12-30 01:00:29', 'Wget/1.10.2', '91.207.189.101');
