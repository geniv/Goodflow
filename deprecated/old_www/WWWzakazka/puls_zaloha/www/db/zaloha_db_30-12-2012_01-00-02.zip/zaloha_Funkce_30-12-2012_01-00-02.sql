
-------------------- table:useradmin

CREATE TABLE useradmin (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                login VARCHAR(800),
                                loginlog VARCHAR(100),
                                heslo VARCHAR(100),
                                permission INTEGER UNSIGNED,
                                jmeno VARCHAR(800),
                                konfigurace TEXT,
                                superadmin BOOL,
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO useradmin (id, login, loginlog, heslo, permission, jmeno, konfigurace, superadmin, pridano, upraveno, aktivni) VALUES ('1', '2610-02760-03840-04500-0494', 'b651040117662c84bb35be7eec7c3239', 'f3ea02c0eeeb8be7062641b5095643ea', '2', '2060-02760-03980-04360-04900-03710-04390-04790-06520-011760-011870-012880-012830-01176', '', '0', '2011-02-15 17:23:01', '2011-06-15 17:08:05', '1');

-------------------- table:ipban

CREATE TABLE ipban (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                nazev VARCHAR(100),
                                typ VARCHAR(50),
                                login VARCHAR(100),
                                ip VARCHAR(50),
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO ipban (id, nazev, typ, login, ip, pridano, upraveno, aktivni) VALUES ('1', 'ban na idiota jirikovskeho', 'fullbanip', '', '89.190.46.238', '2011-03-19 11:59:15', '', '1');
INSERT INTO ipban (id, nazev, typ, login, ip, pridano, upraveno, aktivni) VALUES ('2', 'ban na idiota jirikovskeho', 'banip', '', '89.190.46.238', '2011-03-19 12:08:49', '', '1');

-------------------- table:adminlog

CREATE TABLE adminlog (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                login VARCHAR(100),
                                wrongpass VARCHAR(100),
                                datum DATETIME,
                                ip VARCHAR(50),
                                agent VARCHAR(300),
                                pocet INTEGER UNSIGNED,
                                language VARCHAR(100),
                                cookie TEXT,
                                get TEXT);


-------------------- table:moduly

CREATE TABLE moduly (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                include VARCHAR(500),
                                class VARCHAR(100),
                                admin BOOL,
                                databaze VARCHAR(100),
                                uloziste INTEGER UNSIGNED,
                                aktivni BOOL,
                                poradi INTEGER UNSIGNED,
                                pevneporadi INTEGER UNSIGNED);

INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('1', 'funkce.php', 'Funkce', '1', 'modules/.sqlite2', '1', '1', '1', '1');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('2', 'modules/dynamic_cron/dynamic_cron.php', 'DynamicCron', '1', '.dbdyncro.sqlite2', '1', '1', '2', '2');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('3', 'modules/dynamic_database/dynamic_database.php', 'DynamicDatabase', '1', '', '0', '1', '3', '3');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('4', 'modules/dynamic_config/dynamic_config.php', 'DynamicConfig', '1', '.dbdyncon.sqlite2', '1', '1', '4', '4');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('5', 'modules/dynamic_htaccess/dynamic_htaccess.php', 'DynamicHtaccess', '1', '.dbdynhta.sqlite2', '1', '1', '5', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('6', 'modules/static_menu/static_menu.php', 'StaticMenu', '0', '', '0', '1', '6', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('8', 'modules/dynamic_central/dynamic_central.php', 'DynamicCentral', '1', '.dbdyncen.sqlite2', '2', '1', '8', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('10', 'modules/dynamic_form/dynamicky_formular.php', 'DynamicForm', '1', '.dbdynfor.sqlite2', '1', '1', '10', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('11', 'modules/captcha_code/captcha.php', 'CaptchaCode', '1', '.dbcap.sqlite2', '1', '1', '11', '20');

-------------------- table:reporty

CREATE TABLE reporty (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                login VARCHAR(100),
                                email VARCHAR(200),
                                predmet VARCHAR(500),
                                message TEXT,
                                pridano DATETIME,
                                ip VARCHAR(50),
                                agent VARCHAR(300));


-------------------- table:permission

CREATE TABLE permission (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                nazev VARCHAR(100),
                                popis TEXT,
                                opravneni TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO permission (id, nazev, popis, opravneni, pridano, upraveno, aktivni) VALUES ('2', 'Administrátoři', '', 'DynamicCentral|-|dyncent__10|x||--x|x--|DynamicCentral|-|dyncent__10|x|addobsah|--x|x--|DynamicCentral|-|dyncent__10|x|delobsah|--x|x--|DynamicCentral|-|dyncent__10|x|editobsah|--x|x--|DynamicCentral|-|dyncent__10|x|updateobsah|--x|x--|DynamicCentral|-|dyncent__1|x||--x|x--|DynamicCentral|-|dyncent__1|x|addobsah|--x|x--|DynamicCentral|-|dyncent__1|x|delobsah|--x|x--|DynamicCentral|-|dyncent__1|x|editobsah|--x|x--|DynamicCentral|-|dyncent__1|x|updateobsah|--x|x--|DynamicCentral|-|dyncent__2|x||--x|x--|DynamicCentral|-|dyncent__2|x|addobsah|--x|x--|DynamicCentral|-|dyncent__2|x|delobsah|--x|x--|DynamicCentral|-|dyncent__2|x|editobsah|--x|x--|DynamicCentral|-|dyncent__2|x|updateobsah|--x|x--|DynamicCentral|-|dyncent__3|x||--x|x--|DynamicCentral|-|dyncent__3|x|addobsah|--x|x--|DynamicCentral|-|dyncent__3|x|delobsah|--x|x--|DynamicCentral|-|dyncent__3|x|editobsah|--x|x--|DynamicCentral|-|dyncent__3|x|updateobsah|--x|x--|DynamicCentral|-|dyncent__4|x||--x|x--|DynamicCentral|-|dyncent__4|x|addobsah|--x|x--|DynamicCentral|-|dyncent__4|x|delobsah|--x|x--|DynamicCentral|-|dyncent__4|x|editobsah|--x|x--|DynamicCentral|-|dyncent__4|x|updateobsah|--x|x--|DynamicCentral|-|dyncent__5|x||--x|x--|DynamicCentral|-|dyncent__5|x|editobsah|--x|x--|DynamicConfig|-|pattern__2|x||--x|x--|DynamicConfig|-|pattern__2|x|savevalue|--x|x--|DynamicConfig|-|pattern__3|x||--x|x--|DynamicConfig|-|pattern__3|x|savevalue|--x|x--|Funkce|-|funkce__useralllog|x||--x|x--|Funkce|-|funkce__usercurlog|x||--x|x--|Funkce|-|funkce_logoff|x||--x|x--|Funkce|-|funkce_userlog|x||--x|x--|Funkce|-|funkce|x||--x|x--|Funkce|-||x|', '2011-02-14 11:32:00', '2011-06-15 17:03:52', '1');
