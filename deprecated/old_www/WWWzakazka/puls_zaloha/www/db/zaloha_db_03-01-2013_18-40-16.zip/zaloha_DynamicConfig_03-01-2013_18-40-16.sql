
-------------------- table:sablona

CREATE TABLE sablona (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                adresa TEXT,
                                nazev VARCHAR(200),
                                popis TEXT,
                                poradi INTEGER UNSIGNED);

INSERT INTO sablona (id, adresa, nazev, popis, poradi) VALUES ('1', 'meta-informace', 'Meta informace', '', '1');
INSERT INTO sablona (id, adresa, nazev, popis, poradi) VALUES ('2', 'centralni-obsah', 'Centrální obsah', '', '2');
INSERT INTO sablona (id, adresa, nazev, popis, poradi) VALUES ('3', 'oteviraci-doba', 'Otevírací doba', '', '3');

-------------------- table:element

CREATE TABLE element (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                sablona INTEGER UNSIGNED,
                                adresa TEXT,
                                nazev VARCHAR(200),
                                typ VARCHAR(50),
                                konfigurace TEXT,
                                value TEXT,
                                zamek BOOL,
                                popis TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                poradi INTEGER UNSIGNED);

INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('1', '1', 'meta_author', 'Meta author', 'fulltext', '100|--xx--|200', 'GoodFlow design - Tvorba webových stránek a systémů (www.gfdesign.cz)', '0', '', '2010-11-11 12:08:04', '', '1');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('2', '1', 'meta_copyright', 'Meta copyright', 'fulltext', '100|--xx--|200', 'Created by GoodFlow design', '0', '', '2010-11-11 12:08:04', '', '2');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('3', '1', 'meta_keywords', 'Meta keywords', 'fulltext', '100|--xx--|200', 'studio puls, kadeřnictví, kosmetika, hairstyle, caffe, shop', '0', '', '2010-11-11 12:08:04', '', '3');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('4', '2', 'salon-puls-nadpis', 'Salon puls', 'header', '', '', '0', '', '2011-01-25 10:34:40', '', '1');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('5', '2', 'studio-puls-nadpis', 'Studio puls', 'header', '', '', '0', '', '2011-01-25 10:36:21', '', '8');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('6', '2', 'salon-pulsline-nadpis', 'Salon pulsline', 'header', '', '', '0', '', '2011-01-25 10:37:06', '', '15');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('7', '2', 'salon_puls_nazev', 'Název', 'minitext', '', '', '0', '', '2011-01-25 10:40:51', '', '2');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('8', '2', 'salon_puls_adresa_1', 'Adresa 1', 'minitext', '', '', '0', '', '2011-01-25 10:42:46', '', '3');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('9', '2', 'salon_puls_adresa_2', 'Adresa 2', 'minitext', '', '', '0', '', '2011-01-25 10:43:21', '', '4');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('10', '2', 'salon_puls_tel', 'Tel', 'minitext', '', '', '0', '', '2011-01-25 10:44:21', '', '5');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('11', '2', 'salon_puls_email', 'Email', 'minitext', '', '', '0', '', '2011-01-25 10:44:44', '', '6');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('12', '2', 'salon_puls_skype', 'Skype', 'minitext', '', '', '0', '', '2011-01-25 10:45:15', '', '7');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('13', '2', 'studio_puls_nazev', 'Název', 'minitext', '', 'Studio PULS', '0', '', '2011-01-25 10:47:11', '', '9');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('14', '2', 'studio_puls_adresa_1', 'Adresa 1', 'minitext', '', 'Smetanovo Nábřeží 7', '0', '', '2011-01-25 10:47:32', '', '10');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('15', '2', 'studio_puls_adresa_2', 'Adresa 2', 'minitext', '', '690 02 Břeclav', '0', '', '2011-01-25 10:47:59', '', '11');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('16', '2', 'studio_puls_tel', 'Tel', 'minitext', '', '530 330 717', '0', '', '2011-01-25 10:48:25', '', '12');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('17', '2', 'studio_puls_email', 'Email', 'minitext', '', 'studiopuls@seznam.cz', '0', '', '2011-01-25 10:48:45', '', '13');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('18', '2', 'studio_puls_skype', 'Skype', 'minitext', '', 'Salon PULS . Smetanovo Nábřeží', '0', '', '2011-01-25 10:49:08', '', '14');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('19', '2', 'salon_pulsline_nazev', 'Název', 'minitext', '', '', '0', '', '2011-01-25 10:52:03', '', '16');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('20', '2', 'salon_pulsline_adresa_1', 'Adresa 1', 'minitext', '', '', '0', '', '2011-01-25 10:52:21', '', '17');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('21', '2', 'salon_pulsline_adresa_2', 'Adresa 2', 'minitext', '', '', '0', '', '2011-01-25 10:52:43', '', '18');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('22', '2', 'salon_pulsline_tel', 'Tel', 'minitext', '', '', '0', '', '2011-01-25 10:53:02', '', '19');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('23', '2', 'salon_pulsline_email', 'Email', 'minitext', '', '', '0', '', '2011-01-25 10:53:25', '', '20');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('24', '2', 'salon_pulsline_skype', 'Skype', 'minitext', '', '', '0', '', '2011-01-25 10:54:08', '', '21');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('25', '2', 'kontakt-puls', 'Kontakt', 'header', '', '', '0', '', '2011-01-30 19:38:59', '', '22');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('26', '2', 'kontakt_text', 'Text', 'fulltext', '100|--xx--|300', 'Pokud máte dotaz, připomínku, stížnost, chcete nás pochválit nebo nějaký návrh na zlepšení chodu salonů Puls. Neváhejte a vyplňte formulář níže.', '0', '', '2011-01-30 19:39:36', '', '23');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('27', '3', 'salon_puls_oteviracka', 'Salon Puls', 'header', '', '', '0', '', '2011-02-09 16:30:00', '', '24');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('28', '3', 'salon_puls_pondeli', 'Pondělí', 'minitext', '', '', '0', '', '2011-02-09 16:35:28', '', '25');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('29', '3', 'salon_puls_utery', 'Úterý', 'minitext', '', '', '0', '', '2011-02-09 16:35:45', '2011-02-09 16:36:01', '26');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('30', '3', 'salon_puls_streda', 'Středa', 'minitext', '', '', '0', '', '2011-02-09 16:36:17', '', '27');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('31', '3', 'salon_puls_ctvrtek', 'Čtvrtek', 'minitext', '', '', '0', '', '2011-02-09 16:37:32', '', '28');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('32', '3', 'salon_puls_patek', 'Pátek', 'minitext', '', '', '0', '', '2011-02-09 16:37:45', '', '29');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('33', '3', 'salon_puls_sobota', 'Sobota', 'minitext', '', '', '0', '', '2011-02-09 16:37:58', '', '30');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('34', '3', 'salon_puls_nedele', 'Neděle', 'minitext', '', '', '0', '', '2011-02-09 16:38:12', '', '31');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('35', '3', 'studio_puls_oteviracka', 'Studio Puls', 'header', '', '', '0', '', '2011-02-09 16:39:53', '', '32');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('36', '3', 'studio_puls_pondeli', 'Pondělí', 'minitext', '', '9 - 17 hod', '0', '', '2011-02-09 16:40:09', '', '33');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('37', '3', 'studio_puls_utery', 'Úterý', 'minitext', '', '9 - 17 hod', '0', '', '2011-02-09 16:40:13', '', '34');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('38', '3', 'studio_puls_streda', 'Středa', 'minitext', '', '9 - 17 hod', '0', '', '2011-02-09 16:40:16', '', '35');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('39', '3', 'studio_puls_ctvrtek', 'Čtvrtek', 'minitext', '', '9 - 17 hod', '0', '', '2011-02-09 16:40:20', '', '36');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('40', '3', 'studio_puls_patek', 'Pátek', 'minitext', '', '9 - 17 hod', '0', '', '2011-02-09 16:40:27', '', '37');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('41', '3', 'studio_puls_sobota', 'Sobota', 'minitext', '', 'dle domluvy', '0', '', '2011-02-09 16:40:31', '', '38');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('42', '3', 'studio_puls_nedele', 'Neděle', 'minitext', '', 'zavřeno', '0', '', '2011-02-09 16:40:35', '', '39');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('43', '3', 'salon_pulsline_oteviracka', 'Salon Pulsline', 'header', '', '', '0', '', '2011-02-09 16:42:46', '', '40');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('44', '3', 'salon_pulsline_pondeli', 'Pondělí', 'minitext', '', '', '0', '', '2011-02-09 16:42:56', '', '41');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('45', '3', 'salon_pulsline_utery', 'Úterý', 'minitext', '', '', '0', '', '2011-02-09 16:42:59', '', '42');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('46', '3', 'salon_pulsline_streda', 'Středa', 'minitext', '', '', '0', '', '2011-02-09 16:43:03', '', '43');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('47', '3', 'salon_pulsline_ctvrtek', 'Čtvrtek', 'minitext', '', '', '0', '', '2011-02-09 16:43:06', '', '44');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('48', '3', 'salon_pulsline_patek', 'Pátek', 'minitext', '', '', '0', '', '2011-02-09 16:43:10', '', '45');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('49', '3', 'salon_pulsline_sobota', 'Sobota', 'minitext', '', '', '0', '', '2011-02-09 16:43:14', '', '46');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('50', '3', 'salon_pulsline_nedele', 'Neděle', 'minitext', '', '', '0', '', '2011-02-09 16:43:18', '', '47');
