
-------------------- table:captcha

CREATE TABLE captcha (
                                    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                    typ VARCHAR(50),
                                    otazka VARCHAR(500),
                                    pocet INTEGER UNSIGNED,
                                    x INTEGER UNSIGNED,
                                    y INTEGER UNSIGNED,
                                    width INTEGER UNSIGNED,
                                    height INTEGER UNSIGNED,
                                    font INTEGER UNSIGNED,
                                    font_size VARCHAR(20),
                                    roztec INTEGER UNSIGNED,
                                    font_color VARCHAR(20),
                                    background_color VARCHAR(10),
                                    rotace_pismen VARCHAR(20),
                                    mrizka VARCHAR(20),
                                    rand_dot BOOL,
                                    rand_line BOOL,
                                    rand_rectangle BOOL,
                                    rand_arc BOOL,
                                    rand_ellipse BOOL,
                                    rand_barva VARCHAR(20),
                                    rand_koeficient VARCHAR(20),
                                    url VARCHAR(200),
                                    vyrez_x INTEGER UNSIGNED,
                                    vyrez_y INTEGER UNSIGNED);

INSERT INTO captcha (id, typ, otazka, pocet, x, y, width, height, font, font_size, roztec, font_color, background_color, rotace_pismen, mrizka, rand_dot, rand_line, rand_rectangle, rand_arc, rand_ellipse, rand_barva, rand_koeficient, url, vyrez_x, vyrez_y) VALUES ('1', 'number', 'Zde opište obrázek', '4', '15', '35', '166', '47', '1', '24', '40', '#ffffff', '#2c2324', '0', '', '0', '0', '0', '0', '0', '#cccccc', '1', '', '0', '0');

-------------------- table:captcha_font

CREATE TABLE captcha_font (
                                    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                    nazev VARCHAR(100),
                                    url VARCHAR(300));

INSERT INTO captcha_font (id, nazev, url) VALUES ('1', 'dali___.ttf', '31-01-2011-08-57-15_dali___.ttf');
