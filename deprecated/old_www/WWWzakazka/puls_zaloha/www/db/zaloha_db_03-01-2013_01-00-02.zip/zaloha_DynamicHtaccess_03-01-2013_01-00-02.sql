
-------------------- table:htaccess

CREATE TABLE htaccess (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                rewrite TEXT,
                                popis TEXT,
                                aktivni BOOL,
                                pridano DATETIME,
                                upraveno DATETIME,
                                poradi INTEGER UNSIGNED);

INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('1', 'Options -Indexes', 'Zakazování zobrazení složek', '1', '', '', '1');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('2', 'ErrorDocument 400 http://127.0.0.1/layouty/puls/error_page/400.html', 'Error page 400', '1', '', '', '2');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('3', 'ErrorDocument 401 http://127.0.0.1/layouty/puls/error_page/401.html', 'Error page 401', '1', '', '', '3');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('4', 'ErrorDocument 403 http://127.0.0.1/layouty/puls/error_page/403.html', 'Error page 403', '1', '', '', '4');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('5', 'ErrorDocument 404 http://127.0.0.1/layouty/puls/error_page/404.html', 'Error page 404', '1', '', '', '5');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('6', 'ErrorDocument 500 http://127.0.0.1/layouty/puls/error_page/500.html', 'Error page 500', '1', '', '', '6');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('7', 'ErrorDocument 503 http://127.0.0.1/layouty/puls/error_page/503.html', 'Error page 503', '1', '', '', '7');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('8', 'AddHandler php5-cgi .php', 'Zapínání php5 na klenotu 1/2', '0', '', '', '8');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('9', 'Action php5-cgi /php5cgi/php', 'Zapínání php5 na klenotu 2/2', '0', '', '', '9');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('10', 'RewriteEngine on', 'Zapínání rewrite', '1', '', '', '10');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('11', 'RewriteBase /', 'Nasměrování kořenu', '1', '', '', '11');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('12', 'RewriteRule ^rss/([a-zA-Z-\_]+)/?$ ?action=rss&sablona=$1 [L]', 'Přepis pro RSS', '0', '', '', '12');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('13', 'RewriteRule ^([a-zA-Z0-9-\_]+)/([0-9]+)?$ ?action=$1&str=$2 [L]', 'Přepis pro stránkování', '0', '', '', '13');
INSERT INTO htaccess (id, rewrite, popis, aktivni, pridano, upraveno, poradi) VALUES ('14', 'RewriteRule ^([a-zA-Z0-9-\_]+)/?$ ?action=$1 [L]', 'Přepis pro sekce', '1', '', '', '14');
