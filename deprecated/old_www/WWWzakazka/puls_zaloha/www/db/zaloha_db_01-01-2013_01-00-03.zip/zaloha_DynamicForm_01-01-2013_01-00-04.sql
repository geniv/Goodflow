
-------------------- table:formular

CREATE TABLE formular (
                                    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                    adresa TEXT,
                                    nazev VARCHAR(200),
                                    predmet VARCHAR(200),
                                    email VARCHAR(100),
                                    textemail TEXT,
                                    dodatek TEXT,
                                    oznameni BOOL,
                                    predmetoznameni VARCHAR(200),
                                    textemailoznameni TEXT,
                                    zdrojovyemail VARCHAR(100),
                                    odesilateladmin VARCHAR(100),
                                    odesilateluzivatel VARCHAR(100));

INSERT INTO formular (id, adresa, nazev, predmet, email, textemail, dodatek, oznameni, predmetoznameni, textemailoznameni, zdrojovyemail, odesilateladmin, odesilateluzivatel) VALUES ('1', 'formular-kontakt', 'Kontakt', 'dotaz z studiopuls.cz', 'gfko@gfdesign.cz, studiopuls@studiopuls.cz', '&lt;br /&gt;
Zpráva ze stránek &lt;a href=&quot;@@1@@&quot;&gt;www.studiopuls.cz&lt;/a&gt;
&lt;br /&gt;&lt;br /&gt;
Údaje o odesílateli:
&lt;br /&gt;
IP: @@2@@
&lt;br /&gt;
Host: @@3@@
&lt;br /&gt;
Operační systém: @@4@@
&lt;br /&gt;
Prohlížeč: @@5@@
&lt;br /&gt;&lt;br /&gt;
Datum / čas odeslání zprávy: @@6@@
&lt;br /&gt;&lt;br /&gt;&lt;br /&gt;
@@7@@: @@8@@
&lt;br /&gt;
@@9@@: @@10@@
&lt;br /&gt;
@@11@@: @@12@@
&lt;br /&gt;', '', '0', '', '', 'elem_2', '', '');

-------------------- table:prvek

CREATE TABLE prvek (
                                    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                    formular INTEGER UNSIGNED,
                                    nazev VARCHAR(200),
                                    typ INTEGER UNSIGNED,
                                    value VARCHAR(200),
                                    readonly BOOL,
                                    disabled BOOL,
                                    povinne BOOL,
                                    reg_exp VARCHAR(500),
                                    vstupni_typ INTEGER UNSIGNED,
                                    min_val INTEGER UNSIGNED,
                                    max_val INTEGER UNSIGNED,
                                    poradi INTEGER UNSIGNED);

INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('1', '1', 'Jméno', '0', '', '0', '0', '1', '', '0', '0', '0', '1');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('2', '1', 'Email', '0', '', '0', '0', '1', '/^[_a-zA-Z0-9.-]+@[_a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$/', '2', '0', '0', '2');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('3', '1', '', '4', '1', '0', '0', '1', '', '0', '0', '0', '3');
INSERT INTO prvek (id, formular, nazev, typ, value, readonly, disabled, povinne, reg_exp, vstupni_typ, min_val, max_val, poradi) VALUES ('4', '1', 'Vaše zpráva', '0', '', '0', '0', '1', '', '0', '0', '0', '4');
