o spolecnosti
