prezentace
