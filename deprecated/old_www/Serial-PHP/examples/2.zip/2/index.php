<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <title>
      Web virtuální kapely
    </title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style type="text/css" title="text/css">  
    </style>
  </head>
  <?require "./func.php";?>
  <body>
  <div align="center">
    <table width="760" cellpadding="0" cellspacing="0" border="1">
      <tr>
        <td width="760" height="120" colspan="2"><img src="./images/top.jpg" width="760" height="120"></td>
      </tr>
      <tr>
        <td width="160" valign="top"><?require "./navigace.php"?></td>
        <td width="600" valign="top"><?ukazclanek()?></td>
      </tr>
    </table>
  </div>
  </body>
</html>

