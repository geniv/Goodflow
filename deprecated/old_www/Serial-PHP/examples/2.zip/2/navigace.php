<p><a href="index.php?clanek=uvod">Úvod</a></p>
<p><a href="index.php?clanek=koncerty">Koncerty</a></p>
<p><a href="index.php?clanek=diskografie">Diskografie</a></p>
<p><a href="index.php?clanek=login">Přihlásit</a></p>
<p><a href="index.php?clanek=registrace">Zaregistrovat</a></p>
