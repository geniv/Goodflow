<h1>Koncerty</h1>
<?
  $vysledek=mysql_query("select * from koncerty where datum >= curdate() order by datum",$GLOBALS["link"]);
  if (mysql_num_rows($vysledek)==0)
    echo "--  Není naplánován žádný koncert --";
  else
  {
    echo "<TABLE>";
    while ($zaznam=MySQL_Fetch_Array($vysledek)):
      ?>
      <TR>
        <TD><?echo ceskedatum($zaznam["datum"])?></TD>
        <TD><?echo substr($zaznam["cas"],0,strlen($zaznam["cas"])-3)?></TD>    
        <TD><?echo $zaznam["misto"]?></TD>    
      </TR>
      <?
    endwhile;
    echo "</TABLE>";
  }
?>

