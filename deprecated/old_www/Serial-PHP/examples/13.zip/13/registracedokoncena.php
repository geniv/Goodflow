<?
  $sifra= new Crypt_Xtea;  
  $citlive=$sifra->decrypt(base64_decode(urldecode($_GET["id"])),"T3dX?2.5du");
  $udaje=explode("|",$citlive);
  mysql_query("update uzivatele set registracedokoncena=1 where id=".$udaje[0]." and email='".$udaje[1]."';",$GLOBALS["link"]);
  if (mysql_affected_rows()==1) echo "Vaše registrace byla dokončena.";
  else echo "Příkaz nebyl proveden, zřejmě jsou nesprávné parametry nebo již registrace byla dokončena";
?>
