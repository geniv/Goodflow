<?
  function pisenid ($nazev)
  {
    $vysledek=mysql_query("select id from pisne where nazev='".$nazev."'", $GLOBALS["link"]);
    if (mysql_num_rows($vysledek)==0) 
      return 0; 
    else {
      $radek = mysql_fetch_array($vysledek);
      return $radek["id"];
    }
  }  

  function pisneok ($pisne)
  {
    $problem="";
    foreach ($pisne as $pisen)
    {
      if ((strlen ($pisen)>50) | strlen ($pisen)<3) $problem.="Název písně musí mít 3-50 znaků ($pisen)<BR>\n";
    }
    echo $problem;
    return (boolean)($problem==="");
  }
  
  function naplnseznam ($albapisne, $zvoleno=0)
  {
    $options="";
    $vysledek=mysql_query("select id, nazev from $albapisne order by nazev",$GLOBALS["link"]);
    while ($zaznam=MySQL_Fetch_Array($vysledek)):
      if ($zaznam["id"]==$zvoleno)
        $options.="<option value=\"".$zaznam["id"]."\" selected>".$zaznam["nazev"]."</option>\n";
      else  
        $options.="<option value=\"".$zaznam["id"]."\">".$zaznam["nazev"]."</option>\n";
    endwhile;
    return $options;
  }
    
  if (!jeadmin()) return;
  $BudemeZobrazovat=true;
  if (!empty($_POST)) // už se odeslalo
  {
    if ($_POST["odesli"]=="Přidat píseň")
      if ((strlen ($_POST["nazevpisne"])>50) | strlen ($_POST["nazevpisne"])<3) echo "Název písně musí mít 3-50 znaků";
      else
      {
        mysql_query ("insert into pisne (nazev) values ('".$_POST["nazevpisne"]."');", $GLOBALS["link"]);
        $chyba = mysql_error($GLOBALS["link"]);
        if ($chyba==='') $BudemeZobrazovat=false;
        else echo "Píseň NEBYLA přidána. Databáze vrátila chybu $chyba";  
      }
    elseif ($_POST["odesli"]=="Přidat album")
      if ((strlen ($_POST["nazevalba"])>50) | strlen ($_POST["nazevalba"])<3) echo "Název alba musí mít 3-50 znaků";
      else
      {
        mysql_query ("insert into alba (nazev) values ('".$_POST["nazevalba"]."');", $GLOBALS["link"]);
        $chyba = mysql_error($GLOBALS["link"]);
        if ($chyba==='') $BudemeZobrazovat=false;
        else echo "Album NEBYLO přidáno. Databáze vrátila chybu $chyba";  
      }
    elseif ($_POST["odesli"]=="Přidat píseň do alba")
    {
      mysql_query ("insert into obsahyalb (album, pisen) values (".$_POST["zaradit_album"].",".$_POST["zaradit_pisen"].");", $GLOBALS["link"]);
      $chyba = mysql_error($GLOBALS["link"]);
      if ($chyba==='') $BudemeZobrazovat=false;
      else echo "Píseň NEBYLA přidána do alba. Databáze vrátila chybu $chyba";      
    }
    elseif ($_POST["odesli"]=="Odebrat píseň z alba")
    {
      mysql_query ("delete from obsahyalb where album=".$_POST["zaradit_album"]." and pisen=".$_POST["zaradit_pisen"]." limit 1;", $GLOBALS["link"]);
      $chyba = mysql_error($GLOBALS["link"]);
      if ($chyba==='') $BudemeZobrazovat=false;
      else echo "Píseň NEBYLA odebrána z alba. Databáze vrátila chybu $chyba";
    }
    elseif ($_POST["odesli"]=="Přidat album s písněmi")
    {
      $_POST["nazvynovychpisni"]=ereg_replace("(\r\n)+", "\r\n", $_POST["nazvynovychpisni"]);
      $_POST["nazvynovychpisni"]=ereg_replace("(\r\n)$", "", $_POST["nazvynovychpisni"]);
      $pisne=explode("\r\n",$_POST["nazvynovychpisni"]);
      $_POST["nazvynovychpisni"]=strip_tags($_POST["nazvynovychpisni"]);
      if ((strlen ($_POST["nazevnovehoalba"])>50) | strlen ($_POST["nazevnovehoalba"])<3) echo "Název alba musí mít 3-50 znaků";
      elseif ($_POST["nazvynovychpisni"]=="") echo "Musíte zadat nějaké písně";
      elseif (strlen ($_POST["nazvynovychpisni"])>1500) echo "Máte zadáno příliš mnoho písní";
      elseif (count($pisne)>30) echo "Máte zadáno příliš mnoho písní";
      elseif (!pisneok($pisne)) echo "Opravte názvy písní";
      else
      {
        // pokusíme se přidat album
        mysql_query ("insert into alba (nazev) values ('".$_POST["nazevnovehoalba"]."');", $GLOBALS["link"]);
        $chyba = mysql_error($GLOBALS["link"]);
        if ($chyba==='') $albumid=mysql_insert_id();
        else echo "Album NEBYLO přidáno. Databáze vrátila chybu $chyba <BR>\n";
        // pokusíme se přidat písně
        if (isset($albumid))
        {
          foreach ($pisne as $pisen)
          {
            $pisenid=pisenid($pisen);
            if ($pisenid==0) 
            {
              mysql_query ("insert into pisne (nazev) values ('".$pisen."');", $GLOBALS["link"]);
              $pisenid=mysql_insert_id();
            }
            mysql_query ("insert into obsahyalb (album, pisen) values (".$albumid.",".$pisenid.");", $GLOBALS["link"]);      
          }
        }
        $BudemeZobrazovat=false;
      }
    }
  }
if ($BudemeZobrazovat):?>

  <form method="post" action="index.php?clanek=zadejdiskografii">
  <table>
    <tr>
      <td>Název nového alba:</td>
      <td><input name="nazevnovehoalba" value="<?echo $_POST["nazevnovehoalba"]?>"></td>
    </tr>
    <tr>
      <td>Názvy písní (každá na řádek):</td>    
      <td><textarea rows="20" name="nazvynovychpisni" cols="40"><?echo $_POST["nazvynovychpisni"]?></textarea></td>
    </tr>
    <tr>
      <td colspan="2" align="right"><input type="Submit" name="odesli" value="Přidat album s písněmi"></td>
    </tr>
  </table>
  </form>
  <hr>
  
  <form method="post" action="index.php?clanek=zadejdiskografii">
  <table>
    <tr>
      <td>Název písně:</td>
      <td><input name="nazevpisne" value="<?echo $_POST["nazevpisne"]?>"></td>
      <td><input type="Submit" name="odesli" value="Přidat píseň"></td>
    </tr>
  </table>
  </form>
  <hr>
  
  <form method="post" action="index.php?clanek=zadejdiskografii">
  <table>
    <tr>
      <td>Název alba:</td>
      <td><input name="nazevalba" value="<?echo $_POST["nazevalba"]?>"></td>
      <td><input type="Submit" name="odesli" value="Přidat album"></td>
    </tr>
  </table>
  </form>
  <hr>
  <form method="post" action="index.php?clanek=zadejdiskografii">
  <table>
    <tr>
      <td>Název alba:</td>
      <td>Název písně:</td>
    </tr>
    <tr>
      <td>
        <select name="zaradit_album"><?echo naplnseznam("alba",$_POST["zaradit_album"])?></select>
      </td>
      <td>
        <select name="zaradit_pisen"><?echo naplnseznam("pisne",$_POST["zaradit_pisen"])?></select>
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="Submit" name="odesli" value="Přidat píseň do alba">&nbsp;
        <input type="Submit" name="odesli" value="Odebrat píseň z alba">
      </td>
    </tr>
  </table>
  </form>
<?else:?>  
  <p>Změna byla zapsána. <a href="index.php?clanek=zadejdiskografii">Zadat diskografii</a></p>
<?endif;?>

