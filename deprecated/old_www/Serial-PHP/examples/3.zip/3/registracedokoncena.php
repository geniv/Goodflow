<?
  $link=mysql_connect(SQL_HOST, SQL_USERNAME, SQL_PASSWORD);
  mysql_select_db(SQL_DBNAME);
  mysql_query("update uzivatele set registracedokoncena=1 where id=".$_GET["id"]." and email='".$_GET["email"]."';");
  echo "Vaše registrace byla dokončena."
?>

