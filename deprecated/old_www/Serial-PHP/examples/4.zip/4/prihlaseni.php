<?  
  $BudemeZobrazovat=true;
  if (!empty($_POST)) // už se odeslalo
  {
    if (!isset($_SESSION["id"])) 
    {
      echo "Uživatelské jméno a/nebo heslo nesouhlasí ";
      echo "(<a href=\"index.php?clanek=zapomenuteheslo\">připomenout heslo</a>)";
    }
    else 
    {
      $BudemeZobrazovat=false;
      echo "Přihlášen ".$_POST["prezdivka"];
    }  
  }
if ($BudemeZobrazovat):?>
  <form method="post" action="index.php?clanek=prihlaseni">
  <table>
    <tr>
      <td>Přezdívka:</td>
      <td><input name="prezdivka" value="<?echo $_POST["prezdivka"]?>"></td>
    </tr>
      <td>Heslo:</td>
      <td><input name="heslo" type = "password" value="<?echo $_POST["heslo"]?>"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="Submit" name="odesli" value="Přihlásit"></td>
    </tr>
  </table>
  </form>
<?endif;?>
