<?
  // tělo skriptu - nejprve si vytvoříme odkaz na databázi
  $link=mysql_connect(SQL_HOST, SQL_USERNAME, SQL_PASSWORD);
  mysql_select_db(SQL_DBNAME);
  
  $BudemeZobrazovat=true;
  if (!empty($_POST)) // už se odeslalo
  {
    if ((strlen ($_POST["heslo"])>50) | strlen ($_POST["heslo"])<3) echo "Heslo musí mít 3-50 znaků";
    else
    {
      // kontolou jsme prošli
      $BudemeZobrazovat=false;
      // poděkujeme uživateli
      echo "Vaše heslo bylo změněno";
      // uložíme změny do databáze
      if (isset($_SESSION["id"])) mysql_query ("update uzivatele set heslo = '".$_POST["heslo"]."' where id=".$_SESSION["id"].";", $link);
    }
  }
if ($BudemeZobrazovat):?>
  <form method="post" action="index.php?clanek=zmenahesla">
  <table>
    <tr>
      <td>Nové heslo:</td>
      <td><input name="heslo" type = "password" value="<?echo $_POST["heslo"]?>"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="Submit" name="odesli" value="Změnit heslo"></td>
    </tr>
  </table>
  </form>
<?endif;?>
