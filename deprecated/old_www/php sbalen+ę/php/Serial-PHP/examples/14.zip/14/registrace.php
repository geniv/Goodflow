<?
  function JeEmail ($cislo)
  {
    return ereg("^.+@.+\..+$",$cislo);
  }

  function emailvdb ($email)
  {
    $vysledek=mysql_query("select * from uzivatele where email='".$email."'", $GLOBALS["link"]);
    return (boolean) mysql_num_rows($vysledek);
  }  

  function prezdivkavdb ($prezdivka)
  {
    $vysledek=mysql_query("select * from uzivatele where prezdivka='".$prezdivka."'", $GLOBALS["link"]);
    return (boolean) mysql_num_rows($vysledek);
  }  
  
  $BudemeZobrazovat=true;
  if (!empty($_POST)) // už se odeslalo
  {
    /*
    budeme kontrolovat následující věci:
    1) e-mailovou adresu
    2) zda tam již e-mail není
    3) zda tam již přezdívka není
    4) zda je přezdívka mezi 3 a 50 znaky délky
    5) zda je heslo 3 až 50 znaků dlouhé
    */
    if (!JeEmail($_POST["email"])) echo "Není zadán platný e-mail";
    elseif (emailvdb($_POST["email"])) echo "Uvedený e-mail je již registrován";
    elseif (prezdivkavdb ($_POST["prezdivka"])) 
    {
      echo "Uvedená přezdívka je již registrována ";
      echo "(<a href=\"index.php?clanek=zapomenuteheslo\">připomenout heslo</a>)";
    }
    elseif ((strlen ($_POST["prezdivka"])>50) | strlen ($_POST["prezdivka"])<3)echo "Přezdívka musí mít 3-50 znaků";
    elseif ((strlen ($_POST["heslo"])>50) | strlen ($_POST["heslo"])<3) echo "Heslo musí mít 3-50 znaků";
    else
    {
      // kontolou jsme prošli
      $BudemeZobrazovat=false;
      // poděkujeme uživateli
      echo "Děkujeme za registraci. Na vaši adresu ".$_POST["email"]." byly zaslány informace pro její dokončení.";
      // uložíme to do databáze
      mysql_query ("insert into uzivatele (email, prezdivka, heslo) values ('".$_POST["email"]."', '".$_POST["prezdivka"]."', '".$_POST["heslo"]."');", $GLOBALS["link"]);
      $lastid=mysql_insert_id();
      // a sestavíme e-mail s instrukcemi, jak registraci dokončí
      $sifra= new Crypt_Xtea;
      $citlive=$lastid."|".$_POST["email"];
      $citlive=urlencode(base64_encode($sifra->encrypt((string)$citlive, "T3dX?2.5du")));
      $path="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["SCRIPT_NAME"]."?clanek=registracedokoncena&amp;id=".$citlive;
      $telo = "Dekujeme Vam za registraci na nasem portale [nazev hudebniho portalu]. Pro dokonceni ".
      "registrace navstivte nasledujici odkaz\n\n$path\n\n".
      "Pokud jste se na nasem portale nechteli zaregistrovat, povazujte tento e-mail za bezpredmetny.\n".
      "Vas [nazev hudebniho portalu] team.";
      @mail ($_POST["email"], "Registrace na portalu", $telo);
    }
  }
if ($BudemeZobrazovat):?>
  <form method="post" action="index.php?clanek=registrace">
  <table>
    <tr>
      <td>Přezdívka:</td>
      <td><input name="prezdivka" value="<?echo $_POST["prezdivka"]?>"></td>
    </tr>
    <tr>
      <td>E-mail:</td>
      <td><input name="email" value="<?echo $_POST["email"]?>"></td>
    </tr>
    <tr>
      <td>Heslo:</td>
      <td><input name="heslo" type = "password" value="<?echo $_POST["heslo"]?>"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="Submit" name="odesli" value="Zaregistrovat"></td>
    </tr>
  </table>
  </form>
<?endif;?>
