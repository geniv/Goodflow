<?
echo "<BR>Litujeme, ale požadovaný dokument ".$nazevclanku." nebyl na serveru nalezen.";
?>
