<?

include "../../includes/config.php";

$GLOBALS["link"]=mysql_connect(SQL_HOST, SQL_USERNAME, SQL_PASSWORD);
mysql_select_db(SQL_DBNAME);

function ukazclanek ()
{ 
  if ((string)$_REQUEST["clanek"]<>'') $mujclanek=$_REQUEST["clanek"]; else $mujclanek="uvod";
  if (is_file("./".$mujclanek.".htm")):
    $nazevclanku=$mujclanek.".htm";
    require $nazevclanku;
  elseif (is_file("./".$mujclanek.".php")):
    $nazevclanku=$mujclanek.".php";
    require $nazevclanku;
  else:
    $nazevclanku=$mujclanek.".htm";
    require "notfound.php";
  endif;
}

function iduzivatele ($prezdivka, $heslo)
{
  $vysledek=mysql_query("select id from uzivatele where registracedokoncena=1 and prezdivka='".$prezdivka."' and heslo='".$heslo."'", $GLOBALS["link"]);
  if (mysql_num_rows($vysledek)==0) 
    return false; 
  else {
    $radek = mysql_fetch_array($vysledek);
    return $radek["id"];
  }
}  

function jeadmin ()
{
  if (!isset($_SESSION["id"])) return false;
  $vysledek=mysql_query("select id from uzivatele where id=".$_SESSION["id"]." and jeadmin=1", $GLOBALS["link"]);
  return (boolean) mysql_num_rows($vysledek);
}  

?>