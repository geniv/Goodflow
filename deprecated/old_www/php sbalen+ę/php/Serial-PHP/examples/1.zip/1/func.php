<?
function ukazclanek ()
{ 
  if ((string)$_REQUEST["clanek"]<>'') $mujclanek=$_REQUEST["clanek"]; else $mujclanek="uvod";
  if (is_file("./".$mujclanek.".htm")):
    $nazevclanku=$mujclanek.".htm";
    require $nazevclanku;
  elseif (is_file("./".$mujclanek.".php")):
    $nazevclanku=$mujclanek.".php";
    require $nazevclanku;
  else:
    $nazevclanku=$mujclanek.".htm";
    require "notfound.php";
  endif;
}
?>

