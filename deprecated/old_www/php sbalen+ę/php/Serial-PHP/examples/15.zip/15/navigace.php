<p><a href="index.php?clanek=uvod">Úvod</a></p>
<p><a href="index.php?clanek=koncerty">Koncerty</a></p>
<p><a href="index.php?clanek=diskografie">Diskografie</a></p>
<?if (isset($_SESSION["id"])):?>
<p><a href="index.php?clanek=zmenahesla">Změnit heslo</a></p>
<p><a href="index.php?clanek=odhlaseni">Odhlásit</a></p>
<p><a href="index.php?clanek=zruseniregistracedotaz">Zrušit registraci</a></p>
<?else:?>
<p><a href="index.php?clanek=prihlaseni">Přihlásit</a></p>
<?endif?>
<p><a href="index.php?clanek=registrace">Zaregistrovat</a></p>
