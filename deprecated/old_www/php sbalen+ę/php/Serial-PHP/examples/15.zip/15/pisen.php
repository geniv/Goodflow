<?
if (!jeprihlasen()) return;
if (!is_numeric($_REQUEST["pisen"])) return;
$vysledek=mysql_query("select pisne.nazev, texty.textpisne from pisne inner join texty on pisne.id=texty.pisen where pisne.id=".$_REQUEST["pisen"],$GLOBALS["link"]);
if (mysql_num_rows($vysledek)==0) echo "Tato píseň není v databázi, nebo k ní není zadán text";
else
{
  $zaznam=MySQL_Fetch_Array($vysledek);
  echo "<h1>".$zaznam["nazev"]."</h1>";
  echo "<pre>".$zaznam["textpisne"]."</pre>";
  echo "<a href=\"index.php?clanek=stahnipisen&amp;pisen=".$_REQUEST["pisen"]."\">Stáhnout píseň</a>";
} 
?> 
