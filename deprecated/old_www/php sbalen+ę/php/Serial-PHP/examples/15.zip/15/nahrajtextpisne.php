<?
  function naplnseznam ($zvoleno)
  {
    $vysledek=mysql_query("select pisne.id, pisne.nazev from pisne left join texty on pisne.id = texty.pisen where texty.pisen is null order by nazev",$GLOBALS["link"]);
    while ($zaznam=MySQL_Fetch_Array($vysledek)):
      if ($zaznam["id"]==$zvoleno)
        $options.="<option value=\"".$zaznam["id"]."\" selected>".$zaznam["nazev"]."</option>\n";
      else  
        $options.="<option value=\"".$zaznam["id"]."\">".$zaznam["nazev"]."</option>\n";
    endwhile;
    return $options;
  }

  if (!jeadmin()) return;



if ($_REQUEST["odeslano"]==1):
  @unlink ("./textpisne.txt");
  // kontroly...
  if (move_uploaded_file($_FILES['textpisne']['tmp_name'], "./textpisne.txt"))
  {
    $velikost=filesize("./textpisne.txt");
    if ($velikost==0 or $velikost>20000) echo "Nesprávná délka souboru.";
    else
    {
      $fp = fopen("./textpisne.txt", "r"); 
      $textpisne = addslashes(fread($fp, $velikost)); 
      mysql_query("insert into texty (pisen, textpisne) values (".$_POST["pisen"].", '".$textpisne."');",$GLOBALS["link"]);
      if (mysql_affected_rows()==1) echo "Text písně byl uložen."; else echo "Text písně nebyl uložen. Databáze vrátila chybu: ".mysql_error();
    }
  }
  else
  {
    echo "Soubor se nepodařilo nahrát na server.";
  };
  @unlink ("./textpisne.txt");
else:
?>
    <H1>Nahrání souboru na server</H1>
    <form method="POST" ENCTYPE="multipart/form-data" action="index.php?clanek=nahrajtextpisne">
    <table border="1" >
      <tr>
        <td>Píseň:</td>
        <td colspan="2">
        <select name="pisen"><?echo naplnseznam($_POST["pisen"])?></select>
        </td>
      </tr>

      <tr>
        <td>Text písně:</td>
        <td>
        <input type="HIDDEN" name="MAX_FILE_SIZE" VALUE=20000>
        <input type="file" name="textpisne" ACCEPT="text/*">
        </td>
        <td>(max. 20kB, UTF-8)</td>
      </tr>
      <tr>
        <td colspan="3">
              <input type="hidden" name="odeslano" value="1">
          <p align="center"><input type="submit" value="Odeslat"></td>
      </tr>
    </table>
    </form>
<?
endif;
?> 
