<?
  function idzPrezdivkyNeboEmailu ($udaj)
  {
    /* ověří, zda zaslaný údaj může být existující přezdívka nebo existující e-mail
       v tabulce uživatelů. Vrátí false, pokud se nic nenašlo, v opačném případě
       vrátí ID uživatele s daným mailem nebo přezdívkou
    */
    if (strpos($udaj,"@")===false) //začneme prohledávat přezdívky
    {
      $vysledek=mysql_query("select id from uzivatele where registracedokoncena=1 and prezdivka='".$udaj."'", $GLOBALS["link"]);
      if (mysql_num_rows($vysledek)==0) 
        return false; 
      else 
      {
        $radek = mysql_fetch_array($vysledek);
        return $radek["id"];
      }
    }
    else //je tam zavináč, začneme prohledávat e-mailové adresy
    {
      $vysledek=mysql_query("select id from uzivatele where registracedokoncena=1 and email='".$udaj."'",$GLOBALS["link"]);
      if (mysql_num_rows($vysledek)==0) 
      {
        // nevzdáme to. Konec konců, zavináč může být i v přezdívce
        $vysledek=mysql_query("select id from uzivatele where registracedokoncena=1 and prezdivka='".$udaj."'", $GLOBALS["link"]);
        if (mysql_num_rows($vysledek)==0) 
          return false; 
        else 
        {
          $radek = mysql_fetch_array($vysledek);
          return $radek["id"];
        }              
      }
      else 
      {
        $radek = mysql_fetch_array($vysledek);
        return $radek["id"];
      }
    }
  }  
  
  function emailzid ($id)
  {
    $vysledek=mysql_query("select email from uzivatele where id=".$id, $GLOBALS["link"]);
    $radek = mysql_fetch_array($vysledek);
    return $radek["email"];    
  }

  function heslozid ($id)
  {
    $vysledek=mysql_query("select heslo from uzivatele where id=".$id, $GLOBALS["link"]);
    $radek = mysql_fetch_array($vysledek);
    return $radek["heslo"];    
  }

  function pripomenutozid ($id)
  {
    $vysledek=mysql_query("select unix_timestamp(now()) - unix_timestamp(pripomenuto) from uzivatele where id=".$id, $GLOBALS["link"]);
    $radek = mysql_fetch_array($vysledek);
    return $radek[0];    
  }
  
  $BudemeZobrazovat=true;
  if (!empty($_POST)) // už se odeslalo
  {
    //údaj pro připomenutí nesmí být prázdný
    if ((strlen ($_POST["udaj"])>50) | strlen ($_POST["udaj"])<3)echo "Údaj musí mít 3-50 znaků";
    else
    {
      // kontolou jsme prošli
      $BudemeZobrazovat=false;
      $id=idzPrezdivkyNeboEmailu($_POST["udaj"]);
      if (!$id) echo "Bohužel, takový e-mail ani přezdívka neexistují";
      else
      {
        // zjistíme si e-mail
        $email = emailzid($id);
        $pripomenuto = pripomenutozid($id);
        if (is_null($pripomenuto) | ($pripomenuto/60/60/24>1))
        {        
          echo "Na adresu vyplněnou při registraci bylo zasláno přístupové heslo.";
          // uložíme do databáze čas připomenutí
          mysql_query ("update uzivatele set pripomenuto = now() where id=".$id, $GLOBALS["link"]);
          // a sestavíme e-mail se zapomenutým heslem
          $telo = "Pozadovane pristupove heslo na testovaci hudebni portal je \n".heslozid($id)."\n".
          "Vas [nazev hudebniho portalu] team.";
          @mail ($email, "Zaslani hesla", $telo);
        }
        else
        {
          echo "Nedávno jsme Vám již zaslali zapomenuté heslo. Zkontrolujte svou schránku.";
        }
      }
    }
  }
if ($BudemeZobrazovat):?>
  <form method="post" action="index.php?clanek=zapomenuteheslo">
  <table>
    <tr>
      <td colspan="2">Zadejte svou přezdívku nebo e-mail:</td>
    </tr>
    <tr>
      <td>Přezdívka nebo e-mail:</td>
      <td><input name="udaj" value="<?echo $_POST["udaj"]?>"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="Submit" name="odesli" value="Poslat heslo"></td>
    </tr>
  </table>
  </form>
<?endif;?>
