<p>Opravdu chcete zrušit svou registraci na tomto portále? Pokud to provedete, budete odhlášen
a informace související s Vašim účtem budou odstraněny. Můžete se samozřejmě kdykoli opět registrovat. </p>
<p>Chcete-li opravdu zrušit svou registraci, klepněte <a href="index.php?clanek=zruseniregistrace">sem</a>.</p>
