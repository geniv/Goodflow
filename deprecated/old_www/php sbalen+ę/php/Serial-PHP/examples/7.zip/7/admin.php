<?
  if (!jeadmin()) return;
  echo "Administrátor: ";
  echo "<a href=\"index.php?clanek=zadejkoncert\">Zadat koncert</a>";
?>

