<?
  mysql_query("update uzivatele set registracedokoncena=1 where id=".$_GET["id"]." and email='".$_GET["email"]."';",$GLOBALS["link"]);
  echo "Vaše registrace byla dokončena."
?>



