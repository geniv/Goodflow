<?
  function naplnseznam ($albapisne, $zvoleno=0)
  {
    $options="";
    $vysledek=mysql_query("select id, nazev from $albapisne order by nazev",$GLOBALS["link"]);
    while ($zaznam=MySQL_Fetch_Array($vysledek)):
      if ($zaznam["id"]==$zvoleno)
        $options.="<option value=\"".$zaznam["id"]."\" selected>".$zaznam["nazev"]."</option>\n";
      else  
        $options.="<option value=\"".$zaznam["id"]."\">".$zaznam["nazev"]."</option>\n";
    endwhile;
    return $options;
  }
    
  if (!jeadmin()) return;
  $BudemeZobrazovat=true;
  if (!empty($_POST)) // už se odeslalo
  {
    if ($_POST["odesli"]=="Přidat píseň")
      if ((strlen ($_POST["nazevpisne"])>50) | strlen ($_POST["nazevpisne"])<3) echo "Název písně musí mít 3-50 znaků";
      else
      {
        mysql_query ("insert into pisne (nazev) values ('".$_POST["nazevpisne"]."');", $GLOBALS["link"]);
        $chyba = mysql_error($GLOBALS["link"]);
        if ($chyba==='') $BudemeZobrazovat=false;
        else echo "Píseň NEBYLA přidána. Databáze vrátila chybu $chyba";  
      }
    elseif ($_POST["odesli"]=="Přidat album")
      if ((strlen ($_POST["nazevalba"])>50) | strlen ($_POST["nazevalba"])<3) echo "Název alba musí mít 3-50 znaků";
      else
      {
        mysql_query ("insert into alba (nazev) values ('".$_POST["nazevalba"]."');", $GLOBALS["link"]);
        $chyba = mysql_error($GLOBALS["link"]);
        if ($chyba==='') $BudemeZobrazovat=false;
        else echo "Album NEBYLO přidáno. Databáze vrátila chybu $chyba";  
      }
    elseif ($_POST["odesli"]=="Přidat píseň do alba")
    {
      mysql_query ("insert into obsahyalb (album, pisen) values (".$_POST["zaradit_album"].",".$_POST["zaradit_pisen"].");", $GLOBALS["link"]);
      $chyba = mysql_error($GLOBALS["link"]);
      if ($chyba==='') $BudemeZobrazovat=false;
      else echo "Píseň NEBYLA přidána do alba. Databáze vrátila chybu $chyba";      
    }
    elseif ($_POST["odesli"]=="Odebrat píseň z alba")
    {
      mysql_query ("delete from obsahyalb where album=".$_POST["zaradit_album"]." and pisen=".$_POST["zaradit_pisen"]." limit 1;", $GLOBALS["link"]);
      $chyba = mysql_error($GLOBALS["link"]);
      if ($chyba==='') $BudemeZobrazovat=false;
      else echo "Píseň NEBYLA odebrána z alba. Databáze vrátila chybu $chyba";
    }
  }
if ($BudemeZobrazovat):?>
  <form method="post" action="index.php?clanek=zadejdiskografii">
  <table>
    <tr>
      <td>Název písně:</td>
      <td><input name="nazevpisne" value="<?echo $_POST["nazevpisne"]?>"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="Submit" name="odesli" value="Přidat píseň"></td>
    </tr>
  </table>
  </form>

  <form method="post" action="index.php?clanek=zadejdiskografii">
  <table>
    <tr>
      <td>Název alba:</td>
      <td><input name="nazevalba" value="<?echo $_POST["nazevalba"]?>"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="Submit" name="odesli" value="Přidat album"></td>
    </tr>
  </table>
  </form>

  <form method="post" action="index.php?clanek=zadejdiskografii">
  <table>
    <tr>
      <td>Název alba:</td>
      <td>Název písně:</td>
    </tr>
    <tr>
      <td>
        <select name="zaradit_album"><?echo naplnseznam("alba",$_POST["zaradit_album"])?></select>
      </td>
      <td>
        <select name="zaradit_pisen"><?echo naplnseznam("pisne",$_POST["zaradit_pisen"])?></select>
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="Submit" name="odesli" value="Přidat píseň do alba">&nbsp;
        <input type="Submit" name="odesli" value="Odebrat píseň z alba">
      </td>
    </tr>
  </table>
  </form>
<?else:?>  
  <p>Změna byla zapsána. <a href="index.php?clanek=zadejdiskografii">Zadat diskografii</a></p>
<?endif;?>

