<?
  function jedatum($datum)
  {
    //řetězec musí obsahovat dvě tečky, a po rozdělení těmito tečkami 3 čísla
    $test=explode(".",$datum);
    if(!(count($test))==3) return false;
    return checkdate($test[1],$test[0],$test[2]);
  }
  
  function jecas($cas)
  {
    //řetězec musí obsahovat jednu dvojtečku, a po rozdělení 2 čísla
    $test=explode(":",$cas);
    if(!(count($test))==2) return false;
    if (!is_numeric($test[0])) return false;
    if (!is_numeric($test[1])) return false;
    if (($test[0]<0) | ($test[0]>23)) return false; 
    if (($test[1]<0) | ($test[1]>59)) return false; 
    return true;
  }
  function sqldatum ($datum)
  {
    $test=explode(".",$datum);
    return $test[2]."-".$test[1]."-".$test[0];    
  }
  
  if (!jeadmin()) return;
  $BudemeZobrazovat=true;
  if (!empty($_POST)) // už se odeslalo
  {
    /*
    budeme kontrolovat následující věci:
    1) formát data
    2) formát času
    3) místo - 3 až 50 znaků
    */
    if (!jedatum($_POST["datum"])) echo "Formát data není platný";
    elseif (!jecas($_POST["cas"])) echo "Formát času není platný";
    elseif ((strlen ($_POST["misto"])>50) | strlen ($_POST["misto"])<3)echo "Místo konání koncertu musí mít 3-50 znaků";
    else
    {
      // kontolou jsme prošli
      $BudemeZobrazovat=false;
      // poděkujeme uživateli
      echo "Koncert byl přidán";
      // uložíme to do databáze
      mysql_query ("insert into koncerty (datum, cas, misto) values ('".sqldatum($_POST["datum"])."', '".$_POST["cas"]."', '".$_POST["misto"]."');", $GLOBALS["link"]);
    }
  }
if ($BudemeZobrazovat):?>
  <form method="post" action="index.php?clanek=zadejkoncert">
  <table>
    <tr>
      <td>Datum:</td>
      <td><input name="datum" value="<?echo $_POST["datum"]?>"></td>
      <td>ve formátu d.m.yyyy</td>
    </tr>
    <tr>
      <td>Čas:</td>
      <td><input name="cas" value="<?echo $_POST["cas"]?>"></td>
      <td>ve formátu hh:mm</td>
    </tr>
    <tr>
      <td>Místo:</td>
      <td><input name="misto" value="<?echo $_POST["misto"]?>"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2"><input type="Submit" name="odesli" value="Přidat koncert"></td>
    </tr>
  </table>
  </form>
<?endif;?>

