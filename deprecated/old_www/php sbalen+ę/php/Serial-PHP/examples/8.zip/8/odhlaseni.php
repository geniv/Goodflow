<?
  echo "Byli jste odhlášeni";
?>

