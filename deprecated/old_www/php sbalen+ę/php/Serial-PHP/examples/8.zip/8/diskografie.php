<h1>Diskografie</h1>
<?
  $vysledek=mysql_query("select id, nazev from alba",$GLOBALS["link"]);
  if (mysql_num_rows($vysledek)==0)
    echo "--  Není vydáno žádné album --";
  else
  {
    echo "<TABLE>";
    while ($zaznam=MySQL_Fetch_Array($vysledek)):
      $album=$zaznam["id"];
      ?>
      <TR>
        <TD><B><?echo $zaznam["nazev"]?></B></TD>
      </TR>
      <?
      $vysledek2=mysql_query("select nazev from pisne inner join obsahyalb on pisne.id = obsahyalb.pisen where obsahyalb.album=".$album,$GLOBALS["link"]);
        if (mysql_num_rows($vysledek2)==0)
          echo "--  Nejsou k dispozici písně na tomto albu --";
        else
        {
          while ($zaznam2=MySQL_Fetch_Array($vysledek2)):
            ?>
            <TR>
              <TD><?echo $zaznam2["nazev"]?></TD>
            </TR>
            <?
          endwhile;
        }?>
      <?
    endwhile;
    echo "</TABLE>";
  }
?>

