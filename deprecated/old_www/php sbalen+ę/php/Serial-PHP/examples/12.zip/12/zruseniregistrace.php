<? 
  echo "Vaše registrace na portále byla zrušena";
?>
