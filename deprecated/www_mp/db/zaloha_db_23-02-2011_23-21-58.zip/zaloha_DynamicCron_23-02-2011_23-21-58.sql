
-------------------- table:cron

CREATE TABLE cron (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                modul VARCHAR(100),
                                funkce VARCHAR(100),
                                parametry TEXT,
                                popis TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('1', 'Funkce', 'CronAdminClearLog', '', 'Promazávání admin logu', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('2', 'Funkce', 'CronZalohovaniDatabaze', '', 'Zálohování databází', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('3', 'Funkce', 'CronKontolaZalohyDatabaze', '', 'Promazávání databází', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('4', 'Funkce', 'CronZalohovaniUnikatnich', '', 'Zálohování unikátních', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('5', 'Funkce', 'CronKontrolaUnikatnich', '', 'Promazávání unikátních', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('6', 'Funkce', 'CronKontrolaErrorLogu', '', 'Promazávání error logů', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('7', 'Funkce', 'CronGenerovaniCacheGrafu', '', 'Generování cache pro grafy', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('8', 'Funkce', 'CronKontrolaSessionLogu', '', 'Promazávání session logů', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('9', 'Funkce', 'CronKontrolaActionLogu', '', 'Promazávání action logů', '2010-11-12 16:31:36', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('10', 'DynamicMail', 'CronOdesilaniEmailu', '', '', '2011-02-23 22:57:27', '', '1');

-------------------- table:cron_log

CREATE TABLE cron_log (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                exectime VARCHAR(100),
                                datum DATETIME,
                                agent VARCHAR(300),
                                ip VARCHAR(50));

INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('92', '2.8193', '2011-02-19 01:02:05', 'Wget/1.10.2', '87.236.199.95');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('93', '3.1785', '2011-02-20 01:02:05', 'Wget/1.10.2', '87.236.199.95');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('94', '4.0464', '2011-02-21 01:02:06', 'Wget/1.10.2', '87.236.199.95');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('95', '3.1698', '2011-02-22 01:02:05', 'Wget/1.10.2', '87.236.199.95');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('96', '3.2266', '2011-02-23 01:02:05', 'Wget/1.10.2', '87.236.199.95');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('97', '1.8494', '2011-02-23 23:09:12', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; cs; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13 ( .NET CLR 3.5.30729; .NET4.0C)', '192.168.1.100');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('98', '1.2951', '2011-02-23 23:17:51', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; cs; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13 ( .NET CLR 3.5.30729; .NET4.0C)', '192.168.1.100');
