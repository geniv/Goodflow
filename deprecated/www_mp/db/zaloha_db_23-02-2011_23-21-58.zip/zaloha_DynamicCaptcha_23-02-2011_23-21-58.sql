
-------------------- table:captcha

CREATE TABLE captcha (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                font INTEGER UNSIGNED,
                                typ VARCHAR(50),
                                konfigurace TEXT,
                                otazka VARCHAR(500),
                                x INTEGER UNSIGNED,
                                y INTEGER UNSIGNED,
                                width INTEGER UNSIGNED,
                                height INTEGER UNSIGNED,
                                padding VARCHAR(20),
                                font_size VARCHAR(20),
                                roztec INTEGER UNSIGNED,
                                font_color VARCHAR(20),
                                background_color VARCHAR(10),
                                rotace_pismen VARCHAR(20),
                                mrizka VARCHAR(20),
                                rand_dot BOOL,
                                rand_line BOOL,
                                rand_rectangle BOOL,
                                rand_arc BOOL,
                                rand_ellipse BOOL,
                                rand_barva VARCHAR(20),
                                rand_koeficient VARCHAR(20),
                                url VARCHAR(200),
                                vyrez_x INTEGER UNSIGNED,
                                vyrez_y INTEGER UNSIGNED);

INSERT INTO captcha (id, font, typ, konfigurace, otazka, x, y, width, height, padding, font_size, roztec, font_color, background_color, rotace_pismen, mrizka, rand_dot, rand_line, rand_rectangle, rand_arc, rand_ellipse, rand_barva, rand_koeficient, url, vyrez_x, vyrez_y) VALUES ('1', '1', 'pismena', 'small|--xx--|3', 'nejaka otazka', '10', '30', '0', '0', '5 10 5 10', '14', '20', '#000000', '#ffffff', '0', '', '0', '0', '0', '0', '0', '#cccccc', '1', '', '0', '0');
INSERT INTO captcha (id, font, typ, konfigurace, otazka, x, y, width, height, padding, font_size, roztec, font_color, background_color, rotace_pismen, mrizka, rand_dot, rand_line, rand_rectangle, rand_arc, rand_ellipse, rand_barva, rand_koeficient, url, vyrez_x, vyrez_y) VALUES ('2', '1', 'priklady', 'modulo|--xx--|10|--xx--|20|--xx--|10|--xx--|20', 'deleni umis?', '10', '30', '0', '0', '10 10 10 10', '14', '20', '#000000', '#ffffff', '0', '', '0', '0', '0', '0', '0', '#cccccc', '1', '', '0', '0');

-------------------- table:font

CREATE TABLE font (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                nazev VARCHAR(100),
                                url VARCHAR(300));

INSERT INTO font (id, nazev, url) VALUES ('1', 'Myriad Pro Bold.ttf', '12-11-2010-11-48-42_Myriad-Pro-Bold.ttf');
INSERT INTO font (id, nazev, url) VALUES ('2', '2Proton-2.ttf', '12-12-2010-20-11-02_2Proton-2.ttf');
