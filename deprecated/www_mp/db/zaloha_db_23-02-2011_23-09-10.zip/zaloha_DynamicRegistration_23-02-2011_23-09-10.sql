
-------------------- table:dynamicregistration_last_log

CREATE TABLE `dynamicregistration_last_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(10) unsigned DEFAULT NULL,
  `session` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `logon` datetime DEFAULT NULL,
  `last_act` datetime DEFAULT NULL,
  `agent` varchar(300) COLLATE utf8_czech_ci DEFAULT NULL,
  `ip` varchar(50) COLLATE utf8_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;


-------------------- table:dynamicregistration_user

CREATE TABLE `dynamicregistration_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `heslo` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_czech_ci DEFAULT NULL,
  `pridano` datetime DEFAULT NULL,
  `upraveno` datetime DEFAULT NULL,
  `aktivni` tinyint(1) DEFAULT NULL,
  `polozky` text COLLATE utf8_czech_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('1', 'pokus', 'ad79e2cd5fd5ae53547d991007344847', 'geniv.radek@gmail.com', '2011-02-23 20:37:38', '2011-02-23 22:42:55', '1', 'jmeno:rada|--xx--|prijmeni:hnee|--xx--|vek:24 let|--xx--|vzdelani:sdfgfg|--xx--|telefon:72312312|--xx--|nabidka:dsghgjfd fg dg|--xx--|osobe:gfg |--xx--|zkusenosti:gffg fg fg|--xx--|novinky:on|--xx--|foto:23-02-2011_22-08-48_2004.jpg');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('2', 'pokuss', 'eee118a6fa4d9906f010c0272ce57947', 'radek.frystak@gfdesign.com', '2011-02-23 20:40:47', '', '0', 'jmeno:dfdffg|--xx--|prijmeni:fg fg fg|--xx--|vek:19 let|--xx--|vzdelani:fghg gf|--xx--|telefon:72312312|--xx--|nabidka:ghfgfg fg fg|--xx--|osobe:fg fg fgfg|--xx--|zkusenosti:fg fg fgfg|--xx--|novinky:on|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('3', 'borec', 'b28bfcf0cea32ee6c3cc330b588ac9b7', 'fugess@gfdesign.cz', '2011-02-23 20:41:32', '', '0', 'jmeno:cece jmeno|--xx--|prijmeni:cece prijmeni|--xx--|vek:21 let|--xx--|vzdelani:totalni borec|--xx--|telefon:78978798|--xx--|nabidka:hovno|--xx--|osobe:jsem borec|--xx--|zkusenosti:webmasta a skilli|--xx--|novinky:|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('4', 'alah', '0e1f77ec87287b1385f240ec3835a753', 'martin.fugess@gmail.com', '2011-02-23 20:44:45', '', '0', 'jmeno:gnfhg fg|--xx--|prijmeni:fg fg fg|--xx--|vek:21 let|--xx--|vzdelani:fgg|--xx--|telefon:fg f|--xx--|nabidka:gfg f|--xx--|osobe:fg fgfgf|--xx--|zkusenosti:fg fgfg|--xx--|novinky:on|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('5', 'ddd', '12d13e7bad81a52f3ec893388cb2d2ed', 'geniv@geniv-asus.cz', '2011-02-23 20:51:48', '', '0', 'jmeno:kjfgh|--xx--|prijmeni:kjgkdfjkg|--xx--|vek:22 let|--xx--|vzdelani:dgfgsdg|--xx--|telefon:dfd|--xx--|nabidka:dsfdfd|--xx--|osobe:dfdfdd|--xx--|zkusenosti:dfdf dfdf|--xx--|novinky:on|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('6', 'otrok', '40ad491c1c6403330a6d7695e6fa3723', 'geniv.radek@gmail.com', '2011-02-23 21:01:50', '', '0', 'jmeno:red|--xx--|prijmeni:clif|--xx--|vek:21 let|--xx--|vzdelani:fgdh df|--xx--|telefon:fdfg dfdf|--xx--|nabidka:g dfdfdf|--xx--|osobe:dfd fdf|--xx--|zkusenosti:rtrer ererer|--xx--|novinky:on|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('7', 'sriudszghj', 'b161c733a76204d649714569af5d4efe', 'kontakt@gfdesign.cz', '2011-02-23 21:06:20', '', '0', 'jmeno:ghdfgfd|--xx--|prijmeni:gfgfdgfgfdfg|--xx--|vek:17 let|--xx--|vzdelani:dfdg|--xx--|telefon:fgf g|--xx--|nabidka:fg fgf|--xx--|osobe:fgdfg|--xx--|zkusenosti:fg|--xx--|novinky:|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('8', 'pokusfdghdfj', 'a498aa939753103abce5eb7735cfb195', 'kontakt@gfdesign.cz', '2011-02-23 21:12:22', '', '0', 'jmeno:fdghj|--xx--|prijmeni:fg|--xx--|vek:16 let|--xx--|vzdelani:gfdhf|--xx--|telefon:tffg|--xx--|nabidka:gfgfgf|--xx--|osobe:gfgfg|--xx--|zkusenosti:fgfdg|--xx--|novinky:|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('9', 'mirkovic', 'ff94c9e426915fd1a30048e2044c0f08', 'kontakt@gfdesign.cz', '2011-02-23 21:22:04', '', '0', 'jmeno:Miroslav|--xx--|prijmeni:Mrkcička|--xx--|vek:27 let|--xx--|vzdelani:uplne stredni|--xx--|telefon:72312312|--xx--|nabidka:pracu|--xx--|osobe:jsem borec|--xx--|zkusenosti:uz jsem delal|--xx--|novinky:|--xx--|foto:');
INSERT INTO dynamicregistration_user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('10', 'macrh', '86c625126fc4fe6f219d41d295f27a5f', 'kontakt@gfdesign.cz', '2011-02-23 21:24:38', '', '0', 'jmeno:jmeeeeno|--xx--|prijmeni:prijmeeniii|--xx--|vek:22 let|--xx--|vzdelani:vzdelani|--xx--|telefon:78978|--xx--|nabidka:kulovy|--xx--|osobe:totalni borec|--xx--|zkusenosti:totalni machr|--xx--|novinky:|--xx--|foto:');
