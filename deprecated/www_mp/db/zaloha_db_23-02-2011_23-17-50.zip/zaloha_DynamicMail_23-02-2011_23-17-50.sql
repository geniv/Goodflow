
-------------------- table:dynamicmail_maillist

CREATE TABLE `dynamicmail_maillist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(500) COLLATE utf8_czech_ci DEFAULT NULL,
  `agent` varchar(300) COLLATE utf8_czech_ci DEFAULT NULL,
  `ip` varchar(50) COLLATE utf8_czech_ci DEFAULT NULL,
  `pridano` datetime DEFAULT NULL,
  `upraveno` datetime DEFAULT NULL,
  `typ` varchar(20) COLLATE utf8_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicmail_maillist (id, email, agent, ip, pridano, upraveno, typ) VALUES ('2', 'radek.frystak@gfdesign.com', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.98 Safari/534.13', '127.0.1.1', '2011-02-23 20:40:47', '', 'reg');
INSERT INTO dynamicmail_maillist (id, email, agent, ip, pridano, upraveno, typ) VALUES ('4', 'geniv@geniv-asus.cz', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.98 Safari/534.13', '127.0.1.1', '2011-02-23 20:51:48', '', 'reg');
INSERT INTO dynamicmail_maillist (id, email, agent, ip, pridano, upraveno, typ) VALUES ('7', 'geniv.radek@gmail.com', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; cs; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13 ( .NET CLR 3.5.30729; .NET4.0C)', '192.168.1.100', '2011-02-23 22:42:55', '', 'reg');
INSERT INTO dynamicmail_maillist (id, email, agent, ip, pridano, upraveno, typ) VALUES ('11', 'fugess@gfdesign.cz', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; cs; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13 ( .NET CLR 3.5.30729; .NET4.0C)', '192.168.1.100', '2011-02-23 22:57:54', '', 'web');

-------------------- table:dynamicmail_zpravy

CREATE TABLE `dynamicmail_zpravy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `predmet` varchar(200) COLLATE utf8_czech_ci DEFAULT NULL,
  `zprava` text COLLATE utf8_czech_ci,
  `pridano` datetime DEFAULT NULL,
  `upraveno` datetime DEFAULT NULL,
  `odeslano` datetime DEFAULT NULL,
  `zamek` tinyint(1) DEFAULT NULL,
  `aktivni` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamicmail_zpravy (id, predmet, zprava, pridano, upraveno, odeslano, zamek, aktivni) VALUES ('1', 'totalni super predmet', '&lt;p&gt;totalni super novinka&lt;/p&gt;
&lt;p&gt;kurva cum na to dpc&lt;/p&gt;
&lt;p&gt;hovnoooo &lt;strong&gt;takze ted to bude tucne&lt;/strong&gt; a &lt;em&gt;toto kurzive&lt;/em&gt; a &lt;span style=&quot;text-decoration: underline;&quot;&gt;toto podtrzene&lt;/span&gt; takze uvidime jak to bude fungovat&lt;br /&gt;a ted radek&lt;br /&gt;&lt;br /&gt;&lt;br /&gt;&lt;br /&gt;raaaadek&lt;br /&gt;&lt;br /&gt;&lt;br /&gt;zkouska&lt;/p&gt;', '2011-02-23 23:08:46', '', '2011-02-23 23:09:12', '1', '1');
INSERT INTO dynamicmail_zpravy (id, predmet, zprava, pridano, upraveno, odeslano, zamek, aktivni) VALUES ('2', 'test news konžůretšity', '&lt;p&gt;totalni super text&lt;/p&gt;
&lt;p&gt;dalsi odstavec&lt;/p&gt;
&lt;p&gt;text&lt;br /&gt;raaaadek&lt;br /&gt;&lt;br /&gt;novyy &lt;br /&gt;&lt;br /&gt;&lt;br /&gt;&lt;br /&gt;tdadadas&lt;/p&gt;
&lt;p&gt;dsadsad &lt;strong&gt;sa dsadsadsad&lt;/strong&gt; sdasa d&lt;em&gt;dsa sadsadsad &lt;/em&gt;sad dsad &lt;span style=&quot;text-decoration: underline;&quot;&gt;sad asdsadsa dsad&amp;nbsp; &lt;/span&gt;dsads a&lt;/p&gt;
&lt;p&gt;&amp;nbsp;&lt;/p&gt;
&lt;p&gt;takze jako hovno s hovnem totalnim&lt;/p&gt;', '2011-02-23 23:16:31', '', '', '0', '1');
