<?php

/* -------------------------------------------------------------------------- */

  $result = array("set_typ_vypisu_1" => "fullclassic",

                  "normal_fullclassic_prev_1" => "<a href=\"%%1%%\" title=\"Předchozí strana\">«</a> ",

                  "normal_fullclassic_current_1" => "<span title=\"Strana %%1%%\">%%1%%</span>",

                  "normal_fullclassic_page_1" => "<a href=\"%%1%%\" title=\"Strana %%2%%\">%%2%%</a>",

                  "normal_fullclassic_sep_1" => "",

                  "normal_fullclassic_next_1" => " <a href=\"%%1%%\" title=\"Další strana\">»</a>",

                  "normal_strankovani_1" => "
<div id=\"centralni_strankovani\">
  <p>%%1%%</p>
</div>\n",

/* -------------------------------------------------------------------------- */

                  );

/* -------------------------------------------------------------------------- */

  return $result;
?>
