<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Pagination Language Lines
	|--------------------------------------------------------------------------
	|
	| The following language lines are used by the paginator library to build
	| the pagination links. You're free to change them to anything you want.
	| If you come up with something more exciting, let us know.
	|
	*/

	/*
	|--------------------------------------------------------------------------
	| ペギネーション言語ライン
	|--------------------------------------------------------------------------
	|
	| 以下の言語設定行はpaginatorライブラリーにより、ペギネーションリンクを作成するため
	| 使用されます。お好きなように変更してください。
	| もっとエキサイトするアイデアが思い浮かんだら、私達に教えて下さい。
	|
	*/


	'previous' => '&laquo; 前',
	'next'     => '次 &raquo;',

);
