<?php

$_SERVER['bundle.dummy.start']++;