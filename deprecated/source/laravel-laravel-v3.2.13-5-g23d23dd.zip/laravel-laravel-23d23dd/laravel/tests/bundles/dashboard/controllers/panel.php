<?php

class Dashboard_Panel_Controller extends Controller {

	public function action_index()
	{
		return 'Dashboard_Panel_Index';
	}

}