<?php

namespace Rain\Tpl;

/**
 * Exception thrown when template file does not exists.
 */
class NotFoundException extends Exception {
    
}


// -- end
