ChangeLog
=========

2012-04-25 - Tagged as release 2.0.1
2012-04-15 - Updated America's Army 3 to use A2S (See #27)
2012-03-28 - Tagged as release 2.0.0
