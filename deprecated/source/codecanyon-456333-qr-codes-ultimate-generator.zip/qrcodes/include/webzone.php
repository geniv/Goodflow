<?php
include_once('config.php');

//class
include_once('class/Qrcodes_class.php');
include_once('class/Url_shortner_class.php');

include_once('functions/functions.php');
?>