<?php

$GLOBALS['shortner_service'] = 'google'; //possible values: google

//Optional parameter - you can generate a key on: https://code.google.com/apis/console
//used the Google's Url shorten service
$GLOBALS['google_api_key'] = '';

?>