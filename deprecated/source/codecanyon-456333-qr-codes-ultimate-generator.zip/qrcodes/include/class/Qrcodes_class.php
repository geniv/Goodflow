<?php

class Qrcodes_class
{
	
	function generate_qrcode($criteria=array()) {
		
		
	}
	
}

?>