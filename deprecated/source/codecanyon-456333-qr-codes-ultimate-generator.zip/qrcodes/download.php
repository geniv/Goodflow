<?php
$url = $_GET['url'];
header('Content-Description: File Transfer');
header("Content-type: image/png");
header("Content-disposition: attachment; filename= qrcode_".time().".png");
readfile($url);
?>