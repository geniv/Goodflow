<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<title>QR Codes Generator</title> 

<meta name="description" content="QR Codes Generator" /> 

<link rel="stylesheet" href="include/css/style.css" type="text/css" media="screen, projection">
<link rel="stylesheet" href="include/css/grid.css" type="text/css" media="screen, projection">

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script type="text/javascript" src="include/js/script-min.js"></script>

<?php
include_once('./include/webzone.php');
?>

<script> 
$(document).ready(function() {
	$('.tabs a').live('click', function(event) {
		select_tab($(this));
	});
	init_tabs();
})
</script>

<script type="text/javascript"> 
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-5387583-20']);
  _gaq.push(['_setDomainName', '.yougapi.com']);
  _gaq.push(['_trackPageview']);
 
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

</head>

<body>

<div class="container"> 

	<br>
	<a href="http://codecanyon.net/item/qr-codes-ultimate-generator/456333?ref=yougapi"><img src="include/graph/qrcodes-mini.png" align="left" style="margin-right:30px;"></a>
	<h1 style="margin-bottom:5px;">QR Codes Ultimate Generator</h1>
	<h2 style="margin-bottom:8px;" class="alt">Generate QR Codes images and Urls in seconds<br></h2>
	<br>
	
	<hr>
	
	<div class="span-8 colborder" style="font-size:85%;">
	<h6>Features</h6>
	- Generates QR Code Images and Urls<br>
	- 10+ possible types (email, phone, vCard, location etc).<br>
	- User friendly interface to create QR Codes.<br>
	- Powered by jQuery<br>
	- Possible customizations (image size and encoding)<br>
	- Based on the Google's Inforgraphics API<br>
	</div>
	
	<div class="span-7 colborder" style="font-size:85%;">
	<h6>Possible uses</h6>
	<p>
	- Get your own QR Codes generator<br>
	- Integrate it on your own website or application<br>
	- Create and print your locations as QR Codes<br>
	- And more...<br>
	</p> 
	</div> 
	
	<div class="span-7 last" style="font-size:85%;">
	<h6>Available on codecanyon</h6>
	<p><a href="http://codecanyon.net/item/qr-codes-ultimate-generator/456333?ref=yougapi"><img src="include/graph/cc_125x125_v1.gif" align="right" style="margin-bottom:10px;"></a><br>
	Check <a href="http://codecanyon.net/user/yougapi?ref=yougapi">our portfolio</a> on codecanyon.</p>
	</div>
	
	<hr>
	
	<div class="span-16 colborder">
	
		<form>
			
			<div>
				<b>Encoding</b>
				<select id="qrcode_encoding">
				<option>UTF-8</option>
				<option>Shift_JIS</option>
				<option>ISO-8859-1</option>
				</select>
				
				<span style="margin-left:20px;">
					<b>Size:</b>
					<input type="text" id="qrcode_width" value="300" style="width:60px;">
					X
					<input type="text" id="qrcode_height" value="300" style="width:60px;">
				</span>
				
				<span style="margin-left:20px;">
					<b>Correction level</b>
					<select id="qrcode_correction">
					<option>L</option>
					<option>M</option>
					<option>Q</option>
					<option>H</option>
					</select>
				</span>
				
			</div>
			
			<br>
			
			<div id="wrapper">
			
			    <ul class="tabs">
			        <li><a href="#text" class="current" rel="text">Text</a></li>
			        <li><a href="#email" rel="email">Email</a></li>
			        <li><a href="#tel" rel="tel">Tel</a></li>
			        <li><a href="#url" rel="url">Url</a></li>
			        <li><a href="#vcard" rel="vcard">vCard</a></li>
			        <li><a href="#mecard" rel="mecard">MeCard</a></li>
			        <li><a href="#sms" rel="sms">SMS</a></li>
			        <li><a href="#geo" rel="geo">Location</a></li>
			        <li><a href="#bookmark" rel="bookmark">Bookmark</a></li>
			        <li><a href="#wifi" rel="wifi">WIFI</a></li>
			    </ul>
			 
			    <div class="tab_content" id="text">
			    	<div style="color:#666"><b>Text</b></div>
			    	<textarea id="qrcode_text" style="width:90%; height:100px;"></textarea>
			    	<br><span id="nb_char"></span>
			    </div>
			    
			    <div class="tab_content" id="email">
			    	<div style="color:#666"><b>Email</b></div>
			    	<input type="text" id="qrcode_email" style="width:260px;"><br>
			    	<div style="color:#666"><b>Subject</b></div>
			    	<input type="text" id="qrcode_subject" style="width:260px;"><br>
			    	<div style="color:#666"><b>Message</b></div>
			    	<textarea id="qrcode_message" style="width:90%; height:100px;"></textarea>
			    </div>
			    
			    <div class="tab_content" id="tel">
			    	<div style="color:#666"><b>Tel</b></div>
			    	<input type="text" id="qrcode_tel" style="width:260px;">
			    </div>
			    
			    <div class="tab_content" id="url">
			    	<div style="color:#666"><b>Url</b></div>
			    	<input type="text" id="qrcode_url" style="width:260px;">
			    </div>
			    
			    <div class="tab_content" id="vcard">
			    	<div class="span-8">
				    	<div style="color:#666"><b>First name</b></div>
				    	<input type="text" id="qrcode_vcard_fname" style="width:260px;">
				    	<div style="color:#666"><b>Last name</b></div>
				    	<input type="text" id="qrcode_vcard_lname" style="width:260px;">
				    	<div style="color:#666"><b>Company name</b></div>
				    	<input type="text" id="qrcode_vcard_org" style="width:260px;">
				    	<div style="color:#666"><b>Title</b></div>
				    	<input type="text" id="qrcode_vcard_title" style="width:260px;">
				    	<div style="color:#666"><b>Tel</b></div>
				    	<input type="text" id="qrcode_vcard_tel" style="width:260px;">
				    	<div style="color:#666"><b>Email</b></div>
				    	<input type="text" id="qrcode_vcard_email" style="width:260px;">
				    	<div style="color:#666"><b>Url</b></div>
				    	<input type="text" id="qrcode_vcard_url" style="width:260px;">
				    </div>
				    <div class="span-7 last">
				    	<div style="color:#666"><b>Street name</b></div>
				    	<input type="text" id="qrcode_vcard_street" style="width:260px;">
				    	<div style="color:#666"><b>City</b></div>
				    	<input type="text" id="qrcode_vcard_city" style="width:260px;">
				    	<div style="color:#666"><b>State</b></div>
				    	<input type="text" id="qrcode_vcard_state" style="width:260px;">
				    	<div style="color:#666"><b>Postal code</b></div>
				    	<input type="text" id="qrcode_vcard_zip" style="width:260px;">
				    	<div style="color:#666"><b>Country</b></div>
				    	<input type="text" id="qrcode_vcard_country" style="width:260px;">
				    	<div style="color:#666"><b>Notes</b></div>
				    	<textarea id="qrcode_vcard_note" style="width:260px; height:60px;"></textarea>
				    </div>
			    </div>
			    
			    <div class="tab_content" id="mecard">
			    	<div class="span-8">
				    	<div style="color:#666"><b>First name</b></div>
				    	<input type="text" id="qrcode_mecard_fname" style="width:260px;">
				    	<div style="color:#666"><b>Last name</b></div>
				    	<input type="text" id="qrcode_mecard_lname" style="width:260px;">
				    	<div style="color:#666"><b>Tel</b></div>
				    	<input type="text" id="qrcode_mecard_tel" style="width:260px;">
				    	<div style="color:#666"><b>Email</b></div>
				    	<input type="text" id="qrcode_mecard_email" style="width:260px;">
				    	<div style="color:#666"><b>Url</b></div>
				    	<input type="text" id="qrcode_mecard_url" style="width:260px;">
				    </div>
				    <div class="span-7 last">
				    	<div style="color:#666"><b>Street name</b></div>
				    	<input type="text" id="qrcode_mecard_street" style="width:260px;">
				    	<div style="color:#666"><b>City</b></div>
				    	<input type="text" id="qrcode_mecard_city" style="width:260px;">
				    	<div style="color:#666"><b>State</b></div>
				    	<input type="text" id="qrcode_mecard_state" style="width:260px;">
				    	<div style="color:#666"><b>Postal code</b></div>
				    	<input type="text" id="qrcode_mecard_zip" style="width:260px;">
				    	<div style="color:#666"><b>Country</b></div>
				    	<input type="text" id="qrcode_mecard_country" style="width:260px;">
				    	<div style="color:#666"><b>Notes</b></div>
				    	<textarea id="qrcode_mecard_note" style="width:260px; height:60px;"></textarea>
				    </div>
			    </div>
			    
			    <div class="tab_content" id="sms">
			    	<div style="color:#666"><b>Tel</b></div>
			    	<input type="text" id="qrcode_sms_tel" style="width:260px;">
			    	<div style="color:#666"><b>Message</b></div>
			    	<textarea id="qrcode_sms_message" style="width:90%; height:100px;"></textarea>
			    </div>
			    
			    <div class="tab_content" id="geo">
			    	<div style="color:#666"><b>Address</b></div>
			    	<input type="text" id="qrcode_geo_address" style="width:300px;">
			    	<br>OR<br>
			    	<div style="color:#666"><b>Lat</b></div>
			    	<input type="text" id="qrcode_geo_lat" style="width:200px;">
			    	<div style="color:#666"><b>Lng</b></div>
			    	<input type="text" id="qrcode_geo_lng" style="width:200px;">
			    </div>
			    
			    <div class="tab_content" id="bookmark">
			    	<div style="color:#666"><b>Title</b></div>
			    	<input type="text" id="qrcode_bkm_title" style="width:260px;">
			    	<div style="color:#666"><b>Url</b></div>
			    	<input type="text" id="qrcode_bkm_url" style="width:260px;">
			    </div>
			    
			    <div class="tab_content" id="wifi">
			    	<div style="color:#666"><b>Wireless SSID</b></div>
			    	<input type="text" id="qrcode_wifi_ssid" style="width:260px;">
			    	<div style="color:#666"><b>Password</b></div>
			    	<input type="text" id="qrcode_wifi_password" style="width:260px;">
			    	<div style="color:#666"><b>Network type</b></div>
			    	<select id="qrcode_wifi_type">
			    	<option value="WEP">WEP</option>
			    	<option value="WPA">WPA/WPA2</option>
			    	<option value="nopass" selected>No encryption</option>
			    	</select>
			    </div>
			    
			</div>
			
			<br>
			<hr class="space">
			<input type="submit" id="generate_qrcode_btn" class="green btn" value="Generate QR Code">
		
		</form>
	
	</div>
	
	<div class="span-7 last">
		
		<b>Preview</b>
		<div id="qrcode_preview" style="margin-bottom:10px;"></div>
		<div id="url_box" style="margin-bottom:10px;"></div>
		<div id="short_url_box" style="margin-bottom:10px;"></div>
		<div id="download_box" style="margin-bottom:10px;"></div>
		<div id="sharing_box" style="margin-bottom:10px;"></div>
		
	</div>
	
	<?php
	
	?>
	
	<hr class="space">
	<br>
	<hr>
	<small>Powered by <a href="http://yougapi.com">Yougapi Technology</a></small>
	
</div>

</body>
</html>