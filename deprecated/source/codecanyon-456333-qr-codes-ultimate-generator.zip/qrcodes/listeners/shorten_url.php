<?php
include_once('../include/webzone.php');

$url = $_POST['url'];

//echo $url;

$s1 = new Url_shortner_class();
$data = $s1->shorten_url(array('url'=>$url, 'type'=>$GLOBALS['shortner_service']));

echo $data['shortUrl'];
?>