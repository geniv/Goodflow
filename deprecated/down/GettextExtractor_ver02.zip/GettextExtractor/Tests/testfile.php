<?php

echo $this->translate("Whooa! %d asd", 10);
echo trim(translate () . 'Whooa %s ad', "S"));

function translate($c) {
    translate('ww');
}

?>