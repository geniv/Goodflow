<?php

interface iFilter
{
    public function extract($fileContents);
}