Nette Framework example
-----------------------

A couple of examples demonstrate forms usage in Nette.
