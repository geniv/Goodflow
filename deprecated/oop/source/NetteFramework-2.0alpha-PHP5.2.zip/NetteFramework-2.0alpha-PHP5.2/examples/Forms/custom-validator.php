<?php

/**
 * Forms custom validator example.
 */


require dirname(__FILE__) . '/../../Nette/loader.php';


NDebug::enable();



// Step 0: Define custom validator
function divisibilityValidator($item, $arg)
{
	return $item->value % $arg === 0;
}



// Step 1: Define form with validation rules
$form = new NForm;

$form->addText('num1', 'Multiple of 8:')
	->addRule('divisibilityValidator', 'First number must be %d multiple', 8);

$form->addText('num2', 'Not multiple of 5:')
	->addRule(~'divisibilityValidator', 'Second number must not be %d multiple', 5); // negative


$form->addSubmit('submit', 'Send');



// Step 2: Check if form was submitted?
if ($form->isSubmitted()) {

	// Step 2c: Check if form is valid
	if ($form->isValid()) {
		echo '<h2>Form was submitted and successfully validated</h2>';

		NDebug::dump($form->values);

		// this is the end, my friend :-)
		exit;
	}

} else {
	// not submitted, define default values
	$defaults = array(
		'num1'    => '5',
		'num2'    => '5',
	);

	$form->setDefaults($defaults);
}



// Step 3: Render form
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">

	<title>Nette\Forms custom validator example | Nette Framework</title>

	<style type="text/css">
	.required {
		color: darkred
	}

	fieldset {
		padding: .5em;
		margin: .5em 0;
		background: #E4F1FC;
		border: 1px solid #B2D1EB;
	}

	input.button {
		font-size: 120%;
	}

	th {
		width: 10em;
		text-align: right;
	}
	</style>
	<link rel="stylesheet" type="text/css" media="screen" href="files/style.css" />
</head>

<body>
	<h1>Nette\Forms custom validator example</h1>

	<?php echo $form ?>
</body>
</html>
