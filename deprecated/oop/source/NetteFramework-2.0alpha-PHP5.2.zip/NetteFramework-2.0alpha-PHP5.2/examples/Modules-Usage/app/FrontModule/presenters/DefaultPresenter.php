<?php


class Front_DefaultPresenter extends BasePresenter
{

}
