<?php


class Front_CatalogListPresenter extends BasePresenter
{

}
