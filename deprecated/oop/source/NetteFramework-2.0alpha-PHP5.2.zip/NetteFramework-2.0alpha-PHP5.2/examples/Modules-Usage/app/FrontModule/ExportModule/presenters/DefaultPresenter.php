<?php


class Front_Export_DefaultPresenter extends BasePresenter
{

}
