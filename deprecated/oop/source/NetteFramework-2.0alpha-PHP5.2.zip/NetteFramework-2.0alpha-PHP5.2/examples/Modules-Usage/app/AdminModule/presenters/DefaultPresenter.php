<?php


class Admin_DefaultPresenter extends BasePresenter
{

}
