<?php



abstract class BasePresenter extends NPresenter
{
}
