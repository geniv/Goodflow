Nette Framework example
-----------------------

A simple example showing components as the logical stand-alone units existing
inside the presenter. We can put two components alongside and each of them
will be working stand-alone. The communication between components and
presenter is arranged by events (event-driven model).
