Texy! 2.1 (c) David Grudl, 2004-2010 (http://davidgrudl.com)



Seznámení
---------

Děkuji za stažení Texy!

Texy je program, díky kterému můžete snadno, bez odborných znalostí,
psát texty na webové stránky.

Chcete zvýraznit písmo? Vytvořit nadpis či odrážky? Přidat obrázek
nebo tabulku? Nemusíte zápasit se složitým textovým editorem.
Stačí psát prostý text a Texy už úpravu zvládne za vás. Výsledkem
bude hezky zformátovaná stránka.

Kód je napsán v PHP 5 s plným využitím objektů. Navržen je tak, aby jeho
rozšíření nebo přizpůsobení specifickým potřebám bylo co nejjednodušší a obešlo
se bez zásahu do zdrojového kódu.

Texy je sexy!



Licence
-------

Texy je svobodný program. Můžete ho zdarma stáhnout, libovolně upravovat
a používat ve svých aplikacích v souladu s podmínkami GNU General Public License v2.
Přečtěte si pozorně licenční podmínky v souboru license.txt.

Autor Texy David Grudl nabízí možnost licencovat knihovnu pod komerční licencí
pro organizace, které nechtějí zveřejňovat zdrojové kódy svých aplikací. Cenu a podmínky
najdete na stránkách http://texy.info, nebo kontaktujte přímo autora na david@grudl.com.



Dokumentace a příklady
----------------------

Příklady najdete v adresáři 'examples'. Dokumentace je k dispozici na webových stránkách:

http://texy.info



Texy.minified
-------------

Jde o zhuštěnou jednosouborovou verzi Texy. Je totožná s normální verzí,
redukováno bylo pouze bílé místo a komentáře.



Podpořte Texy!
-------------

Pokud byste rádi vyjádřili uznání za čas, který autor strávil jeho vývojem,
nebo pokud Vám Texy dobře slouží a chtěli byste podpořit jeho další vývoj,
pošlete prosím příspěvek v jakékoliv výši (viz http://texy.info/cs/prispejte)

Texy můžete podpořit také umístěním ikonky na své stránky. Ikonky a vzorový
HTML kód najdete v adresáři /icons/



-----
Chcete-li další informace, navštivte autorův weblog:
http://phpfashion.com
