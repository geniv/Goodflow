Nette Framework example
-----------------------

The example demonstrates the usage of modules and submodules. Presenters (and
then templates) are separated on two main modules Front and Admin.
Furthermore, the Front module contains the Export submodule.
