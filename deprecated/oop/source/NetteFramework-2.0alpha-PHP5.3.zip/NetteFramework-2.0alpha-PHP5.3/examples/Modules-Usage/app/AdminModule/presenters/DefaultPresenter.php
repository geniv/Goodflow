<?php

namespace AdminModule;

class DefaultPresenter extends \BasePresenter
{

}
