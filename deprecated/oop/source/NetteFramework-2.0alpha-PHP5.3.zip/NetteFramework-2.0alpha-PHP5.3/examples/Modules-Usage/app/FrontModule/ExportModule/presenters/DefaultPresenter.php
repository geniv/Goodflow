<?php

namespace FrontModule\ExportModule;

class DefaultPresenter extends \BasePresenter
{

}
