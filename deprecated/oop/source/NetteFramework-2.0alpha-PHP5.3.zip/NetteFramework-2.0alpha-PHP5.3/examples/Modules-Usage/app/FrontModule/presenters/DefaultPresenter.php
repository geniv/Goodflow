<?php

namespace FrontModule;

class DefaultPresenter extends \BasePresenter
{

}
