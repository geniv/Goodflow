<?php

namespace FrontModule;

class CatalogListPresenter extends \BasePresenter
{

}
