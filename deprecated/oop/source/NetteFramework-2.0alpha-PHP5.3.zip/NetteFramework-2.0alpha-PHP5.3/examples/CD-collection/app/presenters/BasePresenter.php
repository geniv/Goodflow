<?php

use Nette\Application\Presenter;


abstract class BasePresenter extends Presenter
{
}
