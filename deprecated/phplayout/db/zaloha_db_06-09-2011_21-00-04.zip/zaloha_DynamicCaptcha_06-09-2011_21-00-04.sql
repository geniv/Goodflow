
-------------------- table:captcha

CREATE TABLE captcha (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                font INTEGER UNSIGNED,
                                typ VARCHAR(50),
                                konfigurace TEXT,
                                otazka VARCHAR(500),
                                x INTEGER UNSIGNED,
                                y INTEGER UNSIGNED,
                                width INTEGER UNSIGNED,
                                height INTEGER UNSIGNED,
                                padding VARCHAR(20),
                                font_size VARCHAR(20),
                                roztec INTEGER UNSIGNED,
                                font_color VARCHAR(20),
                                background_color VARCHAR(10),
                                rotace_pismen VARCHAR(20),
                                mrizka VARCHAR(20),
                                rand_dot BOOL,
                                rand_line BOOL,
                                rand_rectangle BOOL,
                                rand_arc BOOL,
                                rand_ellipse BOOL,
                                rand_barva VARCHAR(20),
                                rand_koeficient VARCHAR(20),
                                url VARCHAR(200),
                                vyrez_x INTEGER UNSIGNED,
                                vyrez_y INTEGER UNSIGNED);


-------------------- table:font

CREATE TABLE font (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                nazev VARCHAR(100),
                                url VARCHAR(300));

