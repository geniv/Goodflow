
-------------------- table:useradmin

CREATE TABLE useradmin (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                login VARCHAR(800),
                                loginlog VARCHAR(100),
                                heslo VARCHAR(100),
                                permission INTEGER UNSIGNED,
                                jmeno VARCHAR(800),
                                konfigurace TEXT,
                                superadmin BOOL,
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO useradmin (id, login, loginlog, heslo, permission, jmeno, konfigurace, superadmin, pridano, upraveno, aktivni) VALUES ('1', '2560-03180-03550-04600-0501', '69f70f3d267e400ae665af2debb333fd', 'ad79e2cd5fd5ae53547d991007344847', '1', '2470-03250-03470-04570-04790-0559', '', '0', '2010-11-12 14:05:01', '', '1');

-------------------- table:ipban

CREATE TABLE ipban (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                nazev VARCHAR(100),
                                typ VARCHAR(50),
                                login VARCHAR(100),
                                ip VARCHAR(50),
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);


-------------------- table:adminlog

CREATE TABLE adminlog (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                login VARCHAR(100),
                                wrongpass VARCHAR(100),
                                datum DATETIME,
                                ip VARCHAR(50),
                                agent VARCHAR(300),
                                pocet INTEGER UNSIGNED,
                                language VARCHAR(100),
                                cookie TEXT,
                                get TEXT);


-------------------- table:moduly

CREATE TABLE moduly (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                include VARCHAR(500),
                                class VARCHAR(100),
                                admin BOOL,
                                databaze VARCHAR(100),
                                uloziste INTEGER UNSIGNED,
                                aktivni BOOL,
                                poradi INTEGER UNSIGNED,
                                pevneporadi INTEGER UNSIGNED);

INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('1', 'funkce.php', 'Funkce', '1', 'modules/.sqlite2', '1', '1', '1', '1');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('2', 'modules/dynamic_cron/dynamic_cron.php', 'DynamicCron', '1', '.dbdyncro.sqlite2', '1', '1', '2', '2');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('3', 'modules/dynamic_database/dynamic_database.php', 'DynamicDatabase', '1', '', '0', '1', '3', '3');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('4', 'modules/dynamic_config/dynamic_config.php', 'DynamicConfig', '1', '.dbdyncon.sqlite2', '1', '1', '4', '4');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('5', 'modules/dynamic_htaccess/dynamic_htaccess.php', 'DynamicHtaccess', '1', '.dbdynhta.sqlite2', '1', '0', '5', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('6', 'modules/dynamic_central/dynamic_central.php', 'DynamicCentral', '1', '.dbdyncen.sqlite2', '1', '1', '10', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('7', 'modules/dynamic_eshop/dynamicky_eshop.php', 'DynamicEshop', '1', '.dbdynesh.sqlite2', '1', '0', '8', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('10', 'modules/dynamic_registration/dynamic_registration.php', 'DynamicRegistration', '1', '.dbdynreg.sqlite2', '1', '1', '7', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('11', 'modules/dynamic_captcha/dynamic_captcha.php', 'DynamicCaptcha', '1', '.dbdyncap.sqlite2', '1', '1', '9', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('12', 'modules/static_menu/static_menu.php', 'StaticMenu', '0', '', '0', '0', '11', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('13', 'modules/dynamic_form/dynamic_form.php', 'DynamicForm', '1', '.dbdynfor.sqlite2', '2', '0', '14', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('14', 'modules/dynamic_table/dynamic_table.php', 'DynamicTable', '1', '.dbdyntab.sqlite2', '1', '0', '12', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('15', 'modules/dynamic_outside/dynamic_outside.php', 'DynamicOutside', '1', '.dbdynout.sqlite2', '1', '0', '13', '20');
INSERT INTO moduly (id, include, class, admin, databaze, uloziste, aktivni, poradi, pevneporadi) VALUES ('16', 'modules/dynamic_mail/dynamic_mail.php', 'DynamicMail', '1', '.dbdynmai.sqlite2', '1', '1', '6', '20');

-------------------- table:reporty

CREATE TABLE reporty (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                login VARCHAR(100),
                                email VARCHAR(200),
                                predmet VARCHAR(500),
                                message TEXT,
                                pridano DATETIME,
                                ip VARCHAR(50),
                                agent VARCHAR(300));


-------------------- table:permission

CREATE TABLE permission (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                nazev VARCHAR(100),
                                popis TEXT,
                                opravneni TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO permission (id, nazev, popis, opravneni, pridano, upraveno, aktivni) VALUES ('1', 'nezav', 'dfsdsd', 'DynamicCentral|-|dyncent__1|x||--x|x--|DynamicCentral|-|dyncent__1|x|addobsah|--x|x--|DynamicCentral|-|dyncent__1|x|delobsah|--x|x--|DynamicCentral|-|dyncent__1|x|editobsah|--x|x--|DynamicCentral|-|dyncent__4|x|addobsah|--x|x--|DynamicCentral|-|dyncent__4|x|copyobsah|--x|x--|DynamicCentral|-|dyncent__4|x|delobsah|--x|x--|DynamicCentral|-|dyncent__4|x|editobsah|--x|x--|DynamicCentral|-|dyncent_menu__1|x||--x|x--|DynamicCentral|-|dyncent_menu|x||--x|x--|DynamicCentral|-|dyncent_menu|x|addmenu|--x|x--|Funkce|-|funkce_logoff|x||--x|x--|Funkce|-|funkce|x||--x|x--|Funkce|-||x|', '2010-11-12 14:01:12', '2011-01-05 23:05:06', '1');
