
-------------------- table:zpravy

CREATE TABLE zpravy (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                predmet VARCHAR(200),
                                zprava TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                odeslano DATETIME,
                                zamek BOOL,
                                aktivni BOOL);

INSERT INTO zpravy (id, predmet, zprava, pridano, upraveno, odeslano, zamek, aktivni) VALUES ('1', 'pokusny predmet', 'toto je nejaka zprava...', '2011-02-23 12:47:47', '', '', '', '1');
INSERT INTO zpravy (id, predmet, zprava, pridano, upraveno, odeslano, zamek, aktivni) VALUES ('2', 'predmet zpravy', 'gdh aasfgfgsdf', '2011-02-23 14:59:03', '', '2011-02-23 15:44:56', '1', '1');
INSERT INTO zpravy (id, predmet, zprava, pridano, upraveno, odeslano, zamek, aktivni) VALUES ('3', 'hfhdg dfgf', 'jh gfh ghgf dffg', '2011-02-23 16:04:36', '', '2011-02-23 16:04:40', '1', '1');
INSERT INTO zpravy (id, predmet, zprava, pridano, upraveno, odeslano, zamek, aktivni) VALUES ('4', 'hgjjh hgfj fhg', 'gh gh gh', '2011-02-23 16:06:20', '', '2011-02-23 16:06:24', '1', '1');
INSERT INTO zpravy (id, predmet, zprava, pridano, upraveno, odeslano, zamek, aktivni) VALUES ('5', 'fdghdgh', 'fgfgh gfxgf fg fgfgdgdfg hjjdfh vc', '2011-02-23 16:08:56', '', '2011-02-23 16:09:00', '1', '1');

-------------------- table:maillist

CREATE TABLE maillist (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                email VARCHAR(500),
                                agent VARCHAR(300),
                                ip VARCHAR(50),
                                pridano DATETIME,
                                upraveno DATETIME,
                                typ VARCHAR(20));

INSERT INTO maillist (id, email, agent, ip, pridano, upraveno, typ) VALUES ('2', 'radek.frystak@gfdesign.cz', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.98 Safari/534.13', '127.0.1.1', '2011-02-23 16:10:54', '', 'dir');
INSERT INTO maillist (id, email, agent, ip, pridano, upraveno, typ) VALUES ('3', 'geniv.radek@gmail.com', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.98 Safari/534.13', '127.0.1.1', '2011-02-23 16:16:04', '', 'web');
INSERT INTO maillist (id, email, agent, ip, pridano, upraveno, typ) VALUES ('4', 'radek.frystak@student.upce.cz', 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/534.13 (KHTML, like Gecko) Chrome/9.0.597.98 Safari/534.13', '127.0.1.1', '2011-02-23 18:08:15', '', 'reg');
