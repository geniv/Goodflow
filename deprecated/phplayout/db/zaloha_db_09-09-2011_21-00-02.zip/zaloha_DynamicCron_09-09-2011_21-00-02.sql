
-------------------- table:cron

CREATE TABLE cron (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                modul VARCHAR(100),
                                funkce VARCHAR(100),
                                parametry TEXT,
                                popis TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL);

INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('1', 'Funkce', 'CronAdminClearLog', '', 'Promazávání admin logu', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('2', 'Funkce', 'CronZalohovaniDatabaze', '', 'Zálohování databází', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('3', 'Funkce', 'CronKontolaZalohyDatabaze', '', 'Promazávání databází', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('4', 'Funkce', 'CronZalohovaniUnikatnich', '', 'Zálohování unikátních', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('5', 'Funkce', 'CronKontrolaUnikatnich', '', 'Promazávání unikátních', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('6', 'Funkce', 'CronKontrolaErrorLogu', '', 'Promazávání error logů', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('7', 'Funkce', 'CronGenerovaniCacheGrafu', '', 'Generování cache pro grafy', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('8', 'Funkce', 'CronKontrolaSessionLogu', '', 'Promazávání session logů', '2010-11-07 10:06:31', '', '1');
INSERT INTO cron (id, modul, funkce, parametry, popis, pridano, upraveno, aktivni) VALUES ('9', 'Funkce', 'CronKontrolaActionLogu', '', 'Promazávání action logů', '2010-11-07 10:06:31', '', '1');

-------------------- table:cron_log

CREATE TABLE cron_log (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                exectime VARCHAR(100),
                                datum DATETIME,
                                agent VARCHAR(300),
                                ip VARCHAR(50));

INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('334', '8.742', '2011-09-04 21:00:14', 'Wget/1.12 (linux-gnu)', '127.0.1.1');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('335', '7.1769', '2011-09-05 21:00:10', 'Wget/1.12 (linux-gnu)', '127.0.1.1');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('336', '8.7362', '2011-09-06 21:00:13', 'Wget/1.12 (linux-gnu)', '127.0.1.1');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('337', '7.4813', '2011-09-07 21:00:11', 'Wget/1.12 (linux-gnu)', '127.0.1.1');
INSERT INTO cron_log (id, exectime, datum, agent, ip) VALUES ('338', '7.859', '2011-09-08 21:00:11', 'Wget/1.12 (linux-gnu)', '127.0.1.1');
