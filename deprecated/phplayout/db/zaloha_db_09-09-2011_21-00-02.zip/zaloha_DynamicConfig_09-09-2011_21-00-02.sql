
-------------------- table:sablona

CREATE TABLE sablona (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                adresa TEXT,
                                nazev VARCHAR(200),
                                popis TEXT,
                                poradi INTEGER UNSIGNED);

INSERT INTO sablona (id, adresa, nazev, popis, poradi) VALUES ('1', 'meta-informace', 'Meta informace', '', '1');
INSERT INTO sablona (id, adresa, nazev, popis, poradi) VALUES ('2', 'sdsd', 'polus', '', '2');

-------------------- table:element

CREATE TABLE element (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                sablona INTEGER UNSIGNED,
                                adresa TEXT,
                                nazev VARCHAR(200),
                                typ VARCHAR(50),
                                konfigurace TEXT,
                                value TEXT,
                                zamek BOOL,
                                popis TEXT,
                                pridano DATETIME,
                                upraveno DATETIME,
                                poradi INTEGER UNSIGNED);

INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('1', '1', 'meta_author', 'Meta author', 'fulltext', '100|--xx--|200', 'GoodFlow design - Tvorba webových stránek a systémů (www.gfdesign.cz)', '0', '', '2010-11-11 11:53:27', '2010-11-25 19:50:01', '1');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('2', '1', 'meta_copyright', 'Meta copyright', 'fulltext', '100|--xx--|200', 'Created by GoodFlow design', '0', '', '2010-11-11 11:53:27', '', '2');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('3', '1', 'meta_keywords', 'Meta keywords', 'fulltext', '100|--xx--|200', '', '0', '', '2010-11-11 11:53:27', '', '3');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('4', '2', 'dfd df df', 'dfdf', 'tinymce', '', '<h5>Newsletter</h5>
<p>Využij možnost b&yacute;t neust&aacute;le informov&aacute;n o novink&aacute;ch Mlad&yacute;ch podnikatelů!</p>
<p>Zadej svoji emailovou adresu a buď v obraze!</p>', '0', '', '2010-11-20 18:21:08', '', '4');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('5', '2', 'sdlfkndskfm', 'dfdfgjfdbn', 'tinymce', '', '<p>dkfjhbdj ndfdf</p>
<p>sdkfjdhjfkdf dsfdfdfdfdfydsf</p>
<p>sdfsdfkjshdgjhsdfdfsdf</p>', '0', '', '2010-11-20 18:22:50', '', '5');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('6', '2', 'sdfj', 'sdhjfbd jnf', 'tinymce', '', '<p>0</p>', '0', '', '2010-11-20 18:23:17', '', '6');
INSERT INTO element (id, sablona, adresa, nazev, typ, konfigurace, value, zamek, popis, pridano, upraveno, poradi) VALUES ('7', '2', 'gmnfg', 'skjfhb', 'tinymce', '', '<p>dviiiiiiiiiiiii</p>', '0', '', '2010-11-20 18:24:03', '', '7');
