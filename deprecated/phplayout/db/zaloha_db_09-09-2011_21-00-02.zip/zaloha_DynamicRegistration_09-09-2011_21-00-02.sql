
-------------------- table:user

CREATE TABLE user (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                login VARCHAR(100),
                                heslo VARCHAR(100),
                                email VARCHAR(200),
                                pridano DATETIME,
                                upraveno DATETIME,
                                aktivni BOOL,
                                polozky TEXT);

INSERT INTO user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('1', 'pokus', 'ad79e2cd5fd5ae53547d991007344847', 'geniv.radek@gmail.com', '2010-11-28 21:41:30', '2011-01-07 15:09:12', '1', 'jmeno:Radek|--xx--|prijmeni:Fryšták|--xx--|vek:15 let|--xx--|vzdelani:uplne stredni with mathuritou|--xx--|telefon:737123123|--xx--|nabidka:php5 with OOP, atd...|--xx--|osobe:I&#039;am good &quot;php programmer&quot;|--xx--|zkusenosti:4 roky v oboru ;) Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumyeirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamvoluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumyeirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamvoluptua. At vero eos et accusam et justo duo dolores et ea reb :) :) :D lol|--xx--|novinky:on|--xx--|foto:02-12-2010_21-30-30_3150.jpg');
INSERT INTO user (id, login, heslo, email, pridano, upraveno, aktivni, polozky) VALUES ('2', 'pokuss', 'eee118a6fa4d9906f010c0272ce57947', 'radek.frystak@student.upce.cz', '2011-02-23 17:15:19', '2011-02-23 18:08:15', '1', 'jmeno:rada|--xx--|prijmeni:hmm nekdo|--xx--|vek:24 let|--xx--|vzdelani:to nej|--xx--|telefon:123123123|--xx--|nabidka:df df dfdf|--xx--|osobe:dfdf df df|--xx--|zkusenosti:dsgddf|--xx--|novinky:on|--xx--|foto:23-02-2011_18-07-30_4336.jpg');

-------------------- table:last_log

CREATE TABLE last_log (
                                id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                user INTEGER UNSIGNED,
                                logon DATETIME,
                                last_act DATETIME,
                                agent VARCHAR(300),
                                ip VARCHAR(50));

