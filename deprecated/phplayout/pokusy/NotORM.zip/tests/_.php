<?php
include_once dirname(__FILE__) . "/connect.inc.php";
$software->debug = true;

foreach ($software->application()->select("author.name")->where("application.id", array(1, 2))->fetchPairs("application.id") as $application) {
	print_r(iterator_to_array($application));
}
