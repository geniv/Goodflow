
-------------------- table:dynamictasks_komentare

CREATE TABLE `dynamictasks_komentare` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tasks` int(10) unsigned DEFAULT NULL,
  `uzivatel` int(10) unsigned DEFAULT NULL,
  `zprava` text COLLATE utf8_czech_ci,
  `pridano` datetime DEFAULT NULL,
  `zanoreni` int(10) unsigned DEFAULT NULL,
  `zobrazit` tinyint(1) DEFAULT NULL,
  `ip` varchar(50) COLLATE utf8_czech_ci DEFAULT NULL,
  `agent` varchar(300) COLLATE utf8_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_komentare (id, tasks, uzivatel, zprava, pridano, zanoreni, zobrazit, ip, agent) VALUES ('1', '1', '2', 'toto je uplne prvni komentar, a taky první dodatek', '2009-10-29 18:45:40', '0', '1', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; cs-CZ; rv:1.9.0.14) Gecko/2009090216 Ubuntu/9.04 (jaunty) Firefox/3.0.14');
INSERT INTO dynamictasks_komentare (id, tasks, uzivatel, zprava, pridano, zanoreni, zobrazit, ip, agent) VALUES ('2', '1', '1', 'dfdfsdf vd sdf', '2009-10-29 18:52:39', '0', '1', '127.0.1.1', 'Mozilla/5.0 (X11; U; Linux i686; cs-CZ; rv:1.9.0.14) Gecko/2009090216 Ubuntu/9.04 (jaunty) Firefox/3.0.14');

-------------------- table:dynamictasks_last_login

CREATE TABLE `dynamictasks_last_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uzivatel` int(10) unsigned DEFAULT NULL,
  `prihlaseni` datetime DEFAULT NULL,
  `last_active` datetime DEFAULT NULL,
  `ip` varchar(50) COLLATE utf8_czech_ci DEFAULT NULL,
  `agent` varchar(300) COLLATE utf8_czech_ci DEFAULT NULL,
  `stav` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;


-------------------- table:dynamictasks_odkaz

CREATE TABLE `dynamictasks_odkaz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skupina` int(10) unsigned DEFAULT NULL,
  `link` text COLLATE utf8_czech_ci,
  `komentar` text COLLATE utf8_czech_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_odkaz (id, skupina, link, komentar) VALUES ('1', '1', 'gfdesign.cz', 'toto je lobovolny popis... :D lol');
INSERT INTO dynamictasks_odkaz (id, skupina, link, komentar) VALUES ('2', '1', 'kvarta.eu', 'n&aacute;řezov&yacute; web! ;)');

-------------------- table:dynamictasks_posta

CREATE TABLE `dynamictasks_posta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `od` int(10) unsigned DEFAULT NULL,
  `pro` int(10) unsigned DEFAULT NULL,
  `predmet` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `zprava` text COLLATE utf8_czech_ci,
  `odeslano` datetime DEFAULT NULL,
  `precteno` datetime DEFAULT NULL,
  `otevreno` tinyint(1) DEFAULT NULL,
  `zobrazit` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;


-------------------- table:dynamictasks_pozadi

CREATE TABLE `dynamictasks_pozadi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uzivatel` int(10) unsigned DEFAULT NULL,
  `url` varchar(300) COLLATE utf8_czech_ci DEFAULT NULL,
  `barva` varchar(20) COLLATE utf8_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_pozadi (id, uzivatel, url, barva) VALUES ('2', '1', '04-11-2009-20-17-33.jpg', '#ee5875');

-------------------- table:dynamictasks_projekt

CREATE TABLE `dynamictasks_projekt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skupina` int(10) unsigned DEFAULT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `popis` text COLLATE utf8_czech_ci,
  `zadani` datetime DEFAULT NULL,
  `dokonceni` datetime DEFAULT NULL,
  `dokonceno` tinyint(1) DEFAULT NULL,
  `cena` int(10) unsigned DEFAULT NULL,
  `narocnost` int(10) unsigned DEFAULT NULL,
  `poradi` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_projekt (id, skupina, nazev, popis, zadani, dokonceni, dokonceno, cena, narocnost, poradi) VALUES ('1', '4', 'pokusny projekt', 'enoenfjbsf asdsaidfn kajs fas dkjsad aks dasd', '2009-10-27 09:53:36', '2009-11-28 00:00:00', '0', '2000', '2', '1');

-------------------- table:dynamictasks_skupina

CREATE TABLE `dynamictasks_skupina` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tym` int(10) unsigned DEFAULT NULL,
  `uzivatel` int(10) unsigned DEFAULT NULL,
  `verejne` int(10) unsigned DEFAULT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `popis` text COLLATE utf8_czech_ci,
  `zalozeno` datetime DEFAULT NULL,
  `poradi` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_skupina (id, tym, uzivatel, verejne, nazev, popis, zalozeno, poradi) VALUES ('1', '22', '1', '1', 'skupina 2', 'ghdsfhgdfg fd df gsdg s.mgfhkdjfghjkdfgjhdsbf fd fd fds  dsf dsf dsfsd fds f dsf', '2009-10-25 11:55:53', '1');
INSERT INTO dynamictasks_skupina (id, tym, uzivatel, verejne, nazev, popis, zalozeno, poradi) VALUES ('4', '36', '2', '1', 'nbcbvcb', 'mvj nbhg bn jhmnmb hgu jbjh kihkj', '2009-10-26 16:06:40', '1');
INSERT INTO dynamictasks_skupina (id, tym, uzivatel, verejne, nazev, popis, zalozeno, poradi) VALUES ('3', '22', '1', '2', 'gdhgff', 'ghdfgfdg srdtg sdf', '2009-10-26 14:58:18', '2');

-------------------- table:dynamictasks_skupina_odkazu

CREATE TABLE `dynamictasks_skupina_odkazu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uzivatel` int(10) unsigned DEFAULT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `barva` varchar(20) COLLATE utf8_czech_ci DEFAULT NULL,
  `komentar` text COLLATE utf8_czech_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_skupina_odkazu (id, uzivatel, nazev, barva, komentar) VALUES ('1', '1', 'moje odkazy', '#200dc9', 'toto je ultra super koment&aacute;ř :D ;) hojas');

-------------------- table:dynamictasks_tasks

CREATE TABLE `dynamictasks_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `projekt` int(10) unsigned DEFAULT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `popis` text COLLATE utf8_czech_ci,
  `zadani` datetime DEFAULT NULL,
  `dokonceni` datetime DEFAULT NULL,
  `dokonceno` tinyint(1) DEFAULT NULL,
  `dulezitost` int(10) unsigned DEFAULT NULL,
  `barva` varchar(20) COLLATE utf8_czech_ci DEFAULT NULL,
  `narocnost` int(10) unsigned DEFAULT NULL,
  `zobrazit` tinyint(1) DEFAULT NULL,
  `poradi` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_tasks (id, projekt, nazev, popis, zadani, dokonceni, dokonceno, dulezitost, barva, narocnost, zobrazit, poradi) VALUES ('1', '1', 'ukol 1.', 'dfdsdf dsfd fd f df d ydsa', '2009-10-28 22:36:27', '0000-00-00 00:00:00', '0', '2', '#1464bd', '0', '1', '1');

-------------------- table:dynamictasks_tym

CREATE TABLE `dynamictasks_tym` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nazev` varchar(300) COLLATE utf8_czech_ci DEFAULT NULL,
  `zakladatel` int(10) unsigned DEFAULT NULL,
  `popis` text COLLATE utf8_czech_ci,
  `vznik` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('2', 'gf design', '1', 'ultra tvořičský tým a vůbec ;)', '2009-10-23 19:10:34');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('3', 'aas', '1', 'gfsfdtg', '2009-10-24 19:47:10');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('4', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 20:33:31');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('5', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:06:26');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('6', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:06:43');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('7', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:07:13');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('8', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:07:23');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('9', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:07:42');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('10', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:08:38');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('11', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:13:47');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('12', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:14:15');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('13', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:14:53');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('14', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:15:15');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('15', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:15:31');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('16', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:16:00');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('17', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:16:47');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('18', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:19:51');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('19', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:20:13');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('20', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:50:18');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('21', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:50:50');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('22', 'tum 2 :D', '1', 'dfgdfg', '2009-10-24 21:52:28');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('23', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:52:51');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('24', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:53:33');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('25', 'dfgfdg', '1', 'dfgdfg', '2009-10-24 21:53:56');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('26', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:19:35');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('27', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:19:54');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('28', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:21:23');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('29', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:23:12');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('30', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:25:18');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('31', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:25:35');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('32', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:25:51');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('33', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:25:59');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('34', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:26:38');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('35', 'sdfdf', '1', 'sdfdsf', '2009-10-24 23:27:55');
INSERT INTO dynamictasks_tym (id, nazev, zakladatel, popis, vznik) VALUES ('36', 'bouchači', '2', 'sda fassad sad sad sad', '2009-10-26 15:06:08');

-------------------- table:dynamictasks_uzivatele

CREATE TABLE `dynamictasks_uzivatele` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tym` text COLLATE utf8_czech_ci,
  `jmeno` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `prijmeni` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `login` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `heslo` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `popis` text COLLATE utf8_czech_ci,
  `foto` varchar(300) COLLATE utf8_czech_ci DEFAULT NULL,
  `zalozeno` datetime DEFAULT NULL,
  `upraveno` datetime DEFAULT NULL,
  `pocet` int(10) unsigned DEFAULT NULL,
  `aktivni` tinyint(1) DEFAULT NULL,
  `nastaveni` text COLLATE utf8_czech_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO dynamictasks_uzivatele (id, tym, jmeno, prijmeni, login, heslo, email, popis, foto, zalozeno, upraveno, pocet, aktivni, nastaveni) VALUES ('1', '22-26-34-35', 'Radek', 'ujo', 'geniv', 'ad79e2cd5fd5ae53547d991007344847', 'email@email.cz', 'bleeeeeeeeee <lol> d:s', '', '2009-10-18 10:51:15', '2009-10-24 23:27:55', '0', '1', '');
INSERT INTO dynamictasks_uzivatele (id, tym, jmeno, prijmeni, login, heslo, email, popis, foto, zalozeno, upraveno, pocet, aktivni, nastaveni) VALUES ('2', '36', 'franta', 'flinta', 'genva', 'ad79e2cd5fd5ae53547d991007344847', 'email@email.cz', 'sd fdfd f dfdf', '', '2009-10-26 15:05:40', '2009-10-26 15:06:08', '0', '1', '');
