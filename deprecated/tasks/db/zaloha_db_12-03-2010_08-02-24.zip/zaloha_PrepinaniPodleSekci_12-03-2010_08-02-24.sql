
-------------------- table:prepinani

CREATE TABLE prepinani (
                                      id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                      adresa TEXT,
                                      kod TEXT);

INSERT INTO prepinani (id, adresa, kod) VALUES ('1', 'titleuvod', 'Uvítací list');
INSERT INTO prepinani (id, adresa, kod) VALUES ('2', 'o-cajovne', ' - ');
INSERT INTO prepinani (id, adresa, kod) VALUES ('3', 'galerie', ' - ');
INSERT INTO prepinani (id, adresa, kod) VALUES ('4', 'online-nabidnik', ' - ');
INSERT INTO prepinani (id, adresa, kod) VALUES ('5', 'akce', ' - ');
INSERT INTO prepinani (id, adresa, kod) VALUES ('6', 'navstevni-kniha', ' - ');
INSERT INTO prepinani (id, adresa, kod) VALUES ('7', 'logo', 'logo_uvitaci_list');
INSERT INTO prepinani (id, adresa, kod) VALUES ('8', 'o-cajovnelogo', 'logo_o_cajovne');
INSERT INTO prepinani (id, adresa, kod) VALUES ('9', 'galerielogo', 'logo_galerie');
INSERT INTO prepinani (id, adresa, kod) VALUES ('10', 'online-nabidniklogo', 'logo_online_nabidnik');
INSERT INTO prepinani (id, adresa, kod) VALUES ('12', 'navstevni-knihalogo', 'logo_navstevni_kniha');
INSERT INTO prepinani (id, adresa, kod) VALUES ('13', 'online-nabidnik-jquery-nabidnik', '&lt;script type=&quot;text/javascript&quot; src=&quot;@@1@@script/jquery/jquery-132-yui.js&quot;&gt;&lt;/script&gt;
    &lt;script type=&quot;text/javascript&quot; src=&quot;@@1@@script/jquery/jqueryaccordion-yui.js&quot;&gt;&lt;/script&gt;
    &lt;script type=&quot;text/javascript&quot; src=&quot;@@1@@script/jquery/accordion.js&quot;&gt;&lt;/script&gt;');
INSERT INTO prepinani (id, adresa, kod) VALUES ('14', 'navstevni-kniha-jquery-tooltip', '&lt;script type=&quot;text/javascript&quot; src=&quot;@@1@@script/jquery/jquery-132-yui.js&quot;&gt;&lt;/script&gt;
    &lt;script type=&quot;text/javascript&quot; src=&quot;@@1@@script/jquery/toolstooltip-102-yui.js&quot;&gt;&lt;/script&gt;
    &lt;script type=&quot;text/javascript&quot; src=&quot;@@1@@script/jquery/jquerytooltip-yui.js&quot;&gt;&lt;/script&gt;');
