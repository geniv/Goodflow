
-------------------- table:dynamicky_obsah

CREATE TABLE dynamicky_obsah (
                                  id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                  adresa TEXT,
                                  text TEXT,
                                  skupina INTEGER UNSIGNED);

INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('1', 'author', 'Martion &amp;amp; Geniv &amp;amp; Fugess (Martion &amp;amp; GF Design, www.martiondesign.net &amp;amp; www.gfdesign.cz)', '1');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('2', 'copyright', 'Designed by Martion &amp;amp; Created by GF design', '1');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('3', 'keywords', 'meta keywords', '1');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('4', 'description', ' - meta description', '1');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('5', 'createdby', 'Designed by &lt;a href=&quot;http://www.martiondesign.net/&quot; title=&quot;Martion Design.net&quot; onclick=&quot;window.open(this.href); return false;&quot;&gt;Martion&lt;/a&gt; | Created by &lt;a href=&quot;http://www.gfdesign.cz/&quot; title=&quot;GF Design - Tvorba webových stránek a systémů&quot;&gt;GF design&lt;/a&gt;', '2');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('6', 'vygenerovano', 'Stránka vygenerována za:', '2');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('7', 'zapaticopyright', 'All rights reserved by Vychozi Layout', '2');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('8', 'validator-xhtml', '&lt;a href=&quot;http://validator.w3.org/check?uri=referer&quot; title=&quot;Valid XHTML 1.0 Strict&quot;&gt;xhtml&lt;/a&gt;', '2');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('9', 'validatory-css', '&lt;a href=&quot;http://jigsaw.w3.org/css-validator/check/referer&quot; title=&quot;Valid CSS 2.1&quot;&gt;css&lt;/a&gt;', '2');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('10', 'highslide-pruhlednost-pozadi', '0.75', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('11', 'highslide-pruhlednost-panel', '.75', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('12', 'highslide-panel-pozice', 'bottom center', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('13', 'highslide-panel-zobrazeni', 'true', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('14', 'highslide-panel-zapnut-vypnut', 'true', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('15', 'panel-staticky-plovouci-fit-false', '&quot;fit&quot;', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('16', 'number-position-caption-heading', '', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('17', 'highslide-nastaveni-outlinetype', 'hs.outlineType', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('18', 'highslide-nastaveni-wrapperclassname', 'hs.wrapperClassName', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('19', 'highslide-outlinetype-hodnota', 'glossy-dark', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('20', 'highslide-wrapperclassname-hodnota', 'dark', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('21', 'fadeinout-prolnuti', 'false', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('22', 'popis-obrazku-caption-heading', 'caption', '3');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('23', 'pozice-admin-panelu', 'right', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('24', 'automaticke-skryvani-admin-panelu', 'false', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('25', 'rychlost-prijeti-admin-panelu', '1000', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('26', 'rychlost-odjeti-admin-panelu', '1000', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('27', 'zpusob-volani-admin-panelu', 'click', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('28', 'smer-prijeti-admin-panelu', 'right', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('29', 'smer-odjeti-admin-panelu', 'left', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('30', 'styl-prijeti-admin-panelu', 'easeOutBounce', '4');
INSERT INTO dynamicky_obsah (id, adresa, text, skupina) VALUES ('31', 'styl-odjeti-admin-panelu', 'easeOutBounce', '4');

-------------------- table:gtk_skupina

CREATE TABLE gtk_skupina (
                                  id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                  nazev VARCHAR(200),
                                  popisek TEXT,
                                  href_id VARCHAR(200),
                                  href_class VARCHAR(200),
                                  href_akce VARCHAR(500),
                                  zobrazit BOOL);

INSERT INTO gtk_skupina (id, nazev, popisek, href_id, href_class, href_akce, zobrazit) VALUES ('1', 'Meta popisky', '', '', '', '', '0');
INSERT INTO gtk_skupina (id, nazev, popisek, href_id, href_class, href_akce, zobrazit) VALUES ('2', 'Zápatí', '', '', '', '', '0');
INSERT INTO gtk_skupina (id, nazev, popisek, href_id, href_class, href_akce, zobrazit) VALUES ('3', 'Nastavení highslide', 'Možné hodnoty a příklady jsou vypsány ve zdrojovém kódu na stránkách&lt;br /&gt;(popis-obrazku-caption-heading - musí být zapsána vždy jedna hodnota caption nebo heading)', '', '', '', '0');
INSERT INTO gtk_skupina (id, nazev, popisek, href_id, href_class, href_akce, zobrazit) VALUES ('4', 'Nastavení admin panelu', 'Zde můžeš měnit hodnoty logovacího panelu do administrace.&lt;br /&gt;
Příklady použití jsou v &lt;strong&gt;&lt;a href=&quot;script/jquery/log_ad.js&quot; title=&quot;log_ad.js&quot;&gt;log_ad.js&lt;/a&gt;&lt;/strong&gt;', '', '', '', '1');
