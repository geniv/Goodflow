<?php

require_once 'Text.class.php'; // Require/include the class file

// You don't need to instantiate the class
echo Text::capitalize('hello world!');

// by the way you can do so if you like
$txt = new Text;
echo $txt->capitalize('hello world!');

?>