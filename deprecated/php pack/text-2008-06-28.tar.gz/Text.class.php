<?php

/**
 * Text helper class
 *
 * A helper class extracted from my own MVC framework.
 *
 * Very, very basic usage:
 *		$Text = new Text;
 *		echo $Text->capitalize('hello world!');
 *
 * @author		Chris Lam <admin@knetgb.com>
 * @package		mvc
 * @subpackage	sys.helpers
 * @version		1.0
 */
class Text
{
	/**
	 * Callback function for capitalize
	 *
	 * @access	private
	 * @param	string
	 * @return	string
	 */
	function _capitalize_ucfirst($str = '', $uc_digits = null)
	{
		static $_uc_digits = false;

		if(isset($uc_digits))
		{
			$_uc_digits = $uc_digits;
			return;
		}

		if(substr($str[0], 0, 1) != "'" && !preg_match("!\d!", $str[0]) || $_uc_digits)
			return ucfirst($str[0]);
		else
			return $str[0];
	}

	/**
	 * Capitalize the first letter of all words in a variable
	 *
	 * @access	public
	 * @param	string
	 * @param	boolean
	 * @return	string
	 */
	function capitalize($str = '', $uc_digits = false)
	{
		return preg_replace_callback('!\'?\b\w(\w|\')*\b!', array('Text', '_capitalize_ucfirst'), $str);
	}

	/**
	 * Word Censor
	 *
	 * Supply a string and an array of disallowed words and any
	 * matched words will be converted to **** or to the replacement
	 * word you've submitted.
	 *
	 * @access	public
	 * @param	string	the text string
	 * @param	array	the array of censored words
	 * @param	string	the optional replacement value
	 * @return	string
	 */
	function censor($str, $censored, $replacement = '')
	{
		if(!is_array($censored))
			$censored = array($censored);

		$str = ' ' . $str . ' ';
		foreach($censored as $badword)
		{
			if(strlen($replacement) > 0)
				$str = preg_replace("/\b(" . str_replace('\*', '\w*?', preg_quote($badword)) . ")\b/i", $replacement, $str);
			else
				$str = preg_replace("/\b(" . str_replace('\*', '\w*?', preg_quote($badword)) . ")\b/ie", "str_repeat('*', strlen('\\1'))", $str);
		}
		return trim($str);
	}

	/**
	 * Count number of characters
	 *
	 * @access	public
	 * @param	string
	 * @param	boolean
	 * @return	integer
	 */
	function count_chars($str = '', $include_spaces = false)
	{
		if($include_spaces)
			return(strlen($str));
		return preg_match_all("/[^\s]/", $str, $match);
	}

	/**
	 * Count number of paragraphs
	 *
	 * @access	public
	 * @param	string
	 * @return	integer
	 */
	function count_paragraphs($str = '')
	{
		return count(preg_split('/[\r\n]+/', $str));
	}

	/**
	 * Count number of sentense
	 *
	 * @access	public
	 * @param	string
	 * @return	integer
	 */
	function count_sentenses($str = '')
	{
		return preg_match_all('/[^\s]\.(?!\w)/', $str, $match);
	}

	/**
	 * encode or escape String
	 *
	 * @param unknown_type $str
	 * @param unknown_type $esc_type
	 * @param unknown_type $char_set
	 * @return unknown
	 */
	function escape($str, $esc_type = 'html', $char_set = 'ISO-8859-1')
	{
		switch ($esc_type)
		{
			case 'html':
				return htmlspecialchars($str, ENT_QUOTES, $char_set);

			case 'htmlall':
				return htmlentities($str, ENT_QUOTES, $char_set);

			case 'url':
				return rawurlencode($str);

			case 'urlpathinfo':
				return str_replace('%2F','/',rawurlencode($str));

			case 'quotes':
				return preg_replace("%(?<!\\\\)'%", "\\'", $str);

			case 'hex':
				$return = '';
				for($x=0; $x < strlen($str); $x++)
				{
					$return .= '%' . bin2hex($str[$x]);
				}
				return $return;

			case 'hexentity':
				$return = '';
				for($x=0; $x < strlen($str); $x++)
				{
					$return .= '&#x' . bin2hex($str[$x]) . ';';
				}
				return $return;

			case 'decentity':
				$return = '';
				for($x=0; $x < strlen($str); $x++)
				{
					$return .= '&#' . ord($str[$x]) . ';';
				}
				return $return;

			case 'js':
				return strtr($str, array('\\'=>'\\\\',"'"=>"\\'",'"'=>'\\"',"\r"=>'\\r',"\n"=>'\\n','</'=>'<\/'));

			case 'mail':
				return str_replace(array('@', '.'),array(' [AT] ', ' [DOT] '), $str);

			case 'nonstd':
				$_res = '';
				for($_i = 0, $_len = strlen($str); $_i < $_len; $_i++)
				{
					$_ord = ord(substr($str, $_i, 1));
					$_res .= $_ord >= 126 ? '&#' . $_ord . ';' : substr($str, $_i, 1);
				}
			return $_res;

			default:
				return $str;
		}
	}

	/**
	 * Alias for Word Censor
	 *
	 * @access	public
	 * @param	string	the text string
	 * @param	array	the array of censored words
	 * @param	string	the optional replacement value
	 * @return	string
	 */
	function filter($str, $censored, $replacement = '')
	{
		return Text::censor($str, $censored, $replacement);
	}

	/**
	 * Code Highlighter
	 *
	 * Colorizes code strings
	 *
	 * @access	public
	 * @param	string	the text string
	 * @return	string
	 */
	function highlight_code($str)
	{
		$str = str_replace(array('&lt;', '&gt;'), array('<', '>'), $str);
		$str = str_replace(array('&lt;?php', '?&gt;',  '\\'), array('phptagopen', 'phptagclose', 'backslashtmp'), $str);
		$str = '<?php //tempstart' . "\n" . $str . '//tempend ?>';
		$str = highlight_string($str, true);
		if(abs(phpversion()) < 5)
		{
			$str = str_replace(array('<font ', '</font>'), array('<span ', '</span>'), $str);
			$str = preg_replace('#color="(.*?)"#', 'style="color: \\1"', $str);
		}
		$str = preg_replace("#\<code\>.+?//tempstart\<br />\</span\>#is", "<code>\n", $str);
		$str = preg_replace("#\<code\>.+?//tempstart\<br />#is", "<code>\n", $str);
		$str = preg_replace("#//tempend.+#is", "</span>\n</code>", $str);
		$str = str_replace(array('phptagopen', 'phptagclose', 'backslashtmp'), array('&lt;?php', '?&gt;', '\\'), $str); //<?
		return $str;
	}

	/**
	 * Phrase Highlighter
	 *
	 * Highlights a phrase within a text string
	 *
	 * @access	public
	 * @param	string	the text string
	 * @param	string	the phrase you'd like to highlight
	 * @param	string	the openging tag to precede the phrase with
	 * @param	string	the closing tag to end the phrase with
	 * @return	string
	 */
	function highlight_phrase($str, $phrase, $tag_open = '<strong>', $tag_close = '</strong>')
	{
		return preg_replace('/(' . preg_quote($phrase) . ')/i', $tag_open . "\\1" . $tag_close, $str);
	}

	/**
	 * Indent words
	 *
	 * @access	public
	 * @param	string
	 * @param	integer
	 * @param	string
	 * @return	string
	 */
	function indent($str, $size = 4, $char='&nbsp;')
	{
		return preg_replace('/^/m', str_repeat($char, $size), $str);
	}

	/**
	 * Word Limiter
	 *
	 * Limits a string to X number of words.
	 *
	 * @access	public
	 * @param	string
	 * @param	integer
	 * @param	string	the end character. Usually an ellipsis (...)
	 * @return	string
	 */
	function limit_word($str, $n = 100, $end_char = '...')
	{
		if(strlen($str) < $n)
			return $str;

		$words = explode(' ', preg_replace("/\s+/", ' ', preg_replace("/(\r\n|\r|\n)/", " ", $str)));

		if(count($words) <= $n)
			return $str;

		$str = '';
		for($i = 0; $i < $n; $i++)
		{
			$str .= $words[$i].' ';
		}
		return trim($str) . $end_char;
	}

	/**
	 * Character Limiter
	 *
	 * Limits the string based on the character count. Preserves complete words
	 * so the character count may not be exactly as specified.
	 *
	 * @access	public
	 * @param	string
	 * @param	integer
	 * @param	string	the end character. Usually an ellipsis (...)
	 * @return	string
	 */
	function limit_char($str, $n = 500, $end_char = '...')
	{
		if(strlen($str) <= $n)
			return $str;

		return substr($str, 0, $n) . $end_char;
	}

	/**
	 * Add specified string between each characters
	 *
	 * @param	string
	 * @param	string
	 * @return	string
	 */
	function spacify($str = '', $spacify_char = ' ')
	{
		return implode($spacify_char, preg_split('//', $str, -1, PREG_SPLIT_NO_EMPTY));
	}

	/**
	 * Replaces all repeated spaces, newlines and tabs with the supplied string
	 *
	 * @param	string
	 * @param	string
	 * @return	string
	 */
	function strip($text, $replace = ' ')
	{
		return preg_replace('/\s+/', $replace, $text);
	}


	/**
	 * Alias for Character Limiter
	 *
	 * Limits the string based on the character count. Preserves complete words
	 * so the character count may not be exactly as specified.
	 *
	 * @access	public
	 * @param	string
	 * @param	integer
	 * @param	string	the end character. Usually an ellipsis (...)
	 * @param	boolean
	 * @return	string
	 */
	function truncate($str, $n = 500, $end_char = '...', $beak_chars = true)
	{
		return $beak_chars ? Text::limit_char($str, $n, $end_char) : Text::limit_word($str, $n, $end_char);
	}

	/**
	 * Word Wrap
	 *
	 * Wraps text at the specified character.  Maintains the integrity of words.
	 * Anything placed between {unwrap}{/unwrap} will not be wrapped, nor
	 * will URLs.
	 *
	 * @access	public
	 * @param	string	the text string
	 * @param	integer	the number of characters to wrap at
	 * @return	string
	 */
	function wordwrap($str, $charlim = 76, $break = '<br />')
	{
		if(!is_numeric($charlim))
			$charlim = 76;

		$str = preg_replace("| +|", " ", $str);
		$str = preg_replace("/\r\n|\r/", "\n", $str);

		$unwrap = array();
		if(preg_match_all("|(\{unwrap\}.+?\{/unwrap\})|s", $str, $matches))
		{
			$count = count($matches['0']);
			for($i = 0; $i < $count; $i++)
			{
				$unwrap[] = $matches['1'][$i];
				$str = str_replace($matches['1'][$i], "{{unwrapped".$i."}}", $str);
			}
		}

		$str = wordwrap($str, $charlim, $break, false);

		$output = '';
		foreach(explode($break, $str) as $line)
		{
			if(strlen($line) <= $charlim)
			{
				$output .= $line . $break;
				continue;
			}

			$temp = '';
			while((strlen($line)) > $charlim)
			{
				if(preg_match("!\[url.+\]|://|wwww.!", $line))
					break;

				$temp .= substr($line, 0, $charlim-1);
				$line = substr($line, $charlim-1);
			}
			$output .= ($temp != '' ? $temp . $this->newline . $line : $line) . $break;
		}

		if(count($unwrap) > 0)
		{
			foreach($unwrap as $key => $val)
			{
				$output = str_replace("{{unwrapped".$key."}}", $val, $output);
			}
		}

		$output = str_replace(array('{unwrap}', '{/unwrap}'), '', $output);
		return $output;
	}
}

?>