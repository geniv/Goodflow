<?
$wl = array(
	'alert' => array(
		'take changes' => 'Salvare i modificazioni?',
		'take filter' => 'Usare filtro?'
	),
	'default' => array(
		'apply' => 'Applicare',
		'balance' => 'Equilibrio colore',
		'blur' => 'Sfocare',
		'brightness' => 'Luminosit&agrave;',
		'brightness contrast' => 'Luminosit&agrave; &amp; contrasto',
		'change size' => 'Cambiare dimensione',
		'color' => 'Colore',
		'contrast' => 'Contrasto',
		'correction' => 'Correzione automaticha tonalit&agrave;',
		'cut' => 'Tagliare',
		'cyan red' => 'Cyan/Rosso',
		'filter' => 'Filtro',
		'font' => 'Scrittura',
		'height' => 'Altezza',
		'horizontal' => 'orizzontale',
		'magenta green' => 'Magenta/Verde',
		'pagetitle' => 'Editore d\'immagine',
		'percent' => 'Percento',
		'preferences' => 'Impostazioni',
		'preview' => 'Visualizzazione',
		'proportions' => 'Mantenere proporzioni',
		'rate' => 'Ammontare',
		'reflect' => 'Riflettere',
		'rotate' => 'Ruotare',
		'invert' => 'Invert',
		'save' => 'Salvare',
		'save changes' => 'Salvare i modificazioni?\n(L\'immagine sarà sostituita)',
		'size' => 'Dimensione',
		'text' => 'Testo',
		'to the left' => 'alla sinistra',
		'to the right' => 'alla destra',
		'update' => 'Aggiornare',
		'vertical' => 'verticale',
		'watermark' => 'Filigrana',
		'width' => 'Larghezza',
		'yellow blue' => 'Giallo/Blu'
	)
);
?>
