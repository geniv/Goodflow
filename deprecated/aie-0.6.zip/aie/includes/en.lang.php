<?
$wl = array(
	'alert' => array(
		'take changes' => 'Save changes?',
		'take filter' => 'Use filter?'
	),
	'default' => array(
		'apply' => 'Apply',
		'balance' => 'Color balance',
		'blur' => 'Blur',
		'brightness' => 'Brightness',
		'brightness contrast' => 'Brightness &amp; contrast',
		'change size' => 'Change size',
		'color' => 'Color',
		'contrast' => 'Contrast',
		'correction' => 'Automatic color correction',
		'cut' => 'Cut',
		'cyan red' => 'Cyan/Red',
		'filter' => 'Filter',
		'font' => 'Font',
		'height' => 'Height',
		'horizontal' => 'horizontal',
		'magenta green' => 'Magenta/Green',
		'pagetitle' => 'Image editor',
		'percent' => 'Percent',
		'preferences' => 'Preferences',
		'preview' => 'Preview',
		'proportions' => 'Maintain proportions',
		'rate' => 'Rate',
		'reflect' => 'Reflect',
		'rotate' => 'Rotate',
		'invert' => 'Invert',
		'save' => 'Save',
		'save changes' => 'Save changes?\n(Image will be overwritten)',
		'size' => 'Size',
		'text' => 'Text',
		'to the left' => 'to the left',
		'to the right' => 'to the right',
		'update' => 'Update',
		'vertical' => 'vertical',
		'watermark' => 'Watermark',
		'width' => 'Width',
		'yellow blue' => 'Yellow/Blue'
	)
);
?>
