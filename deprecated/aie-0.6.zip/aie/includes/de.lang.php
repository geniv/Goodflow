<?
$wl = array(
	'alert' => array(
		'take changes' => 'Änderungen übernehmen?',
		'take filter' => 'Filter anwenden?'
	),
	'default' => array(
		'apply' => 'Anwenden',
		'balance' => 'Farbbalance',
		'blur' => 'Weichzeichnen',
		'brightness' => 'Helligkeit',
		'brightness contrast' => 'Helligkeit &amp; Kontrast',
		'change size' => 'Gr&ouml;&szlig;e &auml;ndern',
		'color' => 'Farbe',
		'contrast' => 'Kontrast',
		'correction' => 'Automatische Tonwertkorrektur',
		'cyan red' => 'Cyan/Rot',
		'cut' => 'Zuschneiden',
		'filter' => 'Filter',
		'font' => 'Schriftart',
		'height' => 'H&ouml;he',
		'horizontal' => 'horizontal',
		'magenta green' => 'Magenta/Gr&uuml;n',
		'pagetitle' => 'Bildeditor',
		'percent' => 'Prozent',
		'preferences' => 'Einstellungen',
		'preview' => 'Vorschau',
		'proportions' => 'Proportionen erhalten',
		'rate' => 'Rate',
		'reflect' => 'Spiegeln',
		'rotate' => 'Rotieren',
		'invert' => 'Negativ',
		'save' => 'Sichern',
		'save changes' => 'Änderungen sichern?\n(Bild wird dabei überschrieben)',
		'size' => 'Gr&ouml;&szlig;e',
		'text' => 'Text',
		'to the left' => 'nach links',
		'to the right' => 'nach rechts',
		'update' => 'Aktualisieren',
		'vertical' => 'vertikal',
		'watermark' => 'Wasserzeichen',
		'width' => 'Breite',
		'yellow blue' => 'Gelb/Blau'
	)
);
?>
