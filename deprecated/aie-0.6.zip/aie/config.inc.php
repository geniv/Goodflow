<?php
  $web_root_dir="/var/www/aie/"; 	             //the root directory of the webpage
  $server_temp_dir=$web_root_dir."temp/";      //the directory for temporary files and thumbnails cache
  $ffmpeg_location="";                         //the location of ffmpeg for video preview eg. "/usr/bin/ffmpeg". leave blank if ffmpeg is not installed.
  $fonts_dir=$web_root_dir."/fonts/";          //the fonts-directory
  $imagemagick_dir="/usr/bin/";                //the ImageMagick installation directory
  $language="en";                              //the Language, en and de for now...
  $ext_dir="../../ext/";                       //the relative path to the ext-js-library
  $default_theme="black";                      //the default ext-js-theme
?>
